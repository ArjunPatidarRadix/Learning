export const ENTER_NAME_SCREEN = 'EnterNameScreen';
export const CHAT_USER_LIST_SCREEN = 'ChatUserListScreen';
export const CHAT_SCREEN = 'ChatScreen';
