const createExpoWebpackConfigAsync = require('@expo/webpack-config');

module.exports = async function (env, argv) {
  // const config = await createExpoWebpackConfigAsync(env, argv);
  const config = await createExpoWebpackConfigAsync({
      ...env,
      babel: {
          dangerouslyAddModulePathsToTranspile: ['@dudigital/react-native-zoomable-view','rn-fade-carousel']
      }
  }, argv);

  // Customize the config before returning it.
  config.resolve.alias['react-native'] = 'react-native-web';
  config.resolve.alias['react-native-maps'] = 'react-native-web-maps';
  config.resolve.alias['deepmerge$'] = 'deepmerge/dist/umd.js';
  config.resolve.alias['lottie-react-native'] = 'react-native-web-lottie';

  // Resolve relative reference ../Utilities/Platform using react-native-web
  // config.resolve.alias['../Utilities/Platform'] = 'react-native-web/dist/exports/Platform';
  // config.resolve.alias['./PlatformColorValueTypes'] = 'react-native-web/dist/exports/StyleSheet';
  // config.resolve.alias['../../Utilities/useWindowDimensions'] = 'react-native-web/dist/exports/useWindowDimensions';

  return config;
};
