// external Libraries
import { create } from "apisauce";

const domain = "https://plus2app.com";
const apiKey = "49a77729-cbcb-4dee-a427-832ac1d573ae";

const apiRequestTimeOut = 20000; // 30 secs

//  Do not change anything after this line if you're not sure about what you're doing.
const api = create({
  baseURL: domain + "/wp-json/rtcl/v1/",
  headers: {
    Accept: "application/json",
    // "Access-Control-Allow-Origin":"*",
    // "Access-Control-Allow-Methods": "DELETE, POST, GET, OPTIONS",
    // "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Requested-With",
    "X-API-KEY": apiKey,
  },
  timeout: apiRequestTimeOut,
});
const setAuthToken = (token) =>
  api.setHeader("Authorization", "Bearer " + token);
const removeAuthToken = () => api.deleteHeader("Authorization");
const setMultipartHeader = () =>
  api.setHeader("Content-Type", "multipart/form-data");
const removeMultipartHeader = () => api.deleteHeader("Content-Type");

export default api;
export {
  apiKey,
  setAuthToken,
  removeAuthToken,
  setMultipartHeader,
  removeMultipartHeader,
};
