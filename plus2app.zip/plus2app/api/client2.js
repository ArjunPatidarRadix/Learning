// external Libraries
import { create } from "apisauce";

const domain = "https://plus2app.com";
const apiKey = "49a77729-cbcb-4dee-a427-832ac1d573ae";

const apiRequestTimeOut = 20000; // 30 secs

//  Do not change anything after this line if you're not sure about what you're doing.
const api2 = create({
    baseURL: domain + "/wp-json/wp/v2/",
    headers: {
        Accept: "application/json",
        // "Access-Control-Allow-Origin":"*",
        "X-API-KEY": apiKey,
    },
    timeout: apiRequestTimeOut,
});
const setAuthToken = (token) =>
    api2.setHeader("Authorization", "Bearer " + token);
const removeAuthToken = () => api2.deleteHeader("Authorization");
const setMultipartHeader = () =>
    api2.setHeader("Content-Type", "multipart/form-data");
const removeMultipartHeader = () => api2.deleteHeader("Content-Type");

export default api2;
export {
    apiKey,
    setAuthToken,
    removeAuthToken,
    setMultipartHeader,
    removeMultipartHeader,
};
