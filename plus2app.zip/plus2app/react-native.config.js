module.exports = {
    assets: ['./assets/fonts'],
    watchOptions: {
        ignored: [
          /node_modules/,
        ],
    }
};