import React from 'react';
import {useNavigation} from "@react-navigation/native";
import {useStateValue} from "../StateProvider";
import authStorage from "../app/auth/authStorage";
import {Image, ScrollView, StyleSheet, Text, TouchableOpacity, View} from "react-native";
import AppSeparator from "./AppSeparator";
import AppButton from "./AppButton";
import {routes} from "../navigation/routes";
import {__} from "../language/stringPicker";
import Option from "./Option";
import {COLORS} from "../variables/color";
import {FontAwesome} from "@expo/vector-icons";
import AdvertiseWithUsScreen from "../screens/AdvertiseWithUsScreen";

const DrawerMenu = ({close}) => {
        const navigation = useNavigation();
        const [{user, appSettings, business_or_professional}, dispatch] = useStateValue();

        const handleLogout = () => {
            dispatch({
                type: "SET_AUTH_DATA",
                data: {
                    user: null,
                    auth_token: null,
                },
            });
            dispatch({
                type: "SET_BUSINESS_OR_PROFESSIONAL",
                business_or_professional: []
            });
            authStorage.removeUser();
        };

        const getUsername = () => {
            if (!!user.first_name || !!user.last_name) {
                return [user.first_name, user.last_name].join(" ");
            } else {
                return user.username;
            }
        };

        return (
            <ScrollView style={styles.container}>
                {/* UserName Component */}
                {user && (
                    <>
                        <View
                            style={{
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                marginVertical: 10
                            }}>
                            <View style={{
                                flexDirection: 'row',
                                alignItems: 'center',
                            }}>
                                <View style={styles.imageWrap}>
                                    {!user.pp_thumb_url ? (
                                        <FontAwesome
                                            name="camera"
                                            size={20}
                                            color={COLORS.text_gray}
                                        />
                                    ) : (
                                        <Image
                                            source={{uri: user.pp_thumb_url}}
                                            style={styles.image}
                                        />
                                    )}
                                </View>
                                <View style={styles.userNameContainer}>
                                    <Text style={styles.userNameText}>{getUsername()}</Text>
                                </View>
                            </View>

                            <View style={{
                                paddingRight: 30,
                                // backgroundColor: 'red',
                                // paddingTop: 10
                                // paddingVertical: 20,
                            }}>
                                <TouchableOpacity onPress={close} style={{marginBottom: 8}}>
                                    <FontAwesome name={'close'} size={24} color={COLORS.red}/>
                                </TouchableOpacity>
                            </View>
                        </View>
                        <Option
                            key={"account_settings"}
                            title={"Account Settings"}
                            onPress={() => navigation.navigate(routes.editPersonalDetailScreen, {data: user})}
                            item={"Account Settings"}
                            uri={require('../assets/folderIcons/005-user.png')}
                        />
                        <Option
                            key={"my_listing"}
                            title={"My Listings"}
                            onPress={() => navigation.navigate("My Listings")}
                            item={"My Listings"}
                            uri={require('../assets/folderIcons/006-list.png')}
                        />
                        <Option
                            key={"my_payments"}
                            title={"My Payments"}
                            onPress={() => navigation.navigate(routes.paymentsScreen)}
                            item={"My Payments"}
                            uri={require('../assets/folderIcons/004-credit-card.png')}
                        />

                        <View style={{alignItems: "center"}}>
                            <AppSeparator style={{width: "94%"}}/>
                        </View>
                        <View
                            style={{
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                flexDirection: 'row',
                                marginHorizontal: 10,
                                marginVertical: 20
                            }}>
                            <TouchableOpacity
                                onPress={() => navigation.navigate('BusinessProfessional', {directory_id: 498})}
                                style={{
                                    borderRadius: 20,
                                    borderWidth: 1,
                                    padding: 10,
                                    borderColor: COLORS.primary,
                                    backgroundColor: COLORS.primary
                                }}>
                                <Text style={{color: COLORS.white}}>Business Directory</Text>
                            </TouchableOpacity>
                            <TouchableOpacity
                                onPress={() => navigation.navigate('BusinessProfessional', {directory_id: 353})}
                                style={{
                                    borderRadius: 20,
                                    borderWidth: 1,
                                    padding: 10,
                                    borderColor: COLORS.primary,
                                    backgroundColor: COLORS.primary
                                }}>
                                <Text style={{color: COLORS.white}}>Professionals Directory</Text>
                            </TouchableOpacity>
                        </View>

                        <View style={{alignItems: "center"}}>
                            <AppSeparator style={{width: "94%"}}/>
                        </View>
                        {/*{!business_or_professional || business_or_professional.length === 0 && (*/}
                        {/*    <>*/}
                        {/*        <Option*/}
                        {/*            key={"register_business"}*/}
                        {/*            title={"Open Business Profile"}*/}
                        {/*            onPress={() => navigation.navigate("New Business Service", {*/}
                        {/*                category: 498*/}
                        {/*            })}*/}
                        {/*            item={"Your Business"}*/}
                        {/*            uri={require('../assets/folderIcons/003-suitcase.png')}*/}
                        {/*        />*/}
                        {/*        <Option*/}
                        {/*            key={"register_service_provider"}*/}
                        {/*            title={"Open Professional Profile"}*/}
                        {/*            onPress={() => navigation.navigate("New Business Service", {*/}
                        {/*                category: 353*/}
                        {/*            })}*/}
                        {/*            item={"Service Provider"}*/}
                        {/*            uri={require('../assets/folderIcons/003-suitcase.png')}*/}
                        {/*        />*/}
                        {/*    </>*/}
                        {/*)}*/}
                        <Option
                            key={"advertise"}
                            title={"Advertise With Us"}
                            onPress={() => navigation.navigate("AdvertiseWithUsScreen")}
                            item={"Advertise With Us"}
                            uri={require('../assets/folderIcons/008-advertisement.png')}
                        />
                        <Option
                            key={"faq"}
                            title={"FAQ"}
                            onPress={() => navigation.navigate("FAQ")}
                            item={"FAQ"}
                            uri={require('../assets/folderIcons/002-faq.png')}
                        />
                        <Option
                            key={"about_us"}
                            title={"About Plus2App"}
                            onPress={() => navigation.navigate(routes.moreScreen)}
                            item={"About"}
                            uri={require('../assets/folderIcons/007-profile.png')}
                        />
                        <Option
                            key={"rate"}
                            title={"Rate Us"}
                            // onPress={() => navigation.navigate("More")}
                            item={"Rate"}
                            uri={require('../assets/folderIcons/001-rating.png')}
                        />
                        <View style={styles.logOutWrap}>
                            <Option
                                title={__(
                                    "accountScreenTexts.logOutButtonText",
                                    appSettings.lng
                                )}
                                onPress={() => handleLogout()}
                                item={{
                                    id: "log_out",
                                }}
                                uri={require('../assets/folderIcons/010-logout.png')}
                            />
                        </View>
                    </>
                )}

                {/* User logged out component */}
                {!user && (
                    <View>
                        <View style={styles.loginWrap}>
                            <AppButton
                                title={__("accountScreenTexts.loginButtonText", appSettings.lng)}
                                style={styles.loginButton}
                                onPress={() => navigation.navigate(routes.signuploginScreen)}
                            />
                        </View>
                        <View
                            style={{
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                flexDirection: 'row',
                                marginHorizontal: 10,
                                marginVertical: 20
                            }}>
                            <TouchableOpacity
                                onPress={() => navigation.navigate('BusinessProfessional', {directory_id: 498})}
                                style={{
                                    borderRadius: 20,
                                    borderWidth: 1,
                                    padding: 10,
                                    borderColor: COLORS.primary,
                                    backgroundColor: COLORS.primary
                                }}>
                                <Text style={{color: COLORS.white}}>Business Directory</Text>
                            </TouchableOpacity>
                            <TouchableOpacity
                                onPress={() => navigation.navigate('BusinessProfessional', {directory_id: 353})}
                                style={{
                                    borderRadius: 20,
                                    borderWidth: 1,
                                    padding: 10,
                                    borderColor: COLORS.primary,
                                    backgroundColor: COLORS.primary
                                }}>
                                <Text style={{color: COLORS.white}}>Professionals Directory</Text>
                            </TouchableOpacity>
                        </View>
                        <Option
                            key={"advertise"}
                            title={"Advertise With Us"}
                            onPress={() => navigation.navigate("AdvertiseWithUsScreen")}
                            item={"Advertise With Us"}
                            uri={require('../assets/folderIcons/008-advertisement.png')}
                        />
                        <Option
                            key={"faq"}
                            title={"FAQ"}
                            onPress={() => navigation.navigate("FAQ")}
                            item={"FAQ"}
                            uri={require('../assets/folderIcons/002-faq.png')}
                        />
                        <Option
                            key={"about_us"}
                            title={"About Plus2App"}
                            onPress={() => navigation.navigate("More")}
                            item={"About"}
                            uri={require('../assets/folderIcons/007-profile.png')}
                        />
                        <Option
                            key={"rate"}
                            title={"Rate Us"}
                            // onPress={() => navigation.navigate("More")}
                            item={"Rate"}
                            uri={require('../assets/folderIcons/001-rating.png')}
                        />
                    </View>
                )}
                {/* Account Options Flatlist */}
            </ScrollView>
        );
    }
;

const styles = StyleSheet.create({
    container: {
        backgroundColor: COLORS.white,
        flex: 1,
    },
    headerMain: {
        alignItems: "center",
        flex: 1,
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: "bold",
        color: COLORS.white,
    },
    headerWrap: {
        backgroundColor: COLORS.primary,
        paddingHorizontal: "3%",
        flexDirection: "row",
        height: 50,
        alignItems: "center",
        justifyContent: "space-between",
    },
    loginButton: {
        paddingVertical: 10,
        borderRadius: 50,
    },
    loginWrap: {
        flexDirection: "row",
        paddingHorizontal: "3%",
        marginVertical: 40,
        alignItems: "center",
        justifyContent: "space-evenly",
    },
    logOutWrap: {
        paddingBottom: 50,
    },
    optionsContainer: {
        flex: 1,
    },
    userNameContainer: {
        paddingHorizontal: 15,
        paddingVertical: 20,
    },
    userNameText: {
        fontSize: 20,
        color: "#444",
        fontFamily: "Poppins Bold"
    },
    imageWrap: {
        height: 50,
        width: 50,
        borderRadius: 30,
        overflow: "hidden",
        backgroundColor: COLORS.bg_dark,
        marginLeft: 15
    },
    image: {
        height: 50,
        width: 50,
        resizeMode: "cover",
    },
});


export default DrawerMenu;
