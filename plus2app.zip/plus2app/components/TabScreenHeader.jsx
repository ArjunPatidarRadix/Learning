import React, {useState} from "react";
import {View, StyleSheet, Image, TouchableOpacity, Text} from "react-native";

// Vector Fonts
import {FontAwesome} from "@expo/vector-icons";
import {MaterialIcons} from "@expo/vector-icons";
//  Custom Components & Variables
import {COLORS} from "../variables/color";
import {useNavigation} from "@react-navigation/native";
import {routes} from "../navigation/routes";
import {useStateValue} from "../StateProvider";
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons'
// eslint-disable-next-line no-undef
// const headerLogoURL = require("../assets/PLUS2APP-LOGO.png");
const headerLogoURL = require("../assets/LOGO-03.png");
const TabScreenHeader = ({
                             right,
                             style,
                             left,user,
                             onLeftClick,
                             drawer,
                             showDrawer,
                         }) => {
    const navigation = useNavigation();
    const [{ios}] = useStateValue();
    return (
        <View style={[styles.container, style]}>
            <Image
                resizeMode="contain"
                source={headerLogoURL}
                style={{height: 50, width: 130, resizeMode: "contain"}}
            />
            {right ? (
                <TouchableOpacity style={styles.headerRight}
                                  onPress={() => navigation.navigate(routes.signuploginScreen)}>
                    <View style={{
                        backgroundColor: COLORS.black,
                        width: 50,
                        height: ios ? 40 : 40,
                        paddingVertical: 5,
                        borderRadius: 50,
                        justifyContent: "center"
                    }}>
                        <Text style={{
                            color: COLORS.white,
                            textAlign: "center",
                            fontFamily: "Poppins Regular",
                            fontSize: 8
                        }}>Login/Signup</Text>
                    </View>
                </TouchableOpacity>)
                :
                user==undefined||user==null?null:<TouchableOpacity style={styles.headerRight}
                                  onPress={() => navigation.navigate(routes.editPersonalDetailScreen, {data: user})}>
                    
                        <MaterialCommunityIcons 
                        name="account-circle-outline" size={35} color="red" />
                   
                </TouchableOpacity>
            }
            {left && (
                <TouchableOpacity style={styles.headerLeft} onPress={onLeftClick}>
                    <MaterialIcons name="arrow-back" size={24} color={COLORS.black}/>
                </TouchableOpacity>
            )}
            {drawer && (
                <TouchableOpacity style={styles.drawerLeft} onPress={showDrawer}>
                    <View style={styles.round}>
                        {/* <MaterialIcons name="sort" size={25} 
                        color={COLORS.gray}/> */}
                        <Image style={{width:25,height:25}} resizeMode='contain' source={require('../assets/drawerIc.png')}/>
                    </View>
                </TouchableOpacity>
            )}
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        backgroundColor: COLORS.white,
        height: 80,
        alignItems: "center",
        justifyContent: "center",
        overflow: "hidden",
    },
    headerLeft: {
        position: "absolute",
        left: "4%",
    },
    drawerLeft: {
        position: "absolute",
        left: "4%",
        width: 50,
    },
    headerRight: {
        position: "absolute",
        right: "4%",
    },
    round: {
        backgroundColor: 'transparent',
        padding: 8,
        borderRadius: 30,
        alignItems: "center"
    }
});

export default TabScreenHeader;
