import React, { useEffect, useState } from "react";
import {
  View,
  StyleSheet,
  Image,
  TouchableWithoutFeedback,
  Alert,
  TouchableOpacity,
  Modal,
  Text,
  Dimensions,
} from "react-native";
import {Platform} from "react-native";
import { Button, Paragraph, Dialog, Portal, Provider } from 'react-native-paper';
// import { TouchableWithoutFeedback } from "react-native-gesture-handler";
// Expo Libraries
import * as ImagePicker from "expo-image-picker";
import { Video } from 'expo-av';
import * as DocumentPicker from 'expo-document-picker';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import * as FileSystem from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import { Ionicons } from "@expo/vector-icons";

// Vector Icons
import { FontAwesome } from "@expo/vector-icons";

// Custom Component & Variables
import { COLORS } from "../variables/color";
import AppTextButton from "./AppTextButton";
import { useStateValue } from "../StateProvider";
import { __ } from "../language/stringPicker";

const { width: deviceWidth } = Dimensions.get("screen");
const { width: windowWidth, height: windowHeight } = Dimensions.get("window");

const ImageInput = ({
  imageUri,
  onChangeImage,
  drag,
  active,
  addingImage,
  closePhotoModal,
  display,
  mediaType,
}) => {
  const [{ appSettings }] = useStateValue();
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    if (!addingImage) {
      return;
    }
    setModalVisible(true);
  }, [addingImage]);

  const requestGalleryParmission = async () => {
    const { granted } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!granted)
      alert(
        __("imageInputTexts.ifImageLibraryPermissionDenied", appSettings.lng)
      );
    else handleSelectGalleryImage();
  };
  const requestCameraParmission = async () => {
    const { granted } = await ImagePicker.requestCameraPermissionsAsync();
    if (!granted)
      alert(__("imageInputTexts.ifCameraPermissionDenied", appSettings.lng));
    else handleSelectCameraImage();
  };
  const handleSelectGalleryImage = async () => {
    // if (Platform.OS === "android") {
    //   setModalVisible((preVodalVisible) => !preVodalVisible);
    // }
    let mTypes = ImagePicker.MediaTypeOptions.Images;
    if(mediaType === 'Videos') {
      mTypes = ImagePicker.MediaTypeOptions.Videos;
    }
    if (Platform.OS === 'web') {
      try {
        const result = await ImagePicker.launchImageLibraryAsync({
          mediaTypes: mTypes,
          allowsEditing: true,
          base64: false,
          quality: 0.5,
          videoMaxDuration: 300,
        });
        if (!result.cancelled) {
          // if (Platform.OS === "ios") {
          setModalVisible(false);
          // }

          // console.log(result);
          // const base64Code = result.uri.split("data:image/png;base64,")[1];
          // console.log(base64Code);
          // const filename = FileSystem.documentDirectory + "some_unique_file_name.png";
          // await FileSystem.writeAsStringAsync(filename, base64Code, {
          //   encoding: FileSystem.EncodingType.Base64,
          // });
          // const mediaResult = await MediaLibrary.saveToLibraryAsync(filename);
          // console.log(mediaResult);

          if(result.duration <= 300000) {
            onChangeImage(result.uri);
          }
          else {
            onChangeImage(null);
          }      
        }
      } catch (error) {
        // TODO add error storing
        setModalVisible((modalVisible) => !modalVisible);
      }
    } else {
      try {
        const result = await ImagePicker.launchImageLibraryAsync({
          mediaTypes: mTypes,
          allowsEditing: true,
          quality: 0.5,
          videoMaxDuration: 300,
        });
        
        if (!result.cancelled) {
          // if (Platform.OS === "ios") {
          setModalVisible(false);
          // }
          if(result.type == 'image') {
            onChangeImage(result.uri);
          }
          else {
            if(result.duration <= 300000) {
              onChangeImage(result.uri);
            }
            else {
              onChangeImage(null);
            }     
          }               
        }
      } catch (error) {
        // TODO add error storing
        setModalVisible((modalVisible) => !modalVisible);
      }
    }
  };
  const handleSelectCameraImage = async () => {
    // if (Platform.OS === "android") {
    //   setModalVisible((prevModalVisible) => !prevModalVisible);
    // }
    try {
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        quality: 0.5,
        videoMaxDuration: 300,
      });
      if (!result.cancelled) {
        // if (Platform.OS === "ios") { 
        setModalVisible(false);
        // }
        if(result.duration <= 300000) {
          onChangeImage(result.uri);
        }
        else {
          onChangeImage(null);
        }      
      }
    } catch (error) {
      // TODO add error storing
      setModalVisible((modalVisible) => !modalVisible);
    }
  };

  const [visible, setVisible] = React.useState(false);
  const showDialog = () => setVisible(true);
  const hideDialog = () => setVisible(false);
  const yesDelete = () => {
    onChangeImage(null);
    setVisible(false);
  }

  const handleDelete = () => {

    if (Platform.OS === 'web') {
      showDialog();
    } else {
      Alert.alert(
        __("imageInputTexts.deleteMessageHeader", appSettings.lng),
        __("imageInputTexts.deletePrompt", appSettings.lng),
        [
          { text: __("imageInputTexts.noButton", appSettings.lng) },
          {
            text: __("imageInputTexts.yesButton", appSettings.lng),
            onPress: () => onChangeImage(null),
          },
        ]
      );
    }
  };
  const handlePress = () => {
    // if (!imageUri) setModalVisible((modalVisible) => !modalVisible);
  };

  return (
    <>
      {/* <TouchableWithoutFeedback onPress={handlePress} onLongPress={drag}> */}
        <View
          style={[styles.container, { display: display ? "flex" : "none" }]}
        >
          {active && <View style={styles.activeOverlay} />}
          {!imageUri && (
            // <Video
            //   source={{ uri: imageUri }}
            //   style={styles.image}
            //   shouldPlay
            //   isMuted={false}
            //   isLooping
            //   resizeMode="contain"
            //   useNativeControls
            //   usePoster={true}
            // />
            <FontAwesome name="camera" size={30} color={COLORS.text_gray} />
          )}
          {imageUri && mediaType == 'Videos' && (
            <Video
              source={{ uri: imageUri }}
              style={styles.image}   
              shouldPlay={false}
              isMuted={false}
              isLooping
              resizeMode="contain"
              useNativeControls
              usePoster={true}
            />
            // <Image source={{ uri: imageUri }} style={styles.image} />
          )}
          {imageUri && mediaType == 'Images' && (            
            <Image source={{ uri: imageUri }} style={styles.image} />
          )}
        </View>
      {/* </TouchableWithoutFeedback> */}
      {/* {imageUri && ( */}
        <TouchableOpacity style={styles.deleteImgWrap} onPress={handleDelete}>
          <View
            style={{ height: 3, width: 10, backgroundColor: COLORS.white }}
          />
        </TouchableOpacity>
      {/* )} */}
      <Modal animationType="fade" transparent={true} visible={modalVisible}>
        <TouchableWithoutFeedback
          onPress={() => {
            setModalVisible((modalVisible) => !modalVisible);
            closePhotoModal();
          }}
        >
          <View style={styles.modalOverlay} />
        </TouchableWithoutFeedback>
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <View style={styles.modalTitleWrap}>
              <Text style={styles.modalTitle}>
                {__("imageInputTexts.addPhoto", appSettings.lng)}
              </Text>
            </View>
            <View style={styles.contentWrap}>
              <TouchableOpacity
                style={styles.libraryWrap}
                onPress={() => requestCameraParmission()}
              >
                <FontAwesome
                  name="camera-retro"
                  size={40}
                  color={COLORS.primary}
                />
                <Text style={styles.libraryText}>
                  {__("imageInputTexts.takePhoto", appSettings.lng)}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.libraryWrap}
                onPress={() => requestGalleryParmission()}
              >
                <Ionicons name="md-images" size={40} color={COLORS.primary} />
                <Text style={styles.libraryText}>
                  {__("imageInputTexts.fromGallery", appSettings.lng)}
                </Text>
              </TouchableOpacity>
            </View>
            <AppTextButton
              style={styles.cancelButton}
              title={__("imageInputTexts.cancelButtonTitle", appSettings.lng)}
              onPress={() => {
                setModalVisible((modalVisible) => !modalVisible);
                closePhotoModal();
              }}
            />
          </View>
        </View>
      </Modal>
      <Provider>
        <View>
          {/* <Button onPress={showDialog}>Show Dialog</Button> */}
          <Portal>
            <Dialog visible={visible} onDismiss={hideDialog} style={styles.centeredView}>
              <Dialog.Title>Delete?</Dialog.Title>
              {/* <Dialog.Content>
                <Paragraph>Delete?</Paragraph>
              </Dialog.Content> */}
              <Dialog.Actions>
                <Button onPress={hideDialog}>No</Button>
                <Button onPress={yesDelete}>Yes</Button>
              </Dialog.Actions>
            </Dialog>
          </Portal>
        </View>
      </Provider>
    </>
  );
};

const styles = StyleSheet.create({
  activeOverlay: {
    height: "100%",
    width: "100%",
    backgroundColor: COLORS.bg_primary,
    opacity: 0.3,
    position: "absolute",
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    elevation: 6,
  },
  cancelButton: {
    marginTop: 20,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  container: {
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
    height: deviceWidth * 0.2,
    width: deviceWidth * 0.2,
    marginRight: deviceWidth * 0.04,
  },
  contentWrap: {
    flexDirection: "row",
    alignItems: "center",
  },
  deleteImgWrap: {
    position: "absolute",
    height: 18,
    width: 18,
    borderRadius: 9,
    top: "20%",
    right: 7,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: COLORS.red,
  },
  image: {
    height: "100%",
    width: "100%",
  },
  libraryText: {
    fontSize: 16,
    color: COLORS.text_gray,
    marginVertical: 10,
  },
  libraryWrap: {
    alignItems: "center",
    marginHorizontal: 15,
  },
  modalOverlay: {
    position: "absolute",
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: "rgba(0,0,0,0.2)",
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: COLORS.text_gray,
    marginBottom: 25,
  },
  modalView: {
    // margin: 20,
    backgroundColor: "white",
    borderRadius: 5,
    paddingVertical: 30,
    paddingHorizontal: 15,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
});

export default ImageInput;
