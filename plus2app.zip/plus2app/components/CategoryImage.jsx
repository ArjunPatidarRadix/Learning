import React from "react";
import { View, StyleSheet, Image } from "react-native";

const CategoryImage = ({ uri, size, tintColor }) => {
  return (
    <View
      style={{
        height: size,
        width: size,
        overflow: "hidden",
      }}
    >
      <Image
      resizeMode='contain'
        source={{ uri: uri }}
        style={{ height: size, width: size, tintColor:tintColor}}
        tintColor={tintColor}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {},
});

export default CategoryImage;
