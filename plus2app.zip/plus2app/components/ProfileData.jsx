import React from "react";
import { View, Text, StyleSheet } from "react-native";

// Custom Components & Constants
import { COLORS } from "../variables/color";

const ProfileData = ({ label, value }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.rowLabel}>{label}</Text>
      <Text style={styles.rowValue}>{value}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 10,
  },
  rowLabel: {
    color: COLORS.text_gray,
    textTransform: "capitalize",
    fontFamily: "Poppins Regular"
  },
  rowValue: {
    color: COLORS.black,
    fontFamily: "Poppins Regular"
  },
});

export default ProfileData;
