import React from "react";
import {StyleSheet, TouchableOpacity, Text} from "react-native";

// Custom Components
import {COLORS} from "../variables/color";

const AppTextButton = ({title, style, textStyle, onPress, disabled}) => {
    return (
        <TouchableOpacity
            onPress={onPress}
            style={[styles.button, style]}
            disabled={disabled}
        >
            <Text
                style={[
                    styles.text,
                    textStyle,
                    {color: disabled ? COLORS.button.disabled : COLORS.button.active},
                ]}
            >
                {title}
            </Text>
        </TouchableOpacity>
    );
};

const styles = StyleSheet.create({
    button: {
        display: "flex",
        justifyContent: "center",
    },
    text: {
        fontSize: 16,
    },
});

export default AppTextButton;
