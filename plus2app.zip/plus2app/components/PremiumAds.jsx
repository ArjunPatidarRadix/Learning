import React, { useState, useEffect } from "react";
import {
  Dimensions,
  Image,
  TouchableOpacity,
  View,
  Linking,
} from "react-native";
import FadeCarousel from "rn-fade-carousel";
import { useStateValue } from "../StateProvider";

import {
  AdMobBanner,
  AdMobInterstitial,
  PublisherBanner,
  AdMobRewarded,
  setTestDeviceIDAsync,
} from "expo-ads-admob";
import Constants from "expo-constants";

const { width: screenWidth } = Dimensions.get("screen");

// Is a real device and running in production.

const PremiumAds = ({ admob }) => {
  const [{ premium_ads }, dispatch] = useStateValue();

  const [adsSlides, setAdsSlides] = useState([]);
  // const testID = 'B5A3AEB099A9FF367CEE2B4FFCB3C0CC';
  const testID = "ca-app-pub-3940256099942544/6300978111";
  const productionID =
    Platform.OS == "ios"
      ? "ca-app-pub-1801380919837019/9536406607"
      : "ca-app-pub-1801380919837019/6328607572";
  const adUnitID = Constants.isDevice && !__DEV__ ? productionID : testID;

  const setDeviceID = async () => {
    await setTestDeviceIDAsync("EMULATOR");
  };

  useEffect(() => {
    setDeviceID();
  }, []);

  useEffect(() => {
    if (Array.isArray(premium_ads)) {
      const newSildes = premium_ads.map((item, index) => {
        return (
          <TouchableOpacity
            onPress={() => Linking.openURL(getAtIndex(index - 1).name.adurl)}
          >
            <View
              style={{
                backgroundColor: "#fff",
                width: screenWidth - 30,
                height: 250,
                padding: 0,
                marginHorizontal: 5,
                marginTop: 0,
              }}
            >
              <Image
                source={{ uri: item?.name?.thumbimg }}
                style={{
                  width: screenWidth - 30,
                  height: 250,
                  backgroundColor: "#fff",
                }}
                resizeMode="cover"
                key={index}
              />
            </View>
          </TouchableOpacity>
        );
      });
      setAdsSlides(newSildes);
    }
  }, [premium_ads]);

  let currentIndex = 0;

  function getAtIndex(i) {
    if (i === 0) {
      return premium_ads[currentIndex];
    } else if (i < 0) {
      return premium_ads[
        (currentIndex + premium_ads.length + i) % premium_ads.length
      ];
    } else if (i > 0) {
      return premium_ads[(currentIndex + i) % premium_ads.length];
    }
  }

  const bannerError = async (error) => {
    // console.log(';;;;', error)
  };

  return admob == false ? (
    <FadeCarousel
      elements={adsSlides}
      fadeDuration={5000}
      stillDuration={2000}
      containerStyle={{
        flex: 1,
        backgroundColor: "#fff",
      }}
      start={true}
    />
  ) : (
    <View
      style={{
        flex: 1,
        marginBottom: 15,
        backgroundColor: "#fff",
      }}
    >
      <AdMobBanner
        style={{
          backgroundColor: "#fff",
          width: screenWidth - 20,
          padding: 0,
          marginHorizontal: 5,
          marginTop: 0,
        }}
        bannerSize="fullBanner"
        adUnitID={testID} // Test ID, Replace with your-admob-unit-id
        servePersonalizedAds={false} // true or false
        onDidFailToReceiveAdWithError={bannerError}
      />
    </View>
  );
};

export default PremiumAds;
