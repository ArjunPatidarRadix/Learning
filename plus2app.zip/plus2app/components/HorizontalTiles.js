import React,{useRef} from 'react'
import {Animated,Dimensions,ScrollView,StyleSheet, View,Text} from 'react-native'
import { TouchableOpacity } from 'react-native-gesture-handler';
import CategoryImage from './CategoryImage';
import CategoryIcon from './CategoryIcon';
import { COLORS } from '../variables/color';
import { decodeString } from '../helper/helper';
import { ScreenWidth } from 'react-native-elements/dist/helpers';
const {width} = Dimensions.get('window')
const itemWidth = (width/3)*2;
const padding = (width-itemWidth)/2;
const offset = itemWidth;

export default function HorizontalTiles({arr,onPress}){
    const scrollX = useRef(new Animated.Value(0)).current;

    return(
        <ScrollView horizontal
        pagingEnabled
        decelerationRate='fast'
        contentContainerStyle={styles.scrollview}
        showsHorizontalScrollIndicator={false}
        snapToInterval={offset}
        onScroll={Animated.event([{nativeEvent:{contentOffset:{x:scrollX}}}],{useNativeDriver:false})}
        >
        {
            arr.map((x,i)=>(
                <Item onPress={() => onPress(x)} key={x} item={x} i={i} scrollX={scrollX}/>
            ))
        }</ScrollView>
    )
}

 function Item({i,scrollX,onPress,item}){
    const scale = scrollX.interpolate({
        inputRange:[-offset+i*offset,i*offset,offset+i*offset],
        outputRange:[0.75,1,0.75],
    })

    return(
        // <Animated.View style={[styles.item,{transform:[{scale}]}]}/>
        <TouchableOpacity
        onPress={onPress}
        style={{
            alignItems: "center",
            width: (ScreenWidth * 0.985 - 10) / 3,
            padding: 5,
        }}
    >
        <Animated.View
            style={[styles.item,{transform:[{scale}]}]}
        >
            <View
                style={{
                    backgroundColor: "#FFFFFF66",
                    padding: 5,
                    borderRadius: 50,
                    shadowColor: '#a9a9a9',
                    shadowOffset: {
                        width: 0,
                        height: 12,
                    },
                    shadowOpacity: 0.58,
                    shadowRadius: 16.00,
                    elevation: 24,
                }}
            >
                <View
                    style={{
                        backgroundColor: "#FFFFFF",
                        padding: 15,
                        borderRadius: 50,
                    }}
                >
                    {item?.icon?.url ? (
                        <CategoryImage size={35} uri={item.icon.url}/>
                    ) : (
                        <CategoryIcon
                            iconName={item.icon.class}
                            iconSize={35}
                            iconColor={COLORS.primary}
                        />
                    )}
                </View>
            </View>
            <Text
                style={{
                    marginTop: 5,
                    color: COLORS.black,
                    fontSize: 11,
                    textAlign: "center",
                    fontFamily: "Poppins Bold"
                }}
            >
                {decodeString(item.name) === "Skilled Professionals" ? "Skilled \n Professionals" : decodeString(item.name)}
            </Text>
        </Animated.View>
    </TouchableOpacity>
    )
}


const styles = StyleSheet.create({
    scrollview:{
        paddingHorizontal:padding,alignItems:'center'
    },
    item:{
        height:itemWidth,
        width:itemWidth,
        backgroundColor:'darkblue',
        borderRadius:10
    }
})