import React, { useState } from "react";
import {
  Dimensions,
  View,
  Text,
  StyleSheet,
  TouchableWithoutFeedback,
  Image,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from "react-native";
// import {TouchableWithoutFeedback} from "@gorhom/bottom-sheet";
// Vector Fonts
import { FontAwesome, FontAwesome5, Ionicons } from "@expo/vector-icons";

// Custom Components & Constants
import {
  daysAgo,
  decodeString,
  getPrice,
  numFormatter,
} from "../helper/helper";
import { COLORS } from "../variables/color";
import { useStateValue } from "../StateProvider";
import Badge from "./Badge";
import { __ } from "../language/stringPicker";
import ListAdComponent from "./ListAdComponent";
import { routes } from "../navigation/routes";
import { useNavigation } from "@react-navigation/native";
import Stars from "react-native-stars";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import api, { removeAuthToken, setAuthToken } from "../api/client";

const { width: screenWidth } = Dimensions.get("screen");
const listingCardFallbackImageUrl = require("../assets/100x100.png");

const ListingCard = ({
  onPress,
  data,
  is_favourite,
  onFavorite,
  favLoading,
}) => {
  const navigation = useNavigation();
  const [{ user, auth_token, config, ios, appSettings, rtl_support }] =
    useStateValue();
  const [item, setItem] = useState(data);
  const [loading, setLoading] = useState(false);
  const handleChatLoginAlert = () => {
    Alert.alert(
      "",
      "Please login to contact this person",
      [
        {
          text: __(
            "listingDetailScreenTexts.cancelButtonTitle",
            appSettings.lng
          ),
        },
        {
          text: __(
            "listingDetailScreenTexts.loginButtonTitle",
            appSettings.lng
          ),
          onPress: () => navigation.navigate(routes.signuploginScreen),
        },
      ],
      { cancelable: false }
    );
  };
  // const [{ user, config, ios, appSettings }] = useStateValue();
  //
  const getTexonomy = (items) => {
    if (!items?.length) return false;
    return decodeString(items[items.length - 1].name);
  };
  const getBackgroundColor = () => {
    if (!item?.badges?.length > 0) {
      return null;
    } else {
      if (item?.badges?.includes("as-top")) {
        return COLORS.cardBg["is-top"];
      } else if (item?.badges?.includes("is-featured")) {
        return COLORS.cardBg["is-featured"];
      }
    }
  };
  let itemParentCat = 0;

  if (item.categories) {
    if (!!item.categories[0] && item.categories[0].parent !== undefined) {
      itemParentCat = item?.categories[0].parent;
    }
  }

  const addToFavorite = (isFav, listing) => {
    // setDeleteLoading(true);
    // console.log('before', listing)
    setLoading(true);
    setAuthToken(auth_token);
    api
      .post("my/favourites", { listing_id: listing.listing_id })
      .then((res) => {
        console.log(res);
        if (res.ok) {
          let tempObj = new Object(listing);
          tempObj.is_favourite = !listing.is_favourite;
          console.log(tempObj);
          setItem(tempObj);
          // setMyFavs(myFavs.filter((fav) => fav != listing));
          removeAuthToken();
          setLoading(false);

          // setDeleteLoading(false);
        } else {
          removeAuthToken();
          // setDeleteLoading(false);
          setLoading(false);
        }
      });
  };

  return item.listAd ? (
    <ListAdComponent dummy={item.dummy} />
  ) : (
    <View style={{ paddingBottom: 10, flex: 1 }}>
      <TouchableOpacity
        onPress={onPress}
        style={{
          shadowColor: "#000",
          shadowRadius: 4,
          shadowOpacity: 0.2,
          shadowOffset: {
            height: 2,
            width: 2,
          },
          flex: 1,
        }}
      >
        <View
          style={[
            styles.featuredItemWrap,
            {
              backgroundColor: "#FFFFFF",
              // flex: 1,
              zIndex: 999,
              shadowColor: "#1B314221",
              shadowRadius: 4,
              shadowOpacity: 0.2,
              shadowOffset: {
                height: 2,
                width: 2,
              },
              overflow: "visible",
              borderRadius: 20,
              height: 330,
            },
          ]}
        >
          {item?.badges?.includes("is-bump-up") && (
            <View style={styles.badgeSection}>
              <Badge badgeName="is-bump-up" type="card" />
            </View>
          )}
          {item?.badges?.includes("is-top") && (
            <View style={styles.badgeSection}>
              <Badge badgeName="is-top" type="card" />
            </View>
          )}
          {item?.badges?.includes("is-sold") && (
            <View
              style={[
                styles.soldOutBadge,
                {
                  top: ios ? "8%" : "6%",
                  left: ios ? "54%" : "56%",
                  width: ios ? "60%" : "60%",
                },
              ]}
            >
              <Text style={styles.soldOutBadgeMessage}>
                {__("listingCardTexts.soldOutBadgeMessage", appSettings.lng)}
              </Text>
            </View>
          )}
          {item?.badges?.includes("is-bump-up") && (
            <View style={styles.bumpUpBadge}></View>
          )}

          <View
            style={[
              styles.featuredItemImageWrap,
              {
                borderBottomWidth: 0, // removed the center border 8 to 0 227295
                position: "relative",
                borderTopLeftRadius: 20,
                borderTopRightRadius: 20,
                borderBottomColor:
                  item?.categories !== undefined
                    ? item?.categories[0]?.parent === 353 ||
                      item?.categories[0]?.parent === 498
                      ? "#574b90"
                      : item?.categories[0]?.parent === 278 ||
                        item?.categories[0]?.parent === 277 ||
                        item?.categories[0]?.parent === 520
                      ? "#1abc9c"
                      : item?.categories[0]?.parent === 340
                      ? "#3498db"
                      : item?.categories[0]?.parent === 76
                      ? "#9b59b6"
                      : item?.categories[0]?.parent === 341
                      ? "#f19066"
                      : item?.categories[0]?.parent === 342
                      ? "#cf6a87"
                      : COLORS.gray
                    : COLORS.gray,
              },
            ]}
          >
            <Image
              style={styles.featuredItemImage}
              source={
                item?.video_thumburl
                  ? {
                      uri: item.video_thumburl,
                    }
                  : item?.images?.length
                  ? {
                      uri: item.images[0].sizes.full.src,
                    }
                  : listingCardFallbackImageUrl
              }
            />
            {item.video_url !== "" && (
              <View
                style={{
                  position: "absolute",
                  top: 0,
                  right: 0,
                  height: "100%",
                  width: "100%",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  backgroundColor: "rgba(0, 0, 0, 0.4)",
                }}
              >
                <Image
                  style={{
                    height: "20%",
                    width: "20%",
                    resizeMode: "stretch",
                  }}
                  source={require("../assets/folderIcons/video-play.png")}
                />
              </View>
            )}
          </View>
          <View style={styles.featuredItemDetailWrap}>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <Text
                style={[
                  styles.featuredItemCategory,
                  { paddingBottom: ios ? 3 : 1 },
                ]}
                numberOfLines={1}
              >
                {getTexonomy(item?.categories)}
              </Text>
              <View>
                {user !== null && (
                  <View>
                    {loading ? (
                      <View style={{ width: 23.5, alignItems: "center" }}>
                        <ActivityIndicator size="small" color="red" />
                      </View>
                    ) : (
                      <TouchableOpacity
                        onPress={() => {
                          addToFavorite(!item.is_favourite, item);
                        }}
                      >
                        <Ionicons
                          name={item.is_favourite ? "heart" : "heart-outline"}
                          size={25}
                          color={COLORS.red}
                        />
                      </TouchableOpacity>
                    )}
                  </View>
                )}
              </View>
            </View>

            {itemParentCat !== 498 &&
              itemParentCat !== 342 &&
              itemParentCat !== 353 && (
                <Text
                  style={[
                    styles.featuredItemTitle,
                    { paddingBottom: ios ? 3 : 1 },
                  ]}
                  numberOfLines={1}
                >
                  {decodeString(item.title)}
                </Text>
              )}

            {itemParentCat !== 76 &&
              (itemParentCat === 498 ||
              itemParentCat === 353 ||
              itemParentCat === 342 ? (
                <Text
                  style={[
                    styles.featuredItemTitle,
                    { paddingBottom: ios ? 3 : 1 },
                  ]}
                  numberOfLines={1}
                >
                  {decodeString(item.title)}
                </Text>
              ) : itemParentCat !== 340 ? (
                <Text style={styles.featuredItemPrice} numberOfLines={1}>
                  {getPrice(
                    config.currency,
                    {
                      pricing_type: item.pricing_type,
                      price_type: item.price_type,
                      price: item.price,
                      max_price: item.max_price,
                    },
                    appSettings.lng
                  )}
                </Text>
              ) : undefined)}

            {itemParentCat === 342 ? (
              !!item.custom_fields &&
              item.custom_fields.length > 0 && (
                <Text
                  style={[{ paddingBottom: ios ? 3 : 1 }]}
                  numberOfLines={1}
                >
                  {/* {item.custom_fields[0].value} */}
                  {""}
                </Text> // commented above line and "" to not show the date field in event 227295
              )
            ) : itemParentCat === 76 ? (
              <Text
                style={[
                  styles.featuredItemTitle,
                  { paddingBottom: ios ? 3 : 1 },
                ]}
                numberOfLines={1}
              >
                {""}
              </Text> // Removed above line "Job Deadline here" and added "" 227295
            ) : (
              <Text></Text>
            )}

            {/*{!!storeData.review.average && (*/}
            <View style={styles.storeRatingWrap}>
              <View
                style={{
                  alignItems: "center",
                  flexDirection: "row",
                  justifyContent: "space-between",
                }}
              >
                <View>
                  {(!!item?.contact?.locations?.length ||
                    !!item?.contact?.geo_address) && (
                    <>
                      {config.location_type === "local" ? (
                        <>
                          {!!item?.contact?.locations?.length && (
                            <View
                              style={[
                                styles.featuredItemLocationWrap,
                                { paddingBottom: ios ? 5 : 3 },
                              ]}
                            >
                              <FontAwesome5
                                name="map-marker-alt"
                                size={10}
                                color={COLORS.text_gray}
                              />
                              <Text style={styles.featuredItemLocation}>
                                {getTexonomy(item.contact.locations)}
                              </Text>
                            </View>
                          )}
                        </>
                      ) : (
                        <>
                          {!!item?.contact?.geo_address && (
                            <View
                              style={[
                                styles.featuredItemLocationWrap,
                                { paddingBottom: ios ? 5 : 3 },
                              ]}
                            >
                              <FontAwesome5
                                name="map-marker-alt"
                                size={10}
                                color={COLORS.text_gray}
                              />
                              <Text
                                style={styles.featuredItemLocation}
                                numberOfLines={1}
                              >
                                {decodeString(item.contact.geo_address)}
                              </Text>
                            </View>
                          )}
                        </>
                      )}
                    </>
                  )}
                </View>
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    marginVertical: 3,
                  }}
                >
                  <View style={styles.iconWrap}>
                    <FontAwesome5
                      name="eye"
                      size={13}
                      color={COLORS.text_gray}
                    />
                  </View>
                  <Text style={styles.listingCardText}>
                    {numFormatter(item?.view_count)}
                  </Text>
                </View>
              </View>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    </View>
  );
};
const styles = StyleSheet.create({
  badgeSection: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
    position: "absolute",
    top: 0,
    left: 2,
    zIndex: 1,
    margin: 2,
  },
  badgeStyle: {
    padding: 3,
    elevation: 5,
  },
  badgeTextStyle: {
    color: COLORS.white,
    fontSize: 12,
    fontFamily: "Poppins Regular",
  },
  bumpUpBadge: {
    height: 20,
    width: 20,
    backgroundColor: COLORS.badges["is-bump-up"],
    alignItems: "center",
    justifyContent: "center",
    position: "absolute",
  },
  container: {},
  featuredListingTop: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: "3%",

    marginVertical: 10,
  },
  featuredItemCategory: {
    fontSize: 12,
    color: COLORS.text_gray,
    fontFamily: "Poppins Regular",
  },
  featuredItemDetailWrap: {
    // alignItems: "flex-start",
    paddingHorizontal: 15,
    paddingVertical: 10,
    // backgroundColor: 'red',
    overflow: "hidden",
    flex: 1,
  },
  featuredItemImage: {
    height: "100%",
    width: "100%",
    resizeMode: "stretch",
  },
  featuredItemImageWrap: {
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
    width: "100%",
    height: screenWidth * 0.455,
    // borderTopRightRadius: 14.95,
    // borderTopLeftRadius: 14.95
  },
  featuredItemLocation: {
    color: COLORS.text_gray,
    fontSize: 12,
    paddingHorizontal: 5,
    fontFamily: "Poppins Regular",
  },
  featuredItemLocationWrap: {
    flexDirection: "row",
    alignItems: "center",
    paddingTop: 2,
  },
  featuredItemPrice: {
    color: COLORS.primary,
    fontSize: 14.5,
    fontWeight: "bold",
  },
  featuredItemTitle: {
    fontSize: 13.5,
    color: COLORS.text_dark,
    fontFamily: "Poppins Bold",
  },
  featuredItemWrap: {
    marginHorizontal: screenWidth * 0.015,
    overflow: "hidden",
    // borderRadius: 14.95,
    marginBottom: screenWidth * 0.03,
    width: screenWidth * 0.455,
    elevation: 4,
    // padding: 5,
  },
  soldOutBadge: {
    position: "absolute",
    backgroundColor: COLORS.primary,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 3,
    transform: [{ rotate: "45deg" }],

    flex: 1,
    elevation: 7,
    zIndex: 20,
    shadowColor: "#000",
    shadowRadius: 4,
    shadowOpacity: 0.2,
    shadowOffset: {
      height: 2,
      width: 2,
    },
  },
  soldOutBadgeMessage: {
    color: COLORS.white,
    fontSize: 11,
    textTransform: "uppercase",
    fontFamily: "Poppins Regular",
  },
  iconWrap: {
    width: 30,
    alignItems: "center",
    padding: 3,
    // backgroundColor: "#DDE9F6"
  },
  listingCardText: {
    fontSize: 12,
    color: COLORS.text_gray,
    // backgroundColor: "#ECF2F9",
    // paddingLeft: 0,
    paddingVertical: 2,
  },
  storeRatingWrap: {
    // position: "absolute",
    // backgroundColor: 'yellow',
    // flexDirection: 'row',
    justifyContent: "flex-end",
    // alignItems: 'baseline',
    flex: 1,
    width: "100%",
    // alignContent: 'center'
  },
});

export default ListingCard;
