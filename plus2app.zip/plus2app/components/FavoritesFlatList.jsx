import React from "react";
import {
    View,
    StyleSheet,
    Text,
    Image,
    TouchableOpacity,
    TouchableWithoutFeedback, Dimensions,
} from "react-native";

// External Libraries
import moment from "moment";

// Vector Icons
import {FontAwesome5} from "@expo/vector-icons";
import {MaterialCommunityIcons} from "@expo/vector-icons";
import {FontAwesome} from "@expo/vector-icons";

// Custom Components
import {COLORS} from "../variables/color";
import {getPrice, decodeString, numFormatter} from "../helper/helper";
import {useStateValue} from "../StateProvider";
import {__} from "../language/stringPicker";
import Stars from "react-native-stars";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";

const favouritesItemfallbackImageUrl = "../assets/200X150.png";


const {width: screenWidth, height: screenHeight} = Dimensions.get("screen");
const getTexonomy = (items) => {
    if (!items?.length) return false;
    return decodeString(items[items.length - 1].name);
};
const FavoritesFlatList = ({onDelete, item, onClick}) => {
    const [{config, ios, appSettings}] = useStateValue();
    const getTaxonomy = (data) => {
        if (data) {
            return decodeString(data);
        } else {
            return "";
        }
    };
    const getImageURL = () => {
        if (item.images.length) {
            return item.images[0].sizes.thumbnail.src;
        }
    };
    return (
        <View>
            <View style={{
                height: 80,
                bottom: 10,
                backgroundColor: COLORS.white,
                opacity: ios ? .5 : .99,
                elevation: 2,
                overflow: "visible",
                width: screenWidth * 0.7,
                alignSelf: "center",
                position: "absolute",
                marginHorizontal: screenWidth * 0.015,
                borderRadius: 24,
                padding: 5,
                shadowColor: "#000",
                shadowRadius: 4,
                shadowOpacity: 0.2,
                shadowOffset: {
                    height: 2,
                    width: 2,
                },
            }}/>
            <View style={styles.wrapper}>
                <View style={styles.listAd}>
                    <TouchableWithoutFeedback onPress={onClick}>
                        <View style={styles.imageWrap}>
                            <Image
                                style={styles.image}
                                source={
                                    item.images.length
                                        ? {
                                            uri: getImageURL(),
                                        }
                                        // : require(favouritesItemfallbackImageUrl)
                                        : {
                                            uri: favouritesItemfallbackImageUrl,
                                        }
                                }
                            />
                        </View>
                    </TouchableWithoutFeedback>
                    <View style={styles.details}>
                        <View style={styles.detailsLeft}>
                            <TouchableWithoutFeedback onPress={onClick}>
                                <View style={{flex: 1, justifyContent: "flex-start"}}>
                                    <View style={styles.detailsLeftRow}>
                                        <Text style={styles.price} numberOfLines={1}>
                                            {getPrice(
                                                config.currency,
                                                {
                                                    pricing_type: item.pricing_type,
                                                    price_type: item.price_type,
                                                    price: item.price,
                                                    max_price: item.max_price,
                                                },
                                                appSettings.lng
                                            )}
                                        </Text>
                                    </View>
                                    <View style={styles.detailsLeftRow}>

                                        <Text
                                            style={[
                                                styles.featuredItemCategory,
                                                {paddingBottom: ios ? 3 : 1},
                                            ]}
                                            numberOfLines={1}
                                        >
                                            {getTexonomy(item.categories)}
                                        </Text>
                                    </View>
                                    <Text
                                        style={[styles.title, {marginBottom: ios ? 3 : 2}]}
                                        numberOfLines={1}
                                    >
                                        {getTaxonomy(item.title)}
                                    </Text>
                                </View>
                            </TouchableWithoutFeedback>
                        </View>
                        <View style={styles.detailsRight}>
                            <View
                                style={{
                                    flex: 1,
                                    alignItems: "flex-end",
                                    justifyContent: "space-between",
                                }}
                            >
                                <View
                                    style={{
                                        flexDirection: "row",
                                        alignItems: "center",
                                        marginVertical: 3,
                                    }}
                                >
                                    <View style={styles.iconWrap}>
                                        <FontAwesome5
                                            name="eye"
                                            size={12}
                                            color={COLORS.text_gray}
                                        />
                                    </View>
                                    <Text style={styles.listingCardText}>
                                        {numFormatter(item?.view_count)}
                                    </Text>
                                </View>
                            </View>
                            <TouchableOpacity style={styles.iconButton} onPress={onDelete}>
                                <FontAwesome name="trash-o" size={20} color={COLORS.red}/>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
                <View>
                    {/*{!!storeData.review.average && (*/}
                    {/* <View style={styles.rating}>
                        <View style={{alignItems: 'center', flexDirection: "row"}}>
                            <Stars
                                display={3.5}
                                count={5}
                                half={true}
                                starSize={80}
                                fullStar={<Icon name={'star'}
                                                style={{color: COLORS.primary}}
                                                size={15}/>}
                                emptyStar={<Icon name={'star-outline'}
                                                 style={{color: COLORS.primary}}
                                                 size={15}/>}
                                halfStar={<Icon name={'star-half'}
                                                style={{color: COLORS.primary}}
                                                size={15}/>}
                                disabled
                            />

                            <Text style={{
                                fontSize: 10,
                                paddingLeft: 2,
                                fontFamily: "Poppins Regular"
                            }}>3.5</Text>
                        </View>
                    </View> */}
                </View>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    button: {
        backgroundColor: COLORS.green,
        borderRadius: 0,
        paddingVertical: 5,
        paddingHorizontal: 20,
        width: "auto",
    },
    buttonText: {
        fontSize: 12,
        fontFamily: "Poppins Bold"
    },
    buttonWrap: {
        alignItems: "center",
    },
    details: {
        flexDirection: "row",
        justifyContent: "space-between",
        flex: 3,
        alignItems: "center",
    },
    detailsLeft: {
        paddingLeft: "4%",
        flex: 1,
    },
    detailsLeftRow: {
        flexDirection: "row",
        alignItems: "center",
        marginVertical: 2,
    },
    detailsLeftRowText: {
        fontSize: 12,
        fontFamily: "Poppins Bold",
        color: COLORS.text_gray,
    },
    detailsRight: {
        justifyContent: "space-around",
        alignItems: "flex-end",
    },
    iconButton: {
        flex: 1,
        alignItems: "flex-end",
    },
    iconWrap: {
        width: 30,
        alignItems: "center",
        padding: 3,
        backgroundColor: "#DDE9F6"
    },
    image: {
        height: 80,
        width: "100%",
        resizeMode: "cover",
    },
    imageWrap: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 5,
        height: 80,
        // width: 70,
        overflow: "hidden",
    },
    price: {
        fontFamily: "Poppins Bold",
        color: COLORS.primary,
    },
    listAd: {
        width: "100%",
        flexDirection: "row",
        justifyContent: "space-between",
        padding: "3%",
        alignItems: "center",
        marginVertical: 5,
    },
    wrapper: {
        backgroundColor: COLORS.white,
        borderRadius: 24,
        marginBottom: 20,
        padding: 5,
        marginHorizontal: 5,
        elevation: 5,
        shadowColor: "#a9a9a9",
        shadowRadius: 4,
        shadowOpacity: 0.2,
        shadowOffset: {
            height: 0,
            width: 0,
        },
        overflow: "visible"
    },
    title: {
        fontFamily: "Poppins Bold",
        fontSize: 13,
    },
    rating: {
        paddingLeft: "3%",
        paddingBottom: "3%"
    },
    featuredItemCategory: {
        fontSize: 12,
        color: COLORS.text_gray,
        fontFamily: "Poppins Regular"
    },
    listingCardText: {
        fontSize: 12,
        color: COLORS.text_gray,
        backgroundColor: "#ECF2F9",
        paddingHorizontal: 10,
        paddingVertical: 2,
    },
});

export default FavoritesFlatList;
