// External Libraries
import { decode } from "html-entities";
import {__} from "../language/stringPicker";
import moment from "moment";


const helperTexts = {callForPrice: "Call for price"};

const getPrice = (config, priceData, lng) => {
    const price = priceData?.price || 0;
    const max_price = priceData?.max_price || 0;
    const price_type = priceData?.price_type || "fixed";
    const pricing_type = priceData?.pricing_type || "price";

    const symbol = getCurrencySymbol(config);

    if (pricing_type === "disabled") return;
    // if (price_type === "on_call") return helperTexts.callForPrice;
    if (price_type === "on_call") return __("callForPrice", lng || "en");

    if (pricing_type !== "range") {
        let result = "";
        if (config.position === "left") {
            result = symbol + price;
        } else if (config.position === "left_space") {
            result = symbol + " " + price;
        } else if (config.position === "right") {
            result = price + symbol;
        } else {
            result = price + " " + symbol;
        }
        return result;
    } else {
        let result = "";
        if (config.position === "left") {
            result = symbol + price + " - " + symbol + max_price;
        } else if (config.position === "left_space") {
            result = symbol + " " + price + " - " + symbol + " " + max_price;
        } else if (config.position === "right") {
            result = price + symbol + " - " + max_price + symbol;
        } else {
            result = price + " " + symbol + " - " + max_price + " " + symbol;
        }
        return result;
    }
};

const getCurrencySymbol = (config) => {
    // const entities = new Html5Entities();
    return decode(config.symbol);
};

const decodeString = (string) => {
    // const entities = new Html5Entities();
    return decode(string);
};

const stripString = (string) => {
    return string.length > 10 ? string.substring(0, 10) + ".." : string;
}
const numFormatter = (num) => {
    if (num > 999 && num < 1000000) {
        return '+' + (num / 1000).toFixed(1) + 'k'; // convert to K for number from > 1000 < 1 million
    } else if (num > 1000000) {
        return '+' + (num / 1000000).toFixed(1) + 'm'; // convert to M for number from > 1 million
    } else if (num < 900) {
        return num; // if value < 1000, nothing to do
    }
}

const daysAgo = (fromDate) => {
    let CreatedDate = new Date(fromDate.substring(0,10))
    let today = new Date()
    let requiredDiffrentDays

    const oneDay = 24 * 60 * 60 * 1000;
    const diffDays = Math.round(Math.abs((CreatedDate - today) / oneDay));

    if (diffDays >= 360) {
        requiredDiffrentDays = Math.floor(diffDays / 360) == 1 ? `${Math.floor(diffDays / 365)} year ago` : `${Math.floor(diffDays / 365)} years ago`
    } else if (diffDays >= 30) {
        requiredDiffrentDays = Math.floor(diffDays / 30) == 1 ? `${Math.floor(diffDays / 30)} month ago` : `${Math.floor(diffDays / 30)} months ago`
    } else if (diffDays < 30) {
        requiredDiffrentDays = (diffDays == 1 || diffDays == 0) ? `${diffDays} day ago` : `${diffDays} days ago`
    }

    return requiredDiffrentDays;
}

function groupedDays(messages) {
    return messages.reduce((acc, el, i) => {
        const messageDay = moment(el.created_at).format('YYYY-MM-DD');
        if (acc[messageDay]) {
            return { ...acc, [messageDay]: acc[messageDay].concat([el]) };
        }
        return { ...acc, [messageDay]: [el] };
    }, {});
}

function generateItems(messages) {
    const days = groupedDays(messages);
    const sortedDays = Object.keys(days).sort(
        (x, y) => moment(y, 'YYYY-MM-DD').unix() - moment(x, 'YYYY-MM-DD').unix()
    );
    const items = sortedDays.reduce((acc, date) => {
        const sortedMessages = days[date].sort(
            (x, y) => new Date(y.created_at) - new Date(x.created_at)
        ).reverse();
        return acc.concat([...sortedMessages, { type: 'day', date, id: date }]);
    }, []);
    return items;
}
function insertAndShift(arr, from, to) {
    let cutOut = arr.splice(from, 1) [0]; // cut the element at index 'from'
    arr.splice(to, 0, cutOut);            // insert it at index 'to'
}
export {decodeString, getCurrencySymbol, getPrice, stripString, numFormatter, daysAgo, generateItems, insertAndShift};
