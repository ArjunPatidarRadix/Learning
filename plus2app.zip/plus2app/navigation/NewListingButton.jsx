import React from "react";
import { View, StyleSheet, TouchableWithoutFeedback } from "react-native";

// Vector Icons
import { FontAwesome5 } from "@expo/vector-icons";

// Custom Components & Functions
import { COLORS } from "../variables/color";
import { useStateValue } from "../StateProvider";

const NewListingButton = ({ onPress }) => {
  const [{ newListingScreen, user }] = useStateValue();
  return (
    <View
      style={newListingScreen && user ? styles.buttonHidden : styles.button}
    >
      <TouchableWithoutFeedback onPress={onPress}>
        <View style={styles.content}>
              <FontAwesome5 name="plus" size={15} color="#fff" />
        </View>
      </TouchableWithoutFeedback>
    </View>
  );
};

const styles = StyleSheet.create({
  button: {
    bottom: 15,
    left: -6,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: COLORS.primary,
    height: 60,
    width: 60,
    borderRadius: 100,
    transform: [{ rotate: '45deg'}],
    elevation: 24,
    shadowColor: '#a9a9a9',
    shadowOffset: {
      width: 0,
      height: 12,
    },
    shadowOpacity: 0.58,
    shadowRadius: 16.00,
  },
  buttonHidden: {
    alignItems: "center",
  },
  buttonTitle: {
    textTransform: "uppercase",
    fontSize: 9,
  },

  content: {
    transform: [{ rotate: '45deg'}],
  },
});

export default NewListingButton;
