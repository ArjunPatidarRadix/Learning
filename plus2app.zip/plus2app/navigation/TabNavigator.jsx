/* eslint-disable react/display-name */
import { View, Text, TouchableOpacity, ImageBackground } from "react-native";
import * as React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import HomeScreen from "../screens/HomeScreen";
import { __ } from "../language/stringPicker";
import { useStateValue } from "../StateProvider";
import FontAwesome5 from "react-native-vector-icons/FontAwesome";
import { COLORS } from "../variables/color";
import ChatListScreen from "../screens/ChatListScreen";
import MyProfileTabScreen from "../screens/MyProfileTabScreen";
import FavoritesTabScreen from "../screens/FavoriteTabScreen";
import NewListingButton from "./NewListingButton";
import { routes } from "./routes";
import NewListingScreen from "../screens/NewListingScreen";
import NewListingScreenTwo from "../screens/NewListingScreenTwo";

import { createStackNavigator } from "@react-navigation/stack";
import CategoriesListings from "../screens/CategoriesListings";
import AllStores from "../screens/AllStores";
import MyStoreScreen from "../screens/MyStoreScreen";
import AllListingsScreen from "../screens/AllListingsScreen";
import NewBusinessServiceScreen from "../screens/NewBusinessServiceScreen";
import BusinessProfileScreen from "../screens/BusinessProfileScreen";
import SubCategoryDetails from "../screens/SubCategoryDetails";

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

function CustomTabBar({ state, descriptors, navigation }) {
  const focusedOptions = descriptors[state.routes[state.index].key].options;
  const [{ ios, chat_badge }] = useStateValue();

  if (focusedOptions.tabBarVisible === false) {
    return null;
  }

  return (
    <ImageBackground
      source={require("../assets/bottom.png")}
      style={{ width: "100%", zIndex: 2, height: 58 }}
    >
      <View
        style={{
          flexDirection: "row",
          marginHorizontal: 15,
          justifyContent: "space-between",
          height: 20,
        }}
      >
        {state.routes.map((route, index) => {
          const { options } = descriptors[route.key];
          const label =
            options.tabBarLabel !== undefined
              ? options.tabBarLabel
              : options.title !== undefined
              ? options.title
              : route.name;
          const badge = options.tabBarBadge;
          const icon =
            index === 0
              ? "home"
              : index === 1
              ? "heart"
              : index === 2
              ? ""
              : index === 3
              ? "envelope"
              : index === 4
              ? "user"
              : "";

          const isFocused = state.index === index;

          const onPress = () => {
            const event = navigation.emit({
              type: "tabPress",
              target: route.key,
              canPreventDefault: true,
            });

            if (!isFocused && !event.defaultPrevented) {
              navigation.navigate(route.name, { load: 0 });
            }
          };

          const onLongPress = () => {
            navigation.emit({
              type: "tabLongPress",
              target: route.key,
            });
          };

          return (
            <TouchableOpacity
              key={index}
              accessibilityRole="button"
              accessibilityState={isFocused ? { selected: true } : {}}
              accessibilityLabel={options.tabBarAccessibilityLabel}
              testID={options.tabBarTestID}
              onPress={onPress}
              onLongPress={onLongPress}
              style={{
                minHeight: 50,
                justifyContent: "center",
                alignItems: "center",
                top: index === 2 && ios ? -15 : index === 2 && !ios ? -20 : 0,
                left: index === 2 ? 7 : 0,
                display: index === 5 ? "none" : "flex",
              }}
            >
              {index === 3 && chat_badge && (
                <View
                  style={{
                    position: "absolute",
                    top: 0,
                    left: 20,
                    backgroundColor: COLORS.primary,
                    paddingHorizontal: 8,
                    zIndex: 1,
                    borderRadius: 100,
                  }}
                >
                  <Text
                    style={{
                      fontFamily: "Poppins Regular",
                      fontSize: 10,
                      color: COLORS.white,
                    }}
                  >
                    {badge}
                  </Text>
                </View>
              )}
              <FontAwesome5
                name={icon}
                style={{
                  color: isFocused ? COLORS.primary : "#867F9E",
                  paddingTop: 10,
                }}
                size={24}
              />
              {/* {index !== 2 && (
                                <Text style={{
                                    color: isFocused ? COLORS.primary : "#867F9E", bottom: -5,
                                    fontFamily: "Poppins Regular",
                                    fontSize: 13
                                }}>
                                    {label}
                                </Text>
                            )} */}

              {index === 2 && <NewListingButton />}
            </TouchableOpacity>
          );
        })}
      </View>
    </ImageBackground>
  );
}

function HomeStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name={"Home"}
        component={HomeScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="CategoriesListings"
        component={CategoriesListings}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="SubCategoryDetails"
        component={SubCategoryDetails}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="Online Stores"
        component={AllStores}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="My Online Store"
        component={MyStoreScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="All Listings Screen"
        component={AllListingsScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="New Business Service"
        component={NewBusinessServiceScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="Business Profile"
        component={BusinessProfileScreen}
        options={{
          headerShown: false,
        }}
      />
    </Stack.Navigator>
  );
}

function TabStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name={"Prof"}
        component={MyProfileTabScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="Buy Sell"
        component={CategoriesListings}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="Online Stores"
        component={AllStores}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="My Online Store"
        component={MyStoreScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="All Listings Screen"
        component={AllListingsScreen}
        options={{
          headerShown: false,
        }}
      />
      <Tab.Screen
        name={routes.newListingScreenTwo}
        component={NewListingScreenTwo}
      />

      <Stack.Screen
        name="New Business Service"
        component={NewBusinessServiceScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="Business Profile"
        component={BusinessProfileScreen}
        options={{
          headerShown: false,
        }}
      />
    </Stack.Navigator>
  );
}

const AddCategory = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen
        name={routes.newListingScreen}
        component={NewListingScreen}
      />
      <Stack.Screen
        name={routes.newListingScreenTwo}
        component={NewListingScreenTwo}
      />
    </Stack.Navigator>
  );
};

const TabNavigator = () => {
  const [{ chat_badge, appSettings }] = useStateValue();

  return (
    <View style={{ flex: 1, backgroundColor: "#ffffff" }}>
      <Tab.Navigator
        tabBar={(props) => <CustomTabBar {...props} />}
        screenOptions={{
          headerShown: false,
          tabBarShowLabel: true,
          inactiveTintColor: COLORS.black,
          // tabBarActiveTintColor: CategoriesListings ? COLORS.red : COLORS.primary,
          tabBarHideOnKeyboard: true,
          tabBarLabelStyle: {
            fontSize: 12,
          },
          tabBarStyle: {
            height: 70,
            borderTopRightRadius: 20,
            borderTopLeftRadius: 20,
            backgroundColor: COLORS.red,
          },
        }}
      >
        <Tab.Screen name="HomeStack" component={HomeStack} />
        <Tab.Screen
          name={__("tabTitles.favorites", appSettings.lng)}
          component={FavoritesTabScreen}
        />
        <Tab.Screen name={routes.newListingStack} component={AddCategory} />
        <Tab.Screen
          name={"Messages"}
          component={ChatListScreen}
          options={{
            tabBarBadge: chat_badge,
          }}
        />
        <Tab.Screen
          name={__("tabTitles.profile", appSettings.lng)}
          component={TabStack}
        />
      </Tab.Navigator>
    </View>
  );
};

export default TabNavigator;
