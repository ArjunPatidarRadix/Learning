### Change log

= 2.0.1 =
* Fix: Require cycles are allowed, but can result in uninitialized values. Consider refactoring to remove the need for a cycle.
* Fix: Warning: Each child in a list should have a unique "key" prop.
* Fix: Warning: componentWillMount has been renamed, and is not recommended for use...Please update the following components: %s, DrawerLayout

* listing validation error
* Fix: VirtualizedLists should never be nested inside plain ScrollViews with the same orientation - use another VirtualizedList-backed container instead.
* Fix: VirtualizedList: You have a large list that is slow to update
* Fix: Error: Text strings must be rendered within a <Text> component.
* Fix: [Unhandled promise rejection: Error: Geocoder is not running.]
* Fix: Can't perform a React state update on an unmounted component. This is a no-op, but it indicates a memory leak in your application. To fix, cancel all subscriptions and asynchronous tasks in the componentWillUnmount method.

= 2.0.0 =
* TODO: Video upload
* Add: Expo-AV video player

= 1.0.0 =
* initial release
