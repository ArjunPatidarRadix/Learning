/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from "react";
import {
  Keyboard,
  Modal,
  StyleSheet,
  Text,
  View,
  TextInput,
  ScrollView,
  KeyboardAvoidingView,
  ActivityIndicator,
  TouchableOpacity,
  Dimensions,
  Image,
  // AsyncStorage,
} from "react-native";
// import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Facebook from "expo-facebook";
import * as Google from "expo-auth-session/providers/google";

// External Libraries
import { Formik } from "formik";
import * as Yup from "yup";

// Custom Components & Functions
import AppButton from "../components/AppButton";
import AppTextButton from "../components/AppTextButton";
import AppSeparator from "../components/AppSeparator";
import { useStateValue } from "../StateProvider";
import api, { removeAuthToken, setAuthToken } from "../api/client";
import { COLORS } from "../variables/color";
import authStorage from "../app/auth/authStorage";
import FlashNotification from "../components/FlashNotification";
import { __ } from "../language/stringPicker";
import { socialConfig } from "../app/services/socialLoginConfig";
import { routes } from "../navigation/routes";
import { useNavigation } from "@react-navigation/native";
import { FontAwesome5 } from "@expo/vector-icons";
import { getPushNotificationTokenAsync } from "../helper/notification";

const { width: screenWidth, height: screenHeight } = Dimensions.get("screen");
const LoginScreen = () => {
  const navigation = useNavigation();
  const [{ ios, appSettings }, dispatch] = useStateValue();
  const [checkboxToggle, setCheckboxToggle] = useState(false);
  const [validationSchema, setValidationSchema] = useState(
    Yup.object().shape({
      username: Yup.string()
        .required(
          __("loginScreenTexts.formFieldsLabel.username", appSettings.lng) +
            " " +
            __("loginScreenTexts.formValidation.requiredField", appSettings.lng)
        )
        .min(
          3,
          __("loginScreenTexts.formFieldsLabel.username", appSettings.lng) +
            " " +
            __(
              "loginScreenTexts.formValidation.minimumLength3",
              appSettings.lng
            )
        ),
      password: Yup.string()
        .required(
          __("loginScreenTexts.formFieldsLabel.password", appSettings.lng) +
            " " +
            __("loginScreenTexts.formValidation.requiredField", appSettings.lng)
        )
        .min(
          3,
          __("loginScreenTexts.formFieldsLabel.password", appSettings.lng) +
            " " +
            __(
              "loginScreenTexts.formValidation.minimumLength3",
              appSettings.lng
            )
        ),
    })
  );
  const [validationSchema_reset, setValidationSchema_reset] = useState(
    Yup.object().shape({
      user_login: Yup.string()
        .required(
          __("loginScreenTexts.formFieldsLabel.reset", appSettings.lng) +
            " " +
            __("loginScreenTexts.formValidation.requiredField", appSettings.lng)
        )
        .min(
          3,
          __("loginScreenTexts.formFieldsLabel.reset", appSettings.lng) +
            " " +
            __(
              "loginScreenTexts.formValidation.minimumLength3",
              appSettings.lng
            )
        ),
    })
  );
  const [responseErrorMessage, setResponseErrorMessage] = useState();
  const [passResetErrorMessage, setPassResetResponseErrorMessage] = useState();
  const [modalVisible, setModalVisible] = useState(false);
  const [loading, setLoading] = useState(false);
  const [reset_Loading, setReset_Loading] = useState(false);
  const [flashNotification, setFlashNotification] = useState(false);
  const [flashNotificationMessage, setFlashNotificationMessage] = useState();
  const [socialOverlayActive, setSocialOverlayActive] = useState(false);
  const [socialErrorMessage, setSocialErrorMessage] = useState();
  const [activeSocialType, setActiveSocialType] = useState();

  const [icon, setIcon] = useState("eye-slash");
  const [hidePassword, setHidePassword] = useState(true);

  const _changeIcon = () => {
    icon === "eye-slash"
      ? (setIcon("eye"), setHidePassword(false))
      : (setIcon("eye-slash"), setHidePassword(true));
  };

  const handleLogin = async (values) => {
    setResponseErrorMessage();
    setLoading(true);
    Keyboard.dismiss();
    // const pushToken = await getPushNotificationTokenAsync();
    api
      .post("login", {
        username: values.username,
        password: values.password,
      })
      .then((res) => {
        console.log("userrrrr", res);
        if (res.ok) {
          dispatch({
            type: "SET_AUTH_DATA",
            data: {
              user: res.data.user,
              auth_token: res.data.jwt_token,
            },
          });
          authStorage.storeUser(JSON.stringify(res.data));
          setAuthToken(res.data.jwt_token);
          // if (pushToken) {
          // api.post('push-notification/register', {
          //     push_token: pushToken,
          //     events: []
          // })
          //     .then((res) => {
          //         // console.log(res)
          //     })
          //     .catch(error => {
          //         // console.log(error);
          //     })
          // }

          api.get("my/listings").then((res) => {
            console.log(res);
            if (res.ok) {
              const array = res.data.data;
              for (let i = 0; i < array.length; i++) {
                if (array[i]?.categories[0]?.parent === 498) {
                  dispatch({
                    type: "SET_BUSINESS_OR_PROFESSIONAL",
                    business_or_professional: array[i],
                  });
                }
                if (array[i]?.categories[0]?.parent === 353) {
                  dispatch({
                    type: "SET_BUSINESS_OR_PROFESSIONAL",
                    business_or_professional: array[i],
                  });
                }
              }
              removeAuthToken();
            }
          });

          handleSuccess(
            __("loginScreenTexts.loginSuccessMessage", appSettings.lng)
          );
        } else {
          let message = "";
          if (res?.data?.error) message = "Invalid Logins";
          setResponseErrorMessage(
            res?.data?.error_message ||
              message ||
              res?.problem ||
              __("loginScreenTexts.customResponseError", appSettings.lng)
          );
          setLoading(false);
        }
      });
  };
  const handleSuccess = (message) => {
    setFlashNotificationMessage(message);
    setTimeout(() => {
      setFlashNotification(true);
    }, 10);
    setTimeout(() => {
      setFlashNotification(false);
      if (loading) {
        setLoading(false);
      }
      if (socialOverlayActive) {
        setSocialOverlayActive(false);
      }
      setFlashNotificationMessage();
      navigation.navigate("Home");
      // navigation.params
    }, 100);
  };
  const handleError = (message) => {
    setFlashNotificationMessage(message);
    setTimeout(() => {
      setFlashNotification(true);
    }, 3000);
    setTimeout(() => {
      setFlashNotification(false);
      setFlashNotificationMessage();

      if (socialOverlayActive) {
        setSocialOverlayActive(false);
      }
    }, 3000);
  };

  const handleResetSuccess = (message) => {
    setFlashNotificationMessage(message);
    setTimeout(() => {
      setFlashNotification(true);
    }, 100);
    setTimeout(() => {
      setFlashNotification(false);
    }, 2000);
  };

  const handlePassReset = (values) => {
    setPassResetResponseErrorMessage();
    setReset_Loading(true);
    Keyboard.dismiss();
    api
      .post("reset-password", {
        user_login: values.user_login,
      })
      .then((res) => {
        if (res.ok) {
          setReset_Loading(false);
          setModalVisible(false);
          handleResetSuccess(
            __("loginScreenTexts.resetSuccessMessage", appSettings.lng)
          );
        } else {
          setPassResetResponseErrorMessage(
            res?.data?.error_message ||
              res?.data?.error ||
              res?.problem ||
              __("loginScreenTexts.customResponseError", appSettings.lng)
          );
          setReset_Loading(false);
        }
      })
      .catch((error) => {
        alert("Error");
      });
  };

  const handleFacebookLoginPress = () => {
    setSocialErrorMessage();
    setActiveSocialType("facebook");
    setSocialOverlayActive(true);
    loginWithFBReadPermissionAsync();
  };

  const loginWithFBReadPermissionAsync = async () => {
    try {
      await Facebook.initializeAsync({
        appId: socialConfig.facebook.appID,
        appName: socialConfig.facebook.appName,
      });

      const result = await Facebook.logInWithReadPermissionsAsync({
        permissions: ["public_profile", "email"],
      });

      if (result?.type === "success" && result?.token) {
        handleSocialLoginRequest(result.token, "facebook");
      } else {
        setActiveSocialType();
        setSocialOverlayActive(false);
      }
    } catch ({ message }) {
      alert(`Facebook Login Error: ${message}`);
    }
  };

  const handleGoogleLoginPress = () => {
    promptAsync();
    setSocialErrorMessage();
    setActiveSocialType("google");
    setSocialOverlayActive(true);
  };

  const [request, response, promptAsync] = Google.useAuthRequest({
    webClientId: socialConfig.google.web.clientId,
    androidClientId: socialConfig.google.android.clientId,
    expoClientId: socialConfig.google.expoGo.clientId,
    iosClientId: socialConfig.google.iOS.clientId,
  });

  useEffect(() => {
    if (response?.type === "success") {
      const { authentication } = response;

      if (authentication?.accessToken) {
        handleSocialLoginRequest(authentication?.accessToken, "google");
      }
    } else {
      if (activeSocialType) {
        setActiveSocialType();
      }
      if (socialOverlayActive) {
        setSocialOverlayActive(false);
      }
    }
  }, [response]);

  const handleSocialLoginRequest = (access_token, type) => {
    if (!access_token || !type) {
      setSocialOverlayActive(false);
      return true;
    }

    api
      .post("social-login", {
        access_token: access_token,
        type: type,
      })
      .then((res) => {
        if (res.ok) {
          dispatch({
            type: "SET_AUTH_DATA",
            data: {
              user: res.data.user,
              auth_token: res.data.jwt_token,
            },
          });
          authStorage.storeUser(JSON.stringify(res.data));

          handleSuccess(
            __("loginScreenTexts.loginSuccessMessage", appSettings.lng)
          );
          setActiveSocialType();
        } else {
          setSocialErrorMessage(
            res?.data?.error_message ||
              res?.data?.error ||
              res?.problem ||
              __("loginScreenTexts.customResponseError", appSettings.lng)
          );
          handleError(
            res?.data?.error_message ||
              res?.data?.error ||
              res?.problem ||
              __("loginScreenTexts.customResponseError", appSettings.lng)
          );
          setActiveSocialType();
        }
      });
  };

  const handleSocialLoginCancel = () => {
    setActiveSocialType();
    setSocialOverlayActive(false);
  };
  return (
    <KeyboardAvoidingView
      behavior={ios ? "padding" : "height"}
      style={{ flex: 1 }}
      keyboardVerticalOffset={80}
    >
      {/* <Text style={styles.text}>{response?.type}</Text> */}
      <View
        style={[
          styles.loginForm,
          { marginBottom: socialConfig?.enabled ? 20 : 40 },
        ]}
      >
        <Formik
          initialValues={{ username: "", password: "" }}
          onSubmit={handleLogin}
          // validationSchema={validationSchema}
        >
          {({
            handleChange,
            handleSubmit,
            values,
            errors,
            setFieldTouched,
            touched,
          }) => (
            <View style={{ width: "100%", paddingTop: 20 }}>
              <Text
                style={{
                  fontFamily: "Poppins Regular",
                }}
              >
                Username or Email <Text style={{ color: COLORS.red }}>*</Text>
              </Text>
              <View style={styles.inputWrap}>
                <TextInput
                  style={styles.input}
                  onChangeText={handleChange("username")}
                  onBlur={() => setFieldTouched("username")}
                  value={values.username}
                  placeholder={__(
                    "loginScreenTexts.formFieldsPlaceholder.username",
                    appSettings.lng
                  )}
                  autoCorrect={false}
                  onFocus={() => setFieldTouched("username")}
                  autoCapitalize="none"
                />
                <View style={styles.errorFieldWrap}>
                  {touched.username && errors.username && (
                    <Text style={styles.errorMessage}>{errors.username}</Text>
                  )}
                </View>
              </View>
              <Text
                style={{
                  fontFamily: "Poppins Regular",
                }}
              >
                Password <Text style={{ color: COLORS.red }}>*</Text>
              </Text>
              <View style={styles.inputWrap}>
                <View style={{ flexDirection: "row", alignItems: "center" }}>
                  <TextInput
                    style={styles.input}
                    onChangeText={handleChange("password")}
                    onBlur={() => setFieldTouched("password")}
                    value={values.password}
                    placeholder={__(
                      "loginScreenTexts.formFieldsPlaceholder.password",
                      appSettings.lng
                    )}
                    type="password"
                    autoCorrect={false}
                    autoCapitalize="none"
                    onFocus={() => setFieldTouched("password")}
                    secureTextEntry={hidePassword}
                  />
                  <FontAwesome5
                    name={icon}
                    size={20}
                    onPress={() => _changeIcon()}
                    style={{
                      position: "absolute",
                      right: 10,
                    }}
                  />
                </View>
                <View style={styles.errorFieldWrap}>
                  {touched.password && errors.password && (
                    <Text style={styles.errorMessage}>{errors.password}</Text>
                  )}
                </View>
              </View>
              <View style={styles.loginBtnWrap}>
                <AppButton
                  onPress={handleSubmit}
                  title={__(
                    "loginScreenTexts.loginButtonTitle",
                    appSettings.lng
                  )}
                  textStyle={{
                    fontFamily: "Poppins Bold",
                  }}
                  style={styles.loginBtn}
                  disabled={
                    errors.username ||
                    errors.password ||
                    !touched.username ||
                    socialOverlayActive
                  }
                  loading={loading}
                />
              </View>
              {responseErrorMessage && (
                <View style={styles.responseErrorWrap}>
                  <Text style={styles.responseErrorMessage}>
                    {responseErrorMessage}
                  </Text>
                </View>
              )}
            </View>
          )}
        </Formik>
        <AppTextButton
          title={__("loginScreenTexts.forgotPassword", appSettings.lng)}
          style={{ color: COLORS.primary }}
          textStyle={{
            fontFamily: "Poppins Regular",
          }}
          onPress={() => {
            setModalVisible(true);
          }}
        />
      </View>
      {/*{socialConfig?.enabled && (*/}
      {/*    <View style={styles.socialLoginWrap}>*/}
      {/*        {socialConfig?.socialPlatforms?.includes("google") && (*/}
      {/*            <AppButton*/}
      {/*                title={__(*/}
      {/*                    "loginScreenTexts.socialButtonTitle.google",*/}
      {/*                    appSettings.lng*/}
      {/*                )}*/}
      {/*                onPress={handleGoogleLoginPress}*/}
      {/*                style={{*/}
      {/*                    backgroundColor: "#fff",*/}
      {/*                    marginBottom: 10,*/}
      {/*                    height: 50,*/}
      {/*                    borderWidth: 1,*/}
      {/*                    borderColor: "#d5d5d5"*/}
      {/*                }}*/}
      {/*                disabled={socialOverlayActive || loading}*/}
      {/*                loading={activeSocialType === "google"}*/}
      {/*                textStyle={{*/}
      {/*                    color: COLORS.black,*/}
      {/*                    fontFamily: "Poppins Bold"*/}
      {/*                }}*/}
      {/*                icon={<Image source={require("../assets/google-logo.png")} style={{width: 25, height: 25}}/>*/}
      {/*                }*/}
      {/*            />*/}
      {/*        )}*/}
      {/*        {socialConfig?.socialPlatforms.includes("facebook") && (*/}
      {/*            <AppButton*/}
      {/*                title={__(*/}
      {/*                    "loginScreenTexts.socialButtonTitle.facebook",*/}
      {/*                    appSettings.lng*/}
      {/*                )}*/}
      {/*                onPress={handleFacebookLoginPress}*/}
      {/*                style={{*/}
      {/*                    backgroundColor: "#fff",*/}
      {/*                    marginBottom: 10,*/}
      {/*                    height: 50,*/}
      {/*                    borderWidth: 1,*/}
      {/*                    borderColor: "#d5d5d5"*/}
      {/*                }}*/}
      {/*                disabled={socialOverlayActive || loading}*/}
      {/*                loading={activeSocialType === "facebook"}*/}
      {/*                textStyle={{*/}
      {/*                    color: COLORS.black,*/}
      {/*                    fontFamily: "Poppins Bold"*/}
      {/*                }}*/}
      {/*                icon={<Image source={require("../assets/facebook-logo.png")}*/}
      {/*                             style={{width: 25, height: 25}}/>*/}
      {/*                }*/}
      {/*            />*/}
      {/*        )}*/}
      {/*        {socialErrorMessage && (*/}
      {/*            <View style={styles.responseErrorWrap}>*/}
      {/*                <Text style={styles.responseErrorMessage}>*/}
      {/*                    {socialErrorMessage}*/}
      {/*                </Text>*/}
      {/*            </View>*/}
      {/*        )}*/}
      {/*    </View>*/}
      {/*)}*/}

      <View style={styles.centeredView}>
        <Modal animationType="slide" transparent={true} visible={modalVisible}>
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <Text style={styles.modalText}>
                {__("loginScreenTexts.forgotPassword", appSettings.lng)}
              </Text>
              <Text style={styles.modalText}>
                {__("loginScreenTexts.passwordReset", appSettings.lng)}
              </Text>

              <Formik
                initialValues={{ user_login: "" }}
                validationSchema={validationSchema_reset}
                onSubmit={handlePassReset}
              >
                {({
                  handleChange,

                  handleSubmit,
                  values,
                  errors,
                  setFieldTouched,
                  touched,
                }) => (
                  <View
                    style={{
                      width: "100%",
                      alignItems: "center",
                    }}
                  >
                    <TextInput
                      style={[styles.modalEmail]}
                      onChangeText={handleChange("user_login")}
                      onBlur={() => setFieldTouched("user_login")}
                      value={values.user_login}
                      placeholder={__(
                        "loginScreenTexts.formFieldsPlaceholder.username",
                        appSettings.lng
                      )}
                      autoCorrect={false}
                      autoCapitalize="none"
                    />
                    <View style={styles.errorFieldWrap}>
                      {touched.user_login && errors.user_login && (
                        <Text style={[styles.errorMessage]}>
                          {errors.user_login}
                        </Text>
                      )}
                    </View>
                    <AppButton
                      title={__(
                        "loginScreenTexts.passwordResetButton",
                        appSettings.lng
                      )}
                      style={styles.resetLink}
                      onPress={handleSubmit}
                      loading={reset_Loading}
                      disabled={
                        errors.user_login || values.user_login.length < 1
                      }
                    />
                    {passResetErrorMessage && (
                      <View style={styles.responseErrorWrap}>
                        <Text style={styles.responseErrorMessage}>
                          {passResetErrorMessage}
                        </Text>
                      </View>
                    )}
                    <AppTextButton
                      title={__(
                        "loginScreenTexts.cancelButtonTitle",
                        appSettings.lng
                      )}
                      onPress={() => {
                        setModalVisible(!modalVisible);
                      }}
                      textStyle={styles.cancelResetBtn}
                    />
                  </View>
                )}
              </Formik>
            </View>
          </View>
        </Modal>
      </View>
      <FlashNotification
        falshShow={flashNotification}
        flashMessage={flashNotificationMessage}
      />
      {socialOverlayActive && (
        <View style={styles.socialOverlayWrap}>
          <View
            style={{
              backgroundColor: "#000",
              opacity: 0.2,
              position: "absolute",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
            }}
          />
          <View
            style={{
              paddingVertical: 40,
              backgroundColor: COLORS.white,
              width: "60%",
              alignItems: "center",
              borderRadius: 10,
            }}
          >
            <Text style={{ marginBottom: 20 }}>
              {__("loginScreenTexts.pleaseWaitText", appSettings.lng)}
            </Text>
            <ActivityIndicator size="large" color="black" />
            <AppTextButton
              title={__("loginScreenTexts.cancelButtonTitle", appSettings.lng)}
              onPress={handleSocialLoginCancel}
              style={{ marginTop: 20 }}
            />
          </View>
        </View>
      )}
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  cancelResetBtn: {
    color: "gray",
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22,
  },
  container: {
    alignItems: "center",
    paddingTop: 10,
  },
  errorFieldWrap: {
    height: 15,
    justifyContent: "center",
  },
  errorMessage: {
    fontSize: 12,
    color: COLORS.red,
    fontFamily: "Poppins Bold",
  },
  input: {
    backgroundColor: "#F5F7FF",
    width: "100%",
    marginVertical: 10,
    height: 50,
    justifyContent: "center",
    borderRadius: 10,
    paddingHorizontal: 10,
    fontFamily: "Poppins Regular",
  },
  inputWrap: {
    width: "100%",
  },
  loginBtn: {
    height: 50,
    borderRadius: 50,
    marginVertical: 10,
    width: "40%",
  },
  loginBtnWrap: {
    width: "100%",
    display: "flex",
    flexDirection: "row",
  },
  loginForm: {
    width: "100%",
    paddingHorizontal: 20,
  },
  loginNotice: {
    fontSize: 16,
    color: "#111",
    marginVertical: 20,
  },
  modalEmail: {
    backgroundColor: "#e3e3e3",
    width: "95%",
    marginVertical: 10,
    height: 38,
    justifyContent: "center",
    borderRadius: 3,
    paddingHorizontal: 10,
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center",
    fontFamily: "Poppins Regular",
  },
  modalView: {
    margin: 20,
    backgroundColor: "white",
    borderRadius: 3,
    padding: 35,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    width: "90%",
  },
  resetLink: {
    height: 40,
    borderRadius: 3,
    marginVertical: 10,
    width: "60%",
  },
  responseErrorMessage: {
    color: COLORS.red,
    fontWeight: "bold",
    fontSize: 15,
  },
  responseErrorWrap: {
    marginVertical: 10,
    alignItems: "center",
  },
  signUpPrompt: {},
  socialLogin: {
    marginHorizontal: 15,
  },
  socialLoginWrap: {
    marginBottom: 10,
    width: "100%",
    paddingHorizontal: 20,
  },
  socialOverlayWrap: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: "center",
    justifyContent: "center",
  },
  tnCToggle: {
    flexDirection: "row",
    paddingHorizontal: screenWidth * 0.03,
    alignItems: "center",
    marginVertical: 10,
  },
  tnCToggleText: {
    paddingLeft: 5,
    fontFamily: "Poppins Regular",
  },
});

export default LoginScreen;
