import React from 'react';
import ContactUsScreen from "./ContactUsScreen";

const AdvertiseWithUsScreen = () => {
    return (
        <ContactUsScreen/>
    );
};

export default AdvertiseWithUsScreen;