import React, { useState } from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";

// Custom Components & Functions
import { getTnC } from "../language/stringPicker";
import { COLORS } from "../variables/color";
import { useStateValue } from "../StateProvider";

const TnCScreen = () => {
  const [{ appSettings }] = useStateValue();
  const [tnCData, setTnCData] = useState(getTnC(appSettings.lng));
  return (
    <View style={styles.container}>
      <ScrollView>
        <View style={styles.mainWrap}>
          <View
            style={{
              alignItems: "center",
              paddingHorizontal: "3%",
            }}
          >
            {tnCData.map((_tnc, index) => (
              <View style={styles.tncParaWrap} key={index}>
                {!!_tnc.paraTitle && (
                  <Text style={styles.paraTitle}>{_tnc.paraTitle}</Text>
                )}
                {!!_tnc.paraData && (
                  <Text style={styles.paraData}>{_tnc.paraData}</Text>
                )}
              </View>
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.white,
    flex: 1,
  },
  mainWrap: {
    paddingVertical: 15,
  },
  paraTitle: {
    fontWeight: "bold",
    fontSize: 15,
    marginBottom: 5,
  },
  paraData: {
    textAlign: "justify",
    fontSize: 14,
    lineHeight: 22,
    fontFamily: "Poppins Regular"
  },
  tncParaWrap: {
    marginBottom: 20,
    width: "100%",
  },
});

export default TnCScreen;
