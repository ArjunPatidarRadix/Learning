/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
import React, {useRef, useEffect, useState} from "react";
import {
    View,
    StyleSheet,
    Text,
    TextInput,
    Image,
    TouchableOpacity,
    ScrollView,
    ActivityIndicator,
    Platform,
    KeyboardAvoidingView, ImageBackground, Dimensions,
} from "react-native";

// External Libraries
import {Formik} from "formik";
import * as Yup from "yup";
import moment from "moment";

// Vector Icons
import {Feather, MaterialCommunityIcons} from "@expo/vector-icons";
import {FontAwesome} from "@expo/vector-icons";

// Custom Components & Functions
import {COLORS} from "../variables/color";
import {useStateValue} from "../StateProvider";
import api, {setAuthToken, removeAuthToken} from "../api/client";
import {decodeString, generateItems, stripString} from "../helper/helper";
import {__} from "../language/stringPicker";
import {routes} from "../navigation/routes";
import TabScreenHeader from "../components/TabScreenHeader";
import chatListItemFallbackImageUrl from "../assets/200X150.png";
import PremiumAds from "../components/PremiumAds";

const chatScreenImagesUrls = {
    fallbackImageUrl: require("../assets/200X150.png"),
};

const validationSchema = Yup.object().shape({
    message: Yup.string().required(),
});


const {width: screenWidth} = Dimensions.get("screen");
const ChatScreen = ({navigation, route}) => {
    const [{user, auth_token, ios, appSettings}] = useStateValue();
    const [listingData] = useState(route.params.listing);
    const [conversationData, setConversationData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [sending, setSending] = useState(false);
    const [autoload, setAutoload] = useState(false);
    const [con_id, setConId] = useState(route.params.con_id);
    const [isConDeleted, setIsConDeleted] = useState({
        sendr_id: parseInt(route.params.sender_id) || 0,
        recipient_delete: parseInt(route.params.recipient_delete) || 0,
        sender_delete: parseInt(route.params.sender_delete) || 0,
        recipient_id: parseInt(route.params.recipient_id) || 0,
    });
    const scrollView = useRef();

    // scroll to end effect
    useEffect(() => {
        if (loading) return;
        scrollView.current.scrollToEnd();
    }, [loading]);

    // auto refresh effect
    useEffect(() => {
        handleLoadMessages();
        const interval = setInterval(handleLoadMessages, 15000);
        if (
            isConDeleted.recipient_delete === 1 ||
            isConDeleted.sender_delete === 1
        ) {
            clearInterval(interval);
            return;
        }
        handleCheckHasConversation();
        return () => clearInterval(interval);
    }, [con_id]);

    const handleCheckHasConversation = () => {
        if (con_id) return;
        setAuthToken(auth_token);
        api
            .get("my/chat/check", {listing_id: route.params.listing.id})
            .then((res) => {
                if (res.ok) {
                    if (res.data && res.data.con_id) {
                        setConversationData(res.data.messages || []);
                        setConId(res.data.con_id);
                    } else {
                        setConversationData([]);
                    }
                    removeAuthToken();
                    setLoading(false);
                } else {
                    // print error
                    // TODO Error handling
                    removeAuthToken();
                    setLoading(false);
                }
            });
    };

    const handleLoadMessages = () => {
        if (autoload || !con_id || sending) {
            return;
        }
        setAutoload(true);
        setAuthToken(auth_token);
        api.get("my/chat/conversation", {con_id: con_id}).then((res) => {
            if (res.ok) {
                setConversationData(res.data.messages);
                setIsConDeleted((isConDeleted) => {
                    return {
                        ...isConDeleted,
                        ["sender_id"]: res.data.sender_id,
                        ["sender_delete"]: res.data.sender_delete,
                        ["recipient_delete"]: res.data.recipient_delete,
                    };
                });
                removeAuthToken();
                setLoading(false);
                setAutoload(false);
            } else {
                // print error
                // TODO Error handling
                removeAuthToken();
                setLoading(false);
                setAutoload(false);
            }
        });
    };

    const handleLocationNCategoryData = () => {
        if (listingData.location.length) {
            if (listingData.category.length) {
                return decodeString(
                    listingData.location[listingData.location.length - 1].name +
                    ", " +
                    listingData.category[listingData.category.length - 1].name
                );
            } else {
                return decodeString(
                    listingData.location[listingData.location.length - 1].name
                );
            }
        } else {
            return decodeString(
                listingData.category[listingData.category.length - 1].name
            );
        }
    };

    //TODO need to check
    const handleMessageReadStatus = (item) => {
        setAuthToken(auth_token);
        api
            .put("my/chat/message", {
                con_id: item.con_id,
                message_id: item.message_id,
            })
            .then((res) => {
                if (res.ok) {
                    removeAuthToken();
                } else {
                    removeAuthToken();
                }
            });
    };

    const handleMessageSending = (values, {resetForm}) => {
        setSending(true);
        const newMessage = {
            message_id: new Date().getTime(),
            source_id: user.id.toString(),
            message: values.message,
            created_at: moment().format("YYYY-MM-DD HH:mm:ss"),
            con_id: route.params.con_id,
            is_read: 0,
        };
        setConversationData((conversationData) => [
            ...conversationData,
            newMessage,
        ]);
        resetForm({values: ""});
        setAuthToken(auth_token);
        const url = con_id ? "my/chat/message" : "my/chat/conversation";
        api
            .post(url, {
                listing_id: listingData.id,
                text: values.message,
                con_id: con_id || 0,
            })
            .then((res) => {
                if (res.ok) {
                    removeAuthToken();
                    if (!con_id && res.data.con_id) {
                        setConId(res.data.con_id);
                    }
                } else {
                    const newConversation = [...conversationData].filter(
                        (message) => message.message_id !== newMessage.message_id
                    );
                    setConversationData([...newConversation, res.data]);
                }
            })
            .then(() => {
                removeAuthToken();
                setSending(false);
            });
    };
    const Message = ({thumb, text, time, sender, is_read}) => (
        <View
            style={{
                width: "100%",
                marginVertical: 10,
            }}
        >
            <View
                style={{
                    flexDirection: "row",
                    backgroundColor: sender ? "white" : "#F4F9FD",
                    borderRadius: 10,
                    paddingHorizontal: 10,
                    paddingVertical: 10,
                }}
            >
                <View style={styles.chatImageContainer}>
                    <Image
                        style={styles.chatImage}
                        source={
                            thumb === null
                                ? chatListItemFallbackImageUrl
                                : {
                                    uri: sender ? thumb : route.params.thumb[0].sizes.thumbnail.src,
                                }
                        }
                    />
                </View>
                <View style={{marginRight: 25}}>
                    <View style={{flexDirection: "row"}}>
                        <Text style={{
                            fontSize: 12,
                            color: COLORS.black,
                            fontFamily: "Poppins Bold",
                            paddingRight: 10
                        }}>
                            {sender ? "You" : route.params.item}
                        </Text>
                        <Text style={{
                            fontSize: 12,
                            color: COLORS.text_gray,
                            fontFamily: "Poppins Regular",
                        }}>
                            {moment(time).format("h:mm A")}
                        </Text>
                    </View>
                    <Text style={{
                        fontFamily: "Poppins Regular",
                    }}>
                        {decodeString(text)}
                    </Text>
                </View>
            </View>
        </View>
    );

    return !ios ? (
        <>
            <TabScreenHeader left onLeftClick={() => navigation.goBack()}/>
            {loading && (
                <View style={styles.loading}>
                    <ActivityIndicator size="large" color={COLORS.primary}/>
                    <Text style={styles.text}>
                        {__("chatScreenTexts.loadingMessage", appSettings.lng)}
                    </Text>
                </View>
            )}
            {!loading && (
                <View style={{flex: 1}}>
                    {/* Chat List Component */}
                    <ScrollView
                        ref={scrollView}
                        onContentSizeChange={() => scrollView.current.scrollToEnd()}
                        showsVerticalScrollIndicator={false}
                        contentContainerStyle={{
                            paddingHorizontal: "2%",
                        }}
                    >


                        <View style={styles.imageSearchContainer}>
                            <View style={styles.child}>
                                <PremiumAds admob={false}/>
                                <View style={{position: 'absolute', left: 0, right: 0, top: 20,}}>
                                    <View style={styles.listingTop}>
                                        <Formik initialValues={{search: ""}}>
                                            {() => (
                                                <View style={styles.ListingSearchContainer}>
                                                    <TextInput
                                                        style={styles.searchInput}
                                                        placeholder={__(
                                                            "homeScreenTexts.listingSearchPlaceholder",
                                                            appSettings.lng
                                                        )
                                                        }
                                                        placeholderTextColor={COLORS.textGray}
                                                    />
                                                    <TouchableOpacity
                                                        style={styles.listingSearchBtnContainer}
                                                    >
                                                        <Feather
                                                            name="search"
                                                            size={20}
                                                            color={COLORS.white}
                                                        />
                                                    </TouchableOpacity>
                                                </View>
                                            )}
                                        </Formik>
                                    </View>
                                </View>
                            </View>
                        </View>
                        <View style={{
                            marginHorizontal: 15,
                            paddingHorizontal: 20,
                            borderRadius: 10,
                            top: -90,
                            backgroundColor: COLORS.white
                        }}>
                            <Text style={{
                                color: COLORS.primary,
                                textAlign: "center",
                                fontSize: 25,
                                fontFamily: "Poppins Bold",
                                paddingTop: 10,
                            }}>Messages</Text>
                            {conversationData.length !== 0 ? (
                                <View>
                                    {generateItems(conversationData).reverse().map((item) => {
                                        const is_read = !!parseInt(item.is_read);
                                        if (!is_read && item.source_id != user.id) {
                                            handleMessageReadStatus(item);
                                        }

                                        if (item.type === 'day') {
                                            return (
                                                <View style={{
                                                    alignItems: "center",
                                                    borderWidth: 1,
                                                    borderColor: "#E6EBF5",
                                                    paddingVertical: 10,
                                                    paddingHorizontal: 5,
                                                    borderRadius: 30,
                                                    width: 240,
                                                    alignSelf: "center"
                                                }}>
                                                    <Text style={{
                                                        fontFamily: "Poppins Bold",
                                                        fontSize: 14,
                                                        color: "#7D8592"
                                                    }}>{moment(item.date).format('dddd, MMMM Do')}</Text>
                                                </View>
                                            )
                                        }

                                        return (
                                            // {* Individual Message Component *}
                                            <Message
                                                key={item.message_id}
                                                text={item.message}
                                                time={item.created_at}
                                                sender={item.source_id === user.id.toString()}
                                                is_read={is_read}
                                                thumb={user.pp_thumb_url}
                                            />
                                        );
                                    })}
                                </View>) : (

                                <View style={styles.noChatWrap}>
                                    <Text style={styles.noChatTitle}>
                                        No messages here yet
                                    </Text>
                                    <View style={styles.noChatIcon}>
                                        <FontAwesome name="wechat" size={100} color={COLORS.primary_soft}/>
                                        <Image style={styles.shadow} source={require("../assets/NoChat.png")}/>
                                    </View>
                                    <Text style={styles.noChatMessage}>
                                        Send a message
                                    </Text>
                                </View>
                            )}
                        </View>
                    </ScrollView>
                </View>
            )}
            {(user.id === isConDeleted.sender_id &&
                isConDeleted.recipient_delete == 0) ||
            (user.id !== isConDeleted.sender_id &&
                isConDeleted.sender_delete == 0) ? (
                <Formik
                    initialValues={{message: ""}}
                    onSubmit={handleMessageSending}
                    validationSchema={validationSchema}
                >
                    {({handleChange, handleBlur, handleSubmit, values, errors}) => (
                        <View style={styles.chatBoxWrap}>
                            {/* Message Input Component */}
                            <TextInput
                                onChangeText={handleChange("message")}
                                onBlur={handleBlur("message")}
                                value={values.message}
                                multiline={true}
                                placeholder={__(
                                    "chatScreenTexts.placeholder.message",
                                    appSettings.lng
                                )}
                                style={styles.chatInput}
                                textAlignVertical="center"
                            />
                            {/* Send Button Component */}
                            <TouchableOpacity
                                style={styles.sendButton}
                                onPress={handleSubmit}
                                disabled={!!errors.message || !values.message.trim().length}
                            >
                                <FontAwesome
                                    name="send-o"
                                    size={25}
                                    color={
                                        errors.message || !values.message.trim().length
                                            ? COLORS.gray
                                            : COLORS.primary
                                    }
                                />
                            </TouchableOpacity>
                        </View>
                    )}
                </Formik>
            ) : (
                // {* Message Deleted Cpmponent *}
                <View style={styles.deletedMessageWrap}>
                    <Text style={styles.deletedMessage}>
                        {__("chatScreenTexts.dactivatedMessage", appSettings.lng)}
                    </Text>
                </View>
            )}
        </>
    ) : (
        <>
            <TabScreenHeader left onLeftClick={() => navigation.goBack()}/>
            {loading && (
                <View style={styles.loading}>
                    <ActivityIndicator size="large" color={COLORS.primary}/>
                    <Text style={styles.text}>
                        {__("chatScreenTexts.loadingMessage", appSettings.lng)}
                    </Text>
                </View>
            )}
            {!loading && (
                <KeyboardAvoidingView
                    style={styles.container}
                    behavior="padding"
                    keyboardVerticalOffset={70}
                >
                    {/* Chat List Component */}
                    <ScrollView
                        ref={scrollView}
                        onContentSizeChange={() => scrollView.current.scrollToEnd()}
                        showsVerticalScrollIndicator={false}
                        contentContainerStyle={{
                            paddingHorizontal: "2%",
                        }}
                    >
                        <View style={styles.imageSearchContainer}>
                            <View style={styles.child}>
                                <PremiumAds admob={false}/>
                                <View style={{position: 'absolute', left: 0, right: 0, top: 20,}}>
                                    <View style={styles.listingTop}>
                                        <Formik initialValues={{search: ""}}>
                                            {() => (
                                                <View style={styles.ListingSearchContainer}>
                                                    <TextInput
                                                        style={styles.searchInput}
                                                        placeholder={__(
                                                            "homeScreenTexts.listingSearchPlaceholder",
                                                            appSettings.lng
                                                        )
                                                        }
                                                        placeholderTextColor={COLORS.textGray}
                                                    />
                                                    <TouchableOpacity
                                                        style={styles.listingSearchBtnContainer}
                                                    >
                                                        {/* <Feather
                                                            name="search"
                                                            size={20}
                                                            color={COLORS.white}
                                                        /> */}
                                                        
                                                        <Text style={{color:'#fff'}}>Search</Text>

                                                    </TouchableOpacity>
                                                </View>
                                            )}
                                        </Formik>
                                    </View>
                                </View>
                            </View>
                        </View>
                        <View style={{
                            marginHorizontal: 15,
                            paddingHorizontal: 10,
                            borderRadius: 10,
                            top: -90,
                            backgroundColor: COLORS.white
                        }}>
                            <Text style={{
                                color: COLORS.primary,
                                textAlign: "center",
                                fontSize: 25,
                                fontFamily: "Poppins Bold",
                                paddingTop: 10,
                            }}>Chats</Text>{conversationData.length !== 0 ? (
                            <View>
                                {generateItems(conversationData).reverse().map((item) => {
                                    const is_read = !!parseInt(item.is_read);
                                    if (!is_read && item.source_id != user.id) {
                                        handleMessageReadStatus(item);
                                    }

                                    if (item.type === 'day') {
                                        return (
                                            <View style={{
                                                alignItems: "center",
                                                borderWidth: 1,
                                                borderColor: "#E6EBF5",
                                                paddingVertical: 10,
                                                paddingHorizontal: 5,
                                                borderRadius: 30,
                                                width: 240,
                                                alignSelf: "center"
                                            }}>
                                                <Text style={{
                                                    fontFamily: "Poppins Bold",
                                                    fontSize: 14,
                                                    color: "#7D8592"
                                                }}>{moment(item.date).format('dddd, MMMM Do')}</Text>
                                            </View>
                                        )
                                    }

                                    return (
                                        // {* Individual Message Component *}
                                        <Message
                                            key={item.message_id}
                                            text={item.message}
                                            time={item.created_at}
                                            sender={item.source_id === user.id.toString()}
                                            is_read={is_read}
                                            thumb={user.pp_thumb_url}
                                        />
                                    );
                                })}
                            </View>) : (

                            <View style={styles.noChatWrap}>
                                <Text style={styles.noChatTitle}>
                                    No messages here yet
                                </Text>
                                <View style={styles.noChatIcon}>
                                    <FontAwesome name="wechat" size={100} color={COLORS.primary_soft}/>
                                    <Image style={styles.shadow} source={require("../assets/NoChat.png")}/>
                                </View>
                                <Text style={styles.noChatMessage}>
                                    Send a message
                                </Text>
                            </View>
                        )}
                        </View>
                    </ScrollView>
                    {(user.id === isConDeleted.sender_id &&
                        isConDeleted.recipient_delete == 0) ||
                    (user.id !== isConDeleted.sender_id &&
                        isConDeleted.sender_delete == 0) ? (
                        <Formik
                            initialValues={{message: ""}}
                            onSubmit={handleMessageSending}
                            validationSchema={validationSchema}
                        >
                            {({handleChange, handleBlur, handleSubmit, values, errors}) => (
                                <View style={styles.chatBoxWrap}>
                                    {/* Message Input Component */}
                                    <TextInput
                                        onChangeText={handleChange("message")}
                                        onBlur={handleBlur("message")}
                                        value={values.message}
                                        multiline={true}
                                        placeholder={__(
                                            "chatScreenTexts.placeholder.message",
                                            appSettings.lng
                                        )}
                                        style={styles.chatInput}
                                        textAlignVertical="center"
                                    />
                                    {/* Send Button Component */}
                                    <TouchableOpacity
                                        style={styles.sendButton}
                                        onPress={handleSubmit}
                                        disabled={!!errors.message || !values.message.trim().length}
                                    >
                                        <FontAwesome
                                            name="send-o"
                                            size={25}
                                            color={
                                                errors.message || !values.message.trim().length
                                                    ? COLORS.gray
                                                    : COLORS.primary
                                            }
                                        />
                                    </TouchableOpacity>
                                </View>
                            )}
                        </Formik>
                    ) : (
                        // {* Message Deleted Cpmponent *}
                        <View style={styles.deletedMessageWrap}>
                            <Text style={styles.deletedMessage}>
                                {__("chatScreenTexts.dactivatedMessage", appSettings.lng)}
                            </Text>
                        </View>
                    )}
                </KeyboardAvoidingView>
            )}
        </>
    );
};

const styles = StyleSheet.create({
    chatBoxWrap: {
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: COLORS.white,
        marginHorizontal: "2%",
        marginVertical: 5,
    },
    chatInput: {
        minHeight: 40,
        backgroundColor: COLORS.white,
        paddingHorizontal: 5,
        flex: 1,
        paddingTop: Platform.OS === "ios" ? 11 : 0,
    },

    container: {
        backgroundColor: COLORS.bg_dark,
        flex: 1,
    },
    deletedMessageWrap: {
        padding: 10,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "yellow",
    },
    deletedMessage: {
        color: COLORS.text_dark,
    },
    loading: {
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        opacity: 1,
        backgroundColor: "transparent",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 5,
        flex: 1,
    },
    mainWrap: {
        backgroundColor: COLORS.bg_dark,
        paddingVertical: 10,
        elevation: 2,
    },
    messageBubble: {
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 10,
        backgroundColor: "#fafafa",
        flex: 1,
    },
    sendButton: {
        paddingHorizontal: 10,
    },
    listingSearchBtnContainer: {
        marginLeft: 5,
        marginRight: -10,
        backgroundColor: COLORS.primary,
        borderRadius: 5,
        padding: 8
    },
    ListingSearchContainer: {
        flex: 1,
        height: 45,
        marginHorizontal: 10,
        backgroundColor: COLORS.white,
        borderWidth: 1,
        borderRadius: 4,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        paddingHorizontal: 15,
        elevation: 7,
        zIndex: 20,
        shadowColor: "#000",
        shadowRadius: 4,
        shadowOpacity: 0.2,
        shadowOffset: {
            height: -4,
            width: 2,
        },
    },
    imageSearchContainer: {
        paddingTop: 0,
        paddingHorizontal: 10,
        
        height: 250,
        width: '100%',
        backgroundColor: "#fff",
        // transform: [{ scaleX: 2 }],
        overflow: 'hidden',
    },
    child: {
        // top: -100,
        flex: 1,
        // transform: [{scaleX: 0.5}],
        alignItems: 'center',
        justifyContent: 'center'
    },
    listingTop: {
        width: "100%",
        // paddingTop: 100,
        zIndex: 1,
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: screenWidth * 0.03,
        paddingBottom: 10,
    },
    chatImage: {
        height: 30,
        width: 30,
        resizeMode: "cover",
    },
    chatImageContainer: {
        height: 30,
        width: 30,
        borderRadius: 30,
        borderWidth: 1,
        borderColor: COLORS.gray,
        overflow: "hidden",
        alignItems: "center",
        justifyContent: "center",
        marginRight: 5
    },

    noChatIcon: {
        marginVertical: 30,
        alignItems: "center",
    },
    noChatMessage: {
        color: COLORS.text_gray,
        fontFamily: "Poppins Regular"
    },
    noChatTitle: {
        fontSize: 16,
        color: COLORS.text_dark,
        fontFamily: "Poppins Bold"
    },
    noChatWrap: {
        paddingVertical: 40,
        backgroundColor: COLORS.white,
        width: "100%",
        alignItems: "center",
        justifyContent: "center",
    },
});

export default ChatScreen;
