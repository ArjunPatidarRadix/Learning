
/* eslint-disable no-undef */
import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";
import {
    View,
    StyleSheet,
    Text,
    TouchableOpacity,
    TextInput,
    FlatList,
    Dimensions,
    Animated,
    ActivityIndicator,
    Keyboard,
    RefreshControl,
    ScrollView,
    Image,
} from "react-native";
import DrawerLayout from 'react-native-gesture-handler/DrawerLayout';
// Vector Fonts
import { Feather } from "@expo/vector-icons";
import { Fontisto } from "@expo/vector-icons";
import { Formik } from "formik";
import Carousel, { Pagination } from 'react-native-snap-carousel';

// Custom Components & Constants
import { COLORS } from "../variables/color";
import TabScreenHeader from "../components/TabScreenHeader";
import { useStateValue } from "../StateProvider";
import api, { removeAuthToken, setAuthToken } from "../api/client";
import { decodeString, insertAndShift, stripString } from "../helper/helper";
import FlashNotification from "../components/FlashNotification";
import AppButton from "../components/AppButton";
import ListingCard from "../components/ListingCard";
import { paginationData } from "../app/pagination/paginationData";
import CategoryIcon from "../components/CategoryIcon";
import CategoryImage from "../components/CategoryImage";
import { __ } from "../language/stringPicker";
import { routes } from "../navigation/routes";
import { useNavigation } from "@react-navigation/native";
import PremiumAds from "../components/PremiumAds";
import DrawerMenu from "../components/DrawerMenu";
import { SwiperFlatList } from 'react-native-swiper-flatlist';
import CacheStore from "react-native-cache-store";

const { width: screenWidth, height: screenHeight } = Dimensions.get("screen");

const SubCategoryDetails = ({ route }) => {
    console.log(route)
    const drawer = useRef(null);
    const [drawerPosition] = useState("left");
    const navigation = useNavigation();
    const [
        { search_locations, country, config, search_categories, ios, user, appSettings },
        dispatch,
    ] = useStateValue();
    const [topCategoriesData, setTopCategoriesData] = useState([]);
    const [pagination, setPagination] = useState({});
    const [searchData, setSearchData] = useState(() => {
        return {
            ...paginationData.home,
            search: "",
            locations: search_locations.length
                ? search_locations.map((location) => location.term_id)
                : "",
            categories: "",
            page: pagination.current_page || 1,
            onScroll: false,
        };
    });
    const [locationsData, setLocationsData] = useState([]);
    const [listingsData, setListingsData] = useState([]);
    const [otherListingsData, setOtherListingsData] = useState([]);
    const [allCategories, setAllCategories] = useState([]);
    const [loading, setLoading] = useState(true);
    const [moreLoading, setMoreLoading] = useState(false);
    const [initial, setInitial] = useState(true);
    const [flashNotification, setFlashNotification] = useState(false);
    const [refreshing, setRefreshing] = useState(false);
    const [timedOut, setTimedOut] = useState();
    const [clickedSubCategory, setClickedSubCategory] = useState("");
    const [networkError, setNetworkError] = useState();
    const [retry, setRetry] = useState(false);
    const [scrollButtonVisible, setScrollButtonVisible] = useState(false);
    const [currentPage, setCurrentPage] = useState(
        pagination.page || paginationData.allStores.page
    );
    const [storesData, setStoresData] = useState([]);
    const [clicked, setClicked] = useState(false);
    const [activeCategorySlide, setActiveSlide] = useState(0);
    const [gettingData, setGettingData] = useState(false);

    const navigationView = () => (
        // eslint-disable-next-line no-undef
        <View style={[styles.container]}>
            <DrawerMenu close={() => drawer.current.closeDrawer()} />
        </View>
    );




    const _getLocations = () => {
        api.get("locations").then((res) => {
            if (res.ok) {
                setLocationsData(res.data);
                CacheStore.set('locations', res.data, 24 * 60);
            } else {
                if (res.problem === "CANCEL_ERROR") {
                    return true;
                }
            }
        });
    }

    const handleLoadLocations = () => {
        CacheStore.get('locations')
            .then(data => {
                if (data === null) {
                    // console.log(data)
                    _getLocations();
                } else {
                    // console.log(data)
                    setLocationsData(data);
                }
            })
            .catch(error => {

            })
    };


    // Load Listing Data
    useEffect(() => {
        if (locationsData.length > 0 && country !== "") {
            setLoading(true);
            setGettingData(true);
        }
    }, [locationsData, country]);




    const _getSelectedCatItems = (item) => {
        setLoading(true)
        api.get(`/listings?categories=${item.term_id}&per_page=100&order_by=locations&order=desc`).then((res) => {
            setClickedSubCategory(item.name)
            // console.log(';;', res)
            if (res.ok) {
                if (refreshing) {
                    setRefreshing(false);
                }
                CacheStore.set(`listing_sub_${item.term_id}`, res.data.data, 2);
                setListingsData(res.data.data.splice(0, 8));
                setOtherListingsData(res.data.data);
                setLoading(false);
            } else {
                if (refreshing) {
                    setRefreshing(false);
                }

                // print error
                // TODO handle error
                if (res.problem === "CANCEL_ERROR") {
                    return true;
                }
                if (res.problem === "TIMEOUT_ERROR") {
                    setTimedOut(true);
                }
            }
            setMoreLoading(false);
            // setLoading(false);
        });
    }

    useEffect(() => {
        if (route.params.item != undefined) {
            handleSelectCategory(route.params.item)
        }
    }, [])

    const handleSelectCategory = (item) => {
        if (item.my_order == "see_more") {
            setClicked(!clicked)
            return false;
        } else if (item.my_order == "see_less") {
            setClicked(!clicked)
            return false;
        } else {
            setClicked(clicked)
            setLoading(true);

            CacheStore.get(`listing_sub_${item.term_id}`)
                .then(data => {
                    console.log('dataaaa', data)
                    if (data === null) {
                        _getSelectedCatItems(item)
                    } else if (data.length == 0) {
                        _getSelectedCatItems(item)

                    } else {
                        const array = [...data];
                        setListingsData(array.splice(0, 8));
                        setOtherListingsData(array);
                        setLoading(false);
                    }
                }).catch((error) => {
                    _getSelectedCatItems(item)
                })
        }
    };

    const scrollY = new Animated.Value(0);
    const diffClamp = Animated.diffClamp(scrollY, 0, 0);
    const translateY = diffClamp.interpolate({
        inputRange: [0, 0],
        outputRange: [0, 0],
    });

    const Category = ({ onPress, item }) => (
        <TouchableOpacity
            onPress={() => onPress(item)}
            style={{
                alignItems: "center",
                width: (screenWidth * 0.985 - 10) / 3,
                padding: item?.my_order == "see_more" || item?.my_order == "see_less" ? 10 : 5,
                marginTop: item?.my_order == "see_more" || item?.my_order == "see_less" ? 7 : 0
            }}
        >
            <View
                style={{
                    justifyContent: "center",
                    alignItems: "center",
                }}
            >
                <View
                    style={{
                        backgroundColor: item?.my_order == "see_more" || item?.my_order == "see_less" ? "transparent" : "#FFFFFF66",
                        padding: 5,
                        borderRadius: 50,
                        shadowColor: '#a9a9a9',
                        shadowOffset: {
                            width: 0,
                            height: item?.my_order == "see_more" || item?.my_order == "see_less" ? 0 : 12,
                        },
                        shadowOpacity: 0.58,
                        shadowRadius: 16.00,
                        elevation: route.params.parent_id === 278 ? 10 : item?.my_order == "see_more" || item?.my_order == "see_less" ? 0 : 24,
                    }}
                >
                    <View
                        style={{
                            backgroundColor: item?.my_order == "see_more" || item?.my_order == "see_less" ? COLORS.primary : "#FFFFFF",
                            padding: item?.my_order == "see_more" || item?.my_order == "see_less" ? 10 : 20,
                            borderRadius: 50,
                        }}
                    >
                        {item?.icon?.url ? (
                            <CategoryImage size={item?.my_order == "see_more" || item?.my_order == "see_less" ? 20 : 27}
                                uri={item.icon.url} />
                        ) : (
                            <CategoryIcon
                                iconName={item.icon.class}
                                iconSize={27}
                                iconColor={COLORS.primary}
                            />
                        )}
                    </View>
                </View>
                <Text
                    style={{
                        marginTop: item?.my_order == "see_more" || item?.my_order == "see_less" ? 20 : 5,
                        color: COLORS.black,
                        fontSize: route.params.parent_id === 341 ? 13 : 11,
                        textAlign: "center",
                        fontFamily: "Poppins Bold"
                    }}
                >
                    {decodeString(item.name)}
                </Text>
            </View>
        </TouchableOpacity>
    );

    const renderCategory = useCallback(
        ({ item }) => <Category onPress={handleSelectCategory} item={item} />,
        [refreshing, config]
    );

    const keyExtractor = useCallback((item, index) => `${index}`, []);

    const renderFeaturedItem = useCallback(
        ({ item }) => (
            <View>
                <ListingCard
                    onPress={() =>
                        navigation.navigate(routes.listingDetailScreen, {
                            listingId: item.listing_id,
                        })
                    }
                    data={item}
                />
            </View>
        ),
        [refreshing, config]
    );

    const handleSearch = (values) => {
        Keyboard.dismiss();
        setSearchData((prevSearchData) => {
            return { ...prevSearchData, search: values.search };
        });
        setLoading(true);
    };

    const handleReset = () => {
        setSearchData({
            categories: "",
            locations: "",
            onScroll: false,
            page: 1,
            per_page: 20,
            search: "",
        });
        dispatch({
            type: "SET_SEARCH_LOCATIONS",
            search_locations: [],
        });
        dispatch({
            type: "SET_SEARCH_CATEGORIES",
            search_categories: [],
        });
    };


    const ListEmptyComponent = () => {
        return (
            !listingsData.length && !timedOut && !networkError && (
                <View style={styles.noListingsWrap}>
                    <Fontisto
                        name="frowning"
                        size={100}
                        color={COLORS.primary_soft}
                    />
                    <Text style={styles.noListingsMessage}>
                        Sorry... No latest listings available!
                    </Text>
                </View>
            )
        )
    };

    const ListFeaturedEmptyComponent = () => {
        return (
            !otherListingsData.length && !timedOut && !networkError && (
                <View style={styles.noListingsWrap}>
                    <Fontisto
                        name="frowning"
                        size={100}
                        color={COLORS.primary_soft}
                    />
                    <Text style={styles.noListingsMessage}>
                        Sorry... No featured listings available!
                    </Text>
                </View>
            )
        )
    };

    const handleSeeAll = () => {
        navigation.navigate(routes.selectcategoryScreen, {
            data: topCategoriesData,
        });
    };

    const handleRetry = () => {
        setLoading(true);
        if (timedOut) setTimedOut(false);
    };

    const [currentSlideIndex, setCurrentSlideIndex] = React.useState(0);
    const updateCurrentSlideIndex = e => {
        const contentOffsetX = e.nativeEvent.contentOffset.x;
        const currentIndex = Math.round(contentOffsetX / screenWidth);
        setCurrentSlideIndex(currentIndex)
    }

    const [currentStoresSlideIndex, setCurrentStoresSlideIndex] = React.useState(0);
    const updateCurrentStoresSlideIndex = e => {
        const contentOffsetX = e.nativeEvent.contentOffset.x;
        const currentIndex = Math.round(contentOffsetX / screenWidth);
        setCurrentStoresSlideIndex(currentIndex)
    }

    const ref = React.useRef(null);

    const goNextSlide = () => {
        const nextSlideIndex = currentSlideIndex + 1;
        const offset = nextSlideIndex * 100;
        ref?.current?.scrollToOffset(offset);
        setCurrentSlideIndex(nextSlideIndex)
    }

    const goPreviousSlide = () => {
        const previousSlideIndex = currentSlideIndex - 1;
        const offset = previousSlideIndex * screenWidth;
        ref?.current?.scrollToOffset(offset);
        setCurrentSlideIndex(previousSlideIndex)
    }

    let selectedCatList = clicked ? allCategories : topCategoriesData;


    return (
        <DrawerLayout
            ref={drawer}
            drawerWidth={380}
            drawerPosition={drawerPosition}
            renderNavigationView={navigationView}
            drawerBackgroundColor={"#ffffff"}>
            <View style={styles.container}>
                <TabScreenHeader
                    drawer
                    user={user}
                    right={!user}
                    showDrawer={() => drawer.current.openDrawer()}
                    style={{ elevation: 0, zIndex: 2 }} />
                {/* Loading Animation */}
                {loading ? (
                    <View style={styles.loading}>
                        <ActivityIndicator size="large" color={COLORS.primary} />
                        <Text style={styles.text}>
                            {__("homeScreenTexts.loadingMessage", appSettings.lng)}
                        </Text>
                    </View>
                ) : (
                    <>
                        {/* Search , Location , Reset button */}
                        <ScrollView
                            refreshing={false}
                            showsVerticalScrollIndicator={false}
                        >
                            <View style={styles.imageSearchContainer}>
                                <View style={styles.child}>
                                    <PremiumAds admob={false}/>
                                    <View style={{ position: 'absolute', left: 0, right: 0, top: 20, }}>
                                        <View style={styles.listingTop}>
                                            <Formik initialValues={{ search: "" }} onSubmit={handleSearch}>
                                                {({ handleChange, handleBlur, handleSubmit, values }) => (
                                                    <View style={styles.ListingSearchContainer}>
                                                        <TextInput
                                                            style={styles.searchInput}
                                                            placeholder={
                                                                searchData.search ||
                                                                __(
                                                                    "homeScreenTexts.listingSearchPlaceholder",
                                                                    appSettings.lng
                                                                )
                                                            }
                                                            placeholderTextColor={COLORS.textGray}
                                                            onChangeText={handleChange("search")}
                                                            onBlur={() => {
                                                                handleBlur("search");
                                                            }}
                                                            value={values.search}
                                                            returnKeyType="search"
                                                            onSubmitEditing={handleSubmit}
                                                        />

                                                        <TouchableOpacity
                                                            onPress={handleSubmit}
                                                            disabled={!values.search || timedOut || networkError}
                                                            style={styles.listingSearchBtnContainer}
                                                        >
                                                            <Feather
                                                                name="search"
                                                                size={20}
                                                                color={values.search ? COLORS.white : COLORS.white}
                                                            />
                                                        </TouchableOpacity>
                                                    </View>
                                                )}
                                            </Formik>
                                        </View>
                                    </View>
                                </View>
                            </View>

                            {/* FlatList */}
                            <View style={{ backgroundColor: "#fafafa" }}>
                                <>
                                    <View style={{ flex: 1, paddingHorizontal: screenWidth * 0.015, }}>


                                        <View style={{
                                            flex: 1,
                                        }}>

                                            <View style={{ paddingVertical: 50 }}>
                                                <View style={{
                                                    // alignItems: "center",
                                                    paddingHorizontal: 5
                                                }}>
                                                    <Text
                                                        style={{
                                                            fontSize: 24,
                                                            fontFamily: "Poppins Bold",
                                                            color: COLORS.headingsColor,
                                                            letterSpacing: 1,
                                                            lineHeight: 33,
                                                            // textAlign: "center",
                                                            paddingTop: clickedSubCategory !== "" ? 0 : 40,
                                                        }}
                                                    >
                                                        {decodeString(clickedSubCategory)}</Text>
                                                </View>
                                                <ListEmptyComponent />
                                                {!!listingsData.length && (
                                                    <FlatList
                                                        data={listingsData}
                                                        style={{ flex: 1 }}
                                                        renderItem={renderFeaturedItem}
                                                        keyExtractor={keyExtractor}
                                                        pagingEnabled
                                                        numColumns={2}
                                                        horizontal={false}
                                                        showsHorizontalScrollIndicator={false}
                                                        contentContainerStyle={{
                                                            paddingVertical: 20,
                                                            // backgroundColor: COLORS.red
                                                        }}
                                                        onMomentumScrollEnd={updateCurrentStoresSlideIndex}
                                                    />
                                                )}
                                            </View>

                                        </View>
                                    </View>
                                </>

                                {!listingsData.length && (!!timedOut || !!networkError) && (
                                    <View style={styles.noListingsWrap}>
                                        <Fontisto
                                            name="frowning"
                                            size={100}
                                            color={COLORS.primary_soft}
                                        />
                                        {!!timedOut && (
                                            <Text style={styles.noListingsMessage}>
                                                {__("homeScreenTexts.requestTimedOut", appSettings.lng)}
                                            </Text>
                                        )}

                                        <View style={styles.retryButton}>
                                            <AppButton title="Retry" onPress={handleRetry} />
                                        </View>
                                    </View>
                                )}


                            </View>
                            {/* No Listing Found */}
                            {/* Flash notification */}
                            <FlashNotification
                                falshShow={flashNotification}
                                flashMessage="Hello World!"
                            />
                        </ScrollView>
                    </>
                )}
            </View>
        </DrawerLayout>
    );
};

const styles = StyleSheet.create({
    categoriesRowWrap: {},
    container: {
        flex: 1,
        backgroundColor: "#fafafa",
    },
    featuredListingTop: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        paddingHorizontal: screenWidth * 0.015,
        paddingBottom: 15,
        paddingTop: 5,
        backgroundColor: COLORS.white,
    },
    itemSeparator: {
        height: "100%",
        width: 1.333,
        backgroundColor: COLORS.bg_dark,
    },
    listingSearchBtnContainer: {
        marginLeft: 5,
        marginRight: -10,
        backgroundColor: COLORS.primary,
        borderRadius: 50,
        padding: 8
    },
    ListingSearchContainer: {
        flex: 1,
        height: 45,
        marginHorizontal: 20,
        backgroundColor: COLORS.white,
        borderRadius: 50,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        paddingHorizontal: 15,
        elevation: 7,
        zIndex: 20,
        shadowColor: "#000",
        shadowRadius: 4,
        shadowOpacity: 0.2,
        shadowOffset: {
            height: -4,
            width: 2,
        },
        borderWidth: 1,
    },
    imageSearchContainer: {
        paddingTop: 0,
        paddingHorizontal: 10,
        // borderBottomRightRadius: 50,
        height: 240,
        width: '100%',
        // transform: [{ scaleX: 2 }],
        // borderBottomStartRadius: 200,
        // borderBottomEndRadius: 200,
        overflow: 'hidden',
    },
    child: {
        // top: -100,
        flex: 1,
        // transform: [{ scaleX: 0.5 }],
        alignItems: 'center',
        justifyContent: 'center'
    },
    listingTop: {
        width: "100%",
        // paddingTop: 100,
        zIndex: 1,
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: screenWidth * 0.03,
        paddingBottom: 10,
    },
    locationWrap: {
        maxWidth: screenWidth * 0.25,
        marginHorizontal: screenWidth * 0.015,
        backgroundColor: COLORS.white,
        borderRadius: 5,
        padding: 7,
    },
    locationContent: {
        flexDirection: "row",
        alignItems: "center",
        width: "100%",
    },
    locationContentText: {
        paddingHorizontal: 5,
        color: COLORS.text_gray,
    },
    loadMoreWrap: {
        marginBottom: 10,
    },
    loading: {
        justifyContent: "center",
        alignItems: "center",
        height: screenHeight - 120,
    },
    noListingsMessage: {
        fontSize: 18,
        color: COLORS.text_gray,
        marginVertical: 10,
    },
    noListingsWrap: {
        alignItems: "center",
        justifyContent: "center",
        flex: 1,
        paddingTop: 100
    },
    resetButton: {
        borderRadius: 5,
        borderWidth: 1,
        borderColor: COLORS.orange,
        paddingVertical: 6,
        paddingHorizontal: 12,
        marginHorizontal: screenWidth * 0.015,
    },
    retryButton: {
        width: "30%",
        alignItems: "center",
        justifyContent: "center",
    },
    searchInput: {
        flex: 1,
    },
    selectedCat: {
        fontSize: 12,
    },
    topCatSliderWrap: {
        position: "absolute",
        top: 244,
        paddingTop: 10,
        justifyContent: "center",
        backgroundColor: COLORS.white,
    },
    logo: {
        height: screenWidth * 0.4,
        width: screenWidth * 0.4,
        resizeMode: "cover",
    },
    logoWrap: {
        height: screenWidth * 0.4,
        width: screenWidth * 0.4,
        overflow: "hidden",
        borderRadius: 10,
        marginBottom: 10,
        alignSelf: "center"
    },
    storeCardListingCount: {
        fontSize: 13,
        fontWeight: "bold",
        color: COLORS.primary,
    },
    storeCardListingCountWrap: {
        backgroundColor: COLORS.primary_soft,
        paddingVertical: 5,
        paddingHorizontal: 10,
        color: COLORS.primary,
        borderRadius: 10
    },
    storeCardTitle: {
        fontWeight: "bold",
        fontSize: 14,
        // marginVertical: 5,
    },
    storeContent: {
        height: screenWidth * 0.6,
        width: screenWidth * 0.455,
        backgroundColor: COLORS.white,
        // overflow: "hidden",
        // alignItems: "center",
        paddingTop: 5,
        elevation: 3,
        borderRadius: 10,
        borderBottomLeftRadius: 5,
        borderBottomRightRadius: 5,
        marginHorizontal: screenWidth * 0.01,
    },
    storeWrap: {
        marginHorizontal: 5,
        // overflow: "hidden",
        shadowColor: "#000",
        shadowRadius: 4,
        shadowOpacity: 0.2,
        shadowOffset: {
            height: 2,
            width: 2,
        },
    },
    indicator: {
        height: 8,
        width: 50,
        backgroundColor: COLORS.gray,
        marginHorizontal: 5,
        borderRadius: 50
    },
    pagination: {
        flexDirection: "row",
        justifyContent: "center"
    },
});

export default SubCategoryDetails;


