/* eslint-disable no-unused-vars */
/* eslint-disable no-undef */
import React, { useState, useEffect, useCallback, useRef } from "react";
import {
  View,
  StyleSheet,
  Text,
  TouchableOpacity,
  TextInput,
  FlatList,
  Dimensions,
  Animated,
  ActivityIndicator,
  Keyboard,
  RefreshControl,
  ImageBackground,
  ScrollView,
} from "react-native";

// Expo Libraries
import Constants from "expo-constants";

// Vector Fonts
import { FontAwesome } from "@expo/vector-icons";
import { SimpleLineIcons } from "@expo/vector-icons";
import { Feather } from "@expo/vector-icons";
import { Fontisto } from "@expo/vector-icons";
import { Formik } from "formik";

// Custom Components & Constants
import { COLORS } from "../variables/color";
import TabScreenHeader from "../components/TabScreenHeader";
import { useStateValue } from "../StateProvider";
import api from "../api/client";
import { decodeString } from "../helper/helper";
import FlashNotification from "../components/FlashNotification";
import AppButton from "../components/AppButton";
import ListingCard from "../components/ListingCard";
import { paginationData } from "../app/pagination/paginationData";
import CategoryIcon from "../components/CategoryIcon";
import CategoryImage from "../components/CategoryImage";
import { __ } from "../language/stringPicker";
import { admobConfig } from "../app/services/adMobConfig";
import { routes } from "../navigation/routes";
import PremiumAds from "../components/PremiumAds";

const { width: screenWidth, height: screenHeight } = Dimensions.get("screen");
const { height: windowHeight } = Dimensions.get("window");

const AllListingScreen = ({ navigation }) => {
  const [
    { search_locations, config, search_categories, cat_name, ios, appSettings },
    dispatch,
  ] = useStateValue();
  const [topCategoriesData, setTopCategoriesData] = useState([]);
  const [pagination, setPagination] = useState({});
  const [searchData, setSearchData] = useState(() => {
    return {
      ...paginationData.home,
      search: "",
      categories: "",
      page: pagination.current_page || 1,
      onScroll: false,
      per_page: 20,
    };
  });
  const [locationsData, setLocationsData] = useState([]);
  const [listingsData, setListingsData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [moreLoading, setMoreLoading] = useState(false);
  const [initial, setInitial] = useState(true);
  const [flashNotification, setFlashNotification] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [timedOut, setTimedOut] = useState();
  const [networkError, setNetworkError] = useState();
  const [retry, setRetry] = useState(false);
  const [scrollButtonVisible, setScrollButtonVisible] = useState(false);

  const iosFlatList = useRef(null);

  // Search on Location Change
  useEffect(() => {
    if (!search_locations) return;
    setSearchData((prevSearchData) => {
      return {
        ...prevSearchData,
        locations: search_locations
          .map((location) => location.term_id)
          .splice(search_locations.length - 1),
        page: 1,
        per_page: 20,
      };
    });
    setLoading(true);
  }, [search_locations]);

  // Search on Category Change from All Category Page
  useEffect(() => {
    if (!search_categories.length) return;
    setSearchData((prevSearchData) => {
      return {
        ...prevSearchData,
        categories: search_categories[search_categories.length - 1],
        page: 1,
        per_page: 20,
      };
    });
    setLoading(true);
  }, [search_categories]);

  // Initial Load Listings Data
  useEffect(() => {
    if (!initial) return;
    dispatch({
      type: "SET_NEW_LISTING_SCREEN",
      newListingScreen: false,
    });
    handleLoadTopCategories();
    if (config.location_type === "local") {
      handleLoadLocations();
    }
    handleLoadListingsData();
  }, [initial]);

  useEffect(() => {
    if (!loading) return;
    if (!retry) {
      dispatch({
        type: "SET_NEW_LISTING_SCREEN",
        newListingScreen: false,
      });
      handleLoadListingsData();
    } else {
      handleLoadTopCategories();
      if (config.location_type === "local") {
        handleLoadLocations();
      }
      handleLoadListingsData();
    }
  }, [loading]);

  // Get Listing on Next Page Request
  useEffect(() => {
    if (!searchData.onScroll) return;

    handleLoadListingsData(true);
  }, [searchData.onScroll]);

  // Refreshing get listing call
  useEffect(() => {
    if (!refreshing) return;
    setSearchData((prevSearchData) => {
      return {
        ...prevSearchData,
        page: 1,
        per_page: 20,
      };
    });
    setPagination({});
    handleLoadListingsData();
  }, [refreshing]);

  const onRefresh = () => {
    if (moreLoading) return;
    setRefreshing(true);
  };

  const handleLoadLocations = () => {
    api.get("locations").then((res) => {
      if (res.ok) {
        setLocationsData(res.data);
      } else {
        // print error
        // TODO handle error
        if (res.problem === "CANCEL_ERROR") {
          return true;
        }
      }
    });
  };

  const handleLoadListingsData = (onScroll) => {
    const location = search_locations.length
      ? search_locations.map((location) => location.term_id)
      : "";

    const s = { ...searchData, locations: location };
    api.get("listings/", searchData).then((res) => {
      if (res.ok) {
        if (refreshing) {
          setRefreshing(false);
        }
        if (onScroll) {
          if (admobConfig.admobEnabled) {
            setListingsData((prevListingsData) => [
              ...prevListingsData,
              { listAd: true },
              { listAd: true, dummy: true },
              ...res.data.data,
            ]);
          } else {
            setListingsData((prevListingsData) => [
              ...prevListingsData,
              ...res.data.data,
            ]);
          }
          setSearchData((prevSearchData) => {
            return {
              ...prevSearchData,
              onScroll: false,
            };
          });
        } else {
          setListingsData(res.data.data);
        }
        console.log("pagination ---- ", res.data.pagination);
        setPagination(res.data.pagination ? res.data.pagination : {});
        if (initial) {
          setInitial(false);
        }
        setLoading(false);
      } else {
        if (refreshing) {
          setRefreshing(false);
        }

        // print error
        // TODO handle error
        if (res.problem === "CANCEL_ERROR") {
          return true;
        }
        if (res.problem === "TIMEOUT_ERROR") {
          setTimedOut(true);
        }
      }
      setMoreLoading(false);
      setLoading(false);
    });
  };
  const handleNextPageLoading = () => {
    // if (!searchData.onScroll) return;
    console.log("handleNextPageLoading called()-----");
    if (pagination && pagination.total_pages > pagination.current_page) {
      setMoreLoading(true);
      setSearchData((prevSearchData) => {
        return {
          ...prevSearchData,
          page: prevSearchData.page + 1,
          onScroll: true,
          per_page: 20,
        };
      });
    }
  };
  const handleLoadTopCategories = () => {
    api.get("categories").then((res) => {
      if (res.ok) {
        setTopCategoriesData(res.data);
        dispatch({
          type: "SET_CATEGORIES_DATA",
          categories_data: res.data,
        });
      } else {
        if (res.problem === "CANCEL_ERROR") {
          return true;
        }
        // print error
        // TODO handle error
      }
    });
  };
  const handleSelectCategory = (item) => {
    setSearchData((prevSearchData) => {
      return { ...prevSearchData, categories: item.term_id, page: 1 };
    });
    dispatch({
      type: "SET_CAT_NAME",
      cat_name: [item.name],
    });
    setLoading(true);
  };

  const scrollY = new Animated.Value(0);
  const diffClamp = Animated.diffClamp(scrollY, 0, 100);
  const translateY = diffClamp.interpolate({
    inputRange: [0, 100],
    outputRange: [0, -100],
  });

  const Category = ({ onPress, item }) => (
    <TouchableOpacity
      onPress={() => onPress(item)}
      style={{
        justifyContent: "center",
        alignItems: "center",
        width: screenWidth / 5,
        padding: 5,
      }}
    >
      <View
        style={{
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        {item?.icon?.url ? (
          <CategoryImage size={27} uri={item.icon.url} />
        ) : (
          <CategoryIcon
            iconName={item.icon.class}
            iconSize={27}
            iconColor={COLORS.primary}
          />
        )}
        <Text
          style={{
            marginTop: 5,
            color: COLORS.text_gray,
            fontWeight: "bold",
            fontSize: 13,
          }}
          numberOfLines={1}
        >
          {decodeString(item.name).split(" ")[0]}
        </Text>
      </View>
    </TouchableOpacity>
  );
  const renderCategory = useCallback(
    ({ item }) => <Category onPress={handleSelectCategory} item={item} />,
    [refreshing, config]
  );

  const keyExtractor = useCallback((item, index) => `${index}`, []);

  const renderFeaturedItem = useCallback(
    ({ item }) => (
      <View style={{ marginBottom: 15 }}>
        <ListingCard
          onPress={() =>
            navigation.navigate(routes.listingDetailScreen, {
              listingId: item.listing_id,
            })
          }
          data={item}
        />
      </View>
    ),
    [refreshing, config]
  );

  const featuredListFooter = () => {
    if (pagination && pagination.total_pages > pagination.current_page) {
      return (
        <View style={styles.loadMoreWrap}>
          <ActivityIndicator size="small" color={COLORS.primary} />
        </View>
      );
    } else {
      return null;
    }
  };

  const handleSearch = (values) => {
    Keyboard.dismiss();
    setSearchData((prevSearchData) => {
      return { ...prevSearchData, search: values.search };
    });
    setLoading(true);
  };

  const handleReset = () => {
    setSearchData({
      categories: "",
      locations: "",
      onScroll: false,
      page: 1,
      per_page: 20,
      search: "",
      city: "",
    });
    dispatch({
      type: "SET_SEARCH_LOCATIONS",
      search_locations: [],
    });
    dispatch({
      type: "SET_SEARCH_CATEGORIES",
      search_categories: [],
    });
  };

  const onAndroidFeaturedListingScroll = (e) => {
    scrollY.setValue(e.nativeEvent.contentOffset.y);
  };
  const onIOSFeaturedListingScroll = (e) => {
    if (!scrollButtonVisible && e.nativeEvent.contentOffset.y > 300) {
      setScrollButtonVisible(true);
    }
    if (scrollButtonVisible && e.nativeEvent.contentOffset.y < 300) {
      setScrollButtonVisible(false);
    }
  };

  const getSelectedCat = (urg) => {
    return decodeString(urg);
  };

  const ListHeader = () => {
    return (
      <View>
        <View style={styles.imageSearchContainer}>
          <View style={styles.child}>
            <PremiumAds admob={false} />
            <View style={{ position: "absolute", left: 0, right: 0, top: 20 }}>
              <View style={styles.listingTop}>
                <Formik initialValues={{ search: "" }} onSubmit={handleSearch}>
                  {({ handleChange, handleBlur, handleSubmit, values }) => (
                    <View style={styles.ListingSearchContainer}>
                      <TextInput
                        style={styles.searchInput}
                        placeholder={
                          searchData.search ||
                          __(
                            "homeScreenTexts.listingSearchPlaceholder",
                            appSettings.lng
                          )
                        }
                        placeholderTextColor={COLORS.textGray}
                        onChangeText={handleChange("search")}
                        onBlur={() => {
                          handleBlur("search");
                        }}
                        value={values.search}
                        returnKeyType="search"
                        onSubmitEditing={handleSubmit}
                      />

                      <TouchableOpacity
                        onPress={handleSubmit}
                        disabled={!values.search || timedOut || networkError}
                        style={styles.listingSearchBtnContainer}
                      >
                        {/* <Feather
                                                    name="search"
                                                    size={20}
                                                    color={values.search ? COLORS.white : COLORS.white}
                                                /> */}
                        <Text style={{ color: "#fff" }}>Search</Text>
                      </TouchableOpacity>
                    </View>
                  )}
                </Formik>
              </View>
            </View>
          </View>
        </View>

        <View
          style={{
            alignItems: "center",
            marginBottom: 20,
            paddingTop: 20,
          }}
        >
          <Text
            style={{
              fontSize: 24,
              fontFamily: "Poppins Bold",
              color: COLORS.headingsColor,
              letterSpacing: 1,
              lineHeight: 33,
            }}
          >
            Latest Ads
          </Text>
        </View>
      </View>
    );
  };

  const handleSeeAll = () => {
    navigation.navigate(routes.selectcategoryScreen, {
      data: topCategoriesData,
    });
  };

  const handleRetry = () => {
    setLoading(true);
    if (timedOut) setTimedOut(false);
  };

  return (
    <View style={styles.container}>
      <TabScreenHeader
        style={{ elevation: 0, zIndex: 2 }}
        left
        onLeftClick={() => navigation.goBack()}
      />
      {/* Loading Animation */}
      {loading ? (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={COLORS.primary} />
          <Text style={styles.text}>
            {__("homeScreenTexts.loadingMessage", appSettings.lng)}
          </Text>
        </View>
      ) : (
        <>
          {/* FlatList */}
          {!!listingsData.length && (
            <>
              <View
                style={{
                  paddingHorizontal: screenWidth * 0.015,
                  height:
                    screenHeight - Constants.statusBarHeight - 50 - 45 - 50,
                }}
              >
                <Animated.FlatList
                  data={listingsData}
                  renderItem={renderFeaturedItem}
                  keyExtractor={keyExtractor}
                  horizontal={false}
                  numColumns={2}
                  showsVerticalScrollIndicator={false}
                  onEndReached={handleNextPageLoading}
                  onEndReachedThreshold={1}
                  ListFooterComponent={featuredListFooter}
                  maxToRenderPerBatch={7}
                  windowSize={41}
                  onScroll={onAndroidFeaturedListingScroll}
                  contentContainerStyle={{
                    paddingBottom: screenHeight - windowHeight,
                  }}
                  ListHeaderComponent={ListHeader}
                  scrollEventThrottle={1}
                  bounces={false}
                />
              </View>
            </>
          )}
          {/* No Listing Found */}
          {!listingsData.length && !timedOut && !networkError && (
            <View style={styles.noListingsWrap}>
              <Fontisto
                name="frowning"
                size={100}
                color={COLORS.primary_soft}
              />
              <Text style={styles.noListingsMessage}>
                {__("homeScreenTexts.noListingsMessage", appSettings.lng)}
              </Text>
            </View>
          )}
          {/* Timeout & Network Error notice */}
          {!listingsData.length && (!!timedOut || !!networkError) && (
            <View style={styles.noListingsWrap}>
              <Fontisto
                name="frowning"
                size={100}
                color={COLORS.primary_soft}
              />
              {!!timedOut && (
                <Text style={styles.noListingsMessage}>
                  {__("homeScreenTexts.requestTimedOut", appSettings.lng)}
                </Text>
              )}

              <View style={styles.retryButton}>
                <AppButton title="Retry" onPress={handleRetry} />
              </View>
            </View>
          )}
          {/* Flash notification */}
          <FlashNotification
            falshShow={flashNotification}
            flashMessage="Hello World!"
          />
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  categoriesRowWrap: {},
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  featuredListingTop: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: screenWidth * 0.015,
    paddingBottom: 15,
    paddingTop: 5,
  },
  itemSeparator: {
    height: "100%",
    width: 1.333,
    backgroundColor: COLORS.bg_dark,
  },
  listingSearchBtnContainer: {
    marginLeft: 5,
    marginRight: -10,
    backgroundColor: COLORS.primary,
    borderRadius: 5,
    padding: 8,
  },
  ListingSearchContainer: {
    flex: 1,
    height: 45,
    marginHorizontal: 10,
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderRadius: 4,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 15,
    elevation: 7,
    zIndex: 20,
    shadowColor: "#000",
    shadowRadius: 4,
    shadowOpacity: 0.2,
    shadowOffset: {
      height: -4,
      width: 2,
    },
  },
  imageSearchContainer: {
    paddingTop: 0,
    paddingHorizontal: 10,

    height: 250,
    width: "100%",
    backgroundColor: "#fff",
    // transform: [{ scaleX: 2 }],
    overflow: "hidden",
  },
  locationWrap: {
    maxWidth: screenWidth * 0.25,
    marginHorizontal: screenWidth * 0.015,
    backgroundColor: COLORS.white,
    borderRadius: 5,
    padding: 7,
  },
  locationContent: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%",
  },
  locationContentText: {
    paddingHorizontal: 5,
    color: COLORS.text_gray,
  },
  loadMoreWrap: {
    marginBottom: 10,
  },
  loading: {
    justifyContent: "center",
    alignItems: "center",
    height: screenHeight - 120,
  },
  noListingsMessage: {
    fontSize: 18,
    color: COLORS.text_gray,
    marginVertical: 10,
  },
  noListingsWrap: {
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
  },
  resetButton: {
    borderRadius: 5,
    borderWidth: 1,
    borderColor: COLORS.white,
    paddingVertical: 6,
    paddingHorizontal: 12,
    marginHorizontal: screenWidth * 0.015,
  },
  retryButton: {
    width: "30%",
    alignItems: "center",
    justifyContent: "center",
  },
  searchInput: {
    flex: 1,
  },
  selectedCat: {
    fontSize: 12,
  },
  topCatSliderWrap: {
    position: "absolute",
    top: 94,
    zIndex: 1,
    justifyContent: "center",
    backgroundColor: COLORS.white,
  },

  child: {
    // top: -100,
    flex: 1,
    // transform: [{ scaleX: 0.5 }],
    alignItems: "center",
    justifyContent: "center",
  },
  listingTop: {
    width: "100%",
    // paddingTop: 100,
    zIndex: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: screenWidth * 0.03,
    paddingBottom: 10,
  },
});

export default AllListingScreen;
