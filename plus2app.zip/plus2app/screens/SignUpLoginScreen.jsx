/* eslint-disable no-unused-vars */
import React from "react";
import {
    StyleSheet,
    View,
    ScrollView,
    KeyboardAvoidingView,
    Platform,
    Dimensions,
} from "react-native";

// Custom Components & Functions
import {TabView, SceneMap, TabBar} from 'react-native-tab-view';
import {COLORS} from "../variables/color";
import TabScreenHeader from "../components/TabScreenHeader";
import { useWindowDimensions } from 'react-native';
import SignUpScreen from "./SignUpScreen";
import LoginScreen from "./LoginScreen";
import PremiumAds from "../components/PremiumAds";

const FirstRoute = () => (
    <LoginScreen/>
)

const SecondRoute = () => (
    <SignUpScreen/>
);

const renderScene = SceneMap({
    first: FirstRoute,
    second: SecondRoute,
});

const renderTabBar = props => (
    <TabBar
        {...props}
        indicatorStyle={{backgroundColor: "transparent"}}
        style={{
            backgroundColor: COLORS.white,
        }}
        activeColor={COLORS.primary}
        inactiveColor={COLORS.black}
        labelStyle={{
            textTransform: "capitalize",
            fontFamily: "Poppins Bold",
            fontSize: 19,
        }}
    />
);
const {width: screenWidth, height: screenHeight} = Dimensions.get("screen");
const SignUpLoginScreen = ({navigation}) => {
    const layout = useWindowDimensions();

    const [index, setIndex] = React.useState(0);
    const [routes] = React.useState([
        {key: 'first', title: 'Login'},
        {key: 'second', title: 'Register'},
    ]);
    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" ? "padding" : "height"}
            style={{
                flex: 1,
                backgroundColor: COLORS.white
            }}
            keyboardVerticalOffset={80}
            keyboardShouldPersistTaps="never"
        >
            <TabScreenHeader
                left
                onLeftClick={() => navigation.goBack()}
                style={{elevation: 0, zIndex: 2}}/>
            <ScrollView
                showsVerticalScrollIndicator={false}
                contentContainerStyle={[styles.container, {paddingBottom: 0}]}
            >
                <View style={styles.imageSearchContainer}>
                    {/* eslint-disable-next-line no-undef */}
                    <View style={styles.child}>
                        <PremiumAds admob={false}/>
                    </View>
                </View>
                <View style={[styles.loginContainer, {height: index === 0 ? 450 : 900}]}>
                    <TabView
                        navigationState={{index, routes}}
                        renderScene={renderScene}
                        renderTabBar={renderTabBar}
                        onIndexChange={setIndex}
                        initialLayout={{width: layout.width}}
                        style={{
                            borderRadius: 20
                        }}
                    />
                </View>
            </ScrollView>

        </KeyboardAvoidingView>
    );
};

const styles = StyleSheet.create({
    loginContainer: {
        backgroundColor: COLORS.white,
        flex: 1,
        width: "90%",
        top: -90,
        borderRadius: 20,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
    },
    cancelResetBtn: {
        color: "gray",
    },
    centeredView: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        marginTop: 22,
    },
    container: {
        alignItems: "center",
        paddingTop: 10,
    },
    errorFieldWrap: {
        height: 15,
        justifyContent: "center",
    },
    errorMessage: {
        fontSize: 12,
        color: COLORS.red,
    },
    input: {
        backgroundColor: "#e3e3e3",
        width: "95%",
        marginVertical: 10,
        height: 50,
        justifyContent: "center",
        borderRadius: 10,
        paddingHorizontal: 10,
    },
    inputWrap: {
        width: "100%",
        paddingHorizontal: 15,
    },
    loginBtn: {
        height: 40,
        borderRadius: 50,
        marginVertical: 10,
        width: "50%",
    },
    loginBtnWrap: {
        display: "flex",
        flexDirection: "row",
        width: "100%",
        paddingHorizontal: 15,
        alignContent: "center",
        alignItems: "center",
    },
    loginForm: {
        width: "100%",
    },
    loginNotice: {
        fontSize: 16,
        color: "#111",
        marginVertical: 20,
    },
    modalEmail: {
        backgroundColor: "#e3e3e3",
        width: "95%",
        marginVertical: 10,
        height: 38,
        justifyContent: "center",
        borderRadius: 3,
        paddingHorizontal: 10,
    },
    modalText: {
        marginBottom: 15,
        textAlign: "center",
    },
    modalView: {
        margin: 20,
        backgroundColor: "white",
        borderRadius: 3,
        padding: 35,
        alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
        width: "90%",
    },
    resetLink: {
        height: 40,
        borderRadius: 3,
        marginVertical: 10,
        width: "60%",
    },
    responseErrorMessage: {
        color: COLORS.red,
        fontWeight: "bold",
        fontSize: 15,
    },
    responseErrorWrap: {
        marginVertical: 10,
        alignItems: "center",
    },
    signUpPrompt: {},
    socialLogin: {
        marginHorizontal: 15,
    },
    socialLoginWrap: {
        marginBottom: 10,
        width: "100%",
        paddingHorizontal: 20,
    },
    socialOverlayWrap: {
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: "center",
        justifyContent: "center",
    },
    imageSearchContainer: {
        paddingTop: 0,
        paddingHorizontal: 15,
        borderBottomRightRadius: 50,
        height: 240,
        width: '100%',
        transform: [{scaleX: 2}],
        borderBottomStartRadius: 200,
        borderBottomEndRadius: 200,
        overflow: 'hidden',
    },
    child: {
        // top: -100,
        flex: 1,
        transform: [{scaleX: 0.5}],
        alignItems: 'center',
        justifyContent: 'center'
    },
    listingTop: {
        width: "100%",
        // paddingTop: 100,
        zIndex: 1,
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: screenWidth * 0.03,
        paddingBottom: 10,
    },
    searchInput: {
        flex: 1,
    },
    listingSearchBtnContainer: {
        marginLeft: 5,
        marginRight: -10,
        backgroundColor: COLORS.primary,
        borderRadius: 50,
        padding: 8
    },
    ListingSearchContainer: {
        flex: 1,
        height: 45,
        marginHorizontal: 20,
        backgroundColor: COLORS.white,
        borderRadius: 50,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        paddingHorizontal: 15,
        elevation: 7,
        zIndex: 20,
        shadowColor: "#000",
        shadowRadius: 4,
        shadowOpacity: 0.2,
        shadowOffset: {
            height: -4,
            width: 2,
        },
    },
});

export default SignUpLoginScreen;


