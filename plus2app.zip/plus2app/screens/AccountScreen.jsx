import React, {useEffect, useState} from "react";
import {View, Text, StyleSheet, ScrollView} from "react-native";

// Custom Components & Constants
import {COLORS} from "../variables/color";
import Option from "../components/Option";
import AppButton from "../components/AppButton";
import authStorage from "../app/auth/authStorage";
import AppSeparator from "../components/AppSeparator";
import {useStateValue} from "../StateProvider";
import {__} from "../language/stringPicker";
import {routes} from "../navigation/routes";
import {useNavigation} from '@react-navigation/native';
import api, {removeAuthToken, setAuthToken} from "../api/client";

const AccountScreen = () => {
        const navigation = useNavigation();
        const [{auth_token, user, appSettings}, dispatch] = useStateValue();
        const [businessData, setBusinessData] = useState([]);
        const [professionalData, setProfessionalData] = useState([]);


        useEffect(() => {
            setAuthToken(auth_token);
            api.get("my/listings").then((res) => {
                if (res.ok) {
                    const array = res.data.data;
                    for (let i = 0; i < array.length; i++) {
                        if (array[i].categories[0].term_id === 353) {
                            setProfessionalData(array[i])
                        }
                    }
                    removeAuthToken();
                } else {
                    setProfessionalData([]);
                }
            })
        }, []);
        useEffect(() => {
            setAuthToken(auth_token);
            api.get("my/listings").then((res) => {
                if (res.ok) {
                    const array = res.data.data;
                    for (let i = 0; i < array.length; i++) {
                        if (array[i].categories[0].term_id === 498) {
                            setBusinessData(array[i])
                        }
                    }
                    removeAuthToken();
                } else {
                    setBusinessData([]);
                }
            })
        }, []);


        const handleLogout = () => {
            dispatch({
                type: "SET_AUTH_DATA",
                data: {
                    user: null,
                    auth_token: null,
                },
            });
            authStorage.removeUser();
            setProfessionalData([])
            setBusinessData([])
        };

        const getUsername = () => {
            if (!!user.first_name || !!user.last_name) {
                return [user.first_name, user.last_name].join(" ");
            } else {
                return user.username;
            }
        };

        return (
            <View style={styles.container}>
                {/* UserName Component */}
                {user && (
                    <>
                        <View style={styles.userNameContainer}>
                            <Text style={styles.userNameText}>{getUsername()}</Text>
                        </View>
                        <View style={{alignItems: "center"}}>
                            <AppSeparator style={{width: "94%"}}/>
                        </View>
                    </>
                )}
                {/* User logged out component */}
                {!user && (
                    <View>
                        <View style={styles.loginWrap}>
                            <AppButton
                                title={__("accountScreenTexts.loginButtonText", appSettings.lng)}
                                style={styles.loginButton}
                                onPress={() => navigation.navigate(routes.signuploginScreen)}
                            />
                        </View>
                        <Option
                            key={"advertise"}
                            title={"Advertise With Us"}
                            item={"Advertise With Us"}
                        />
                        <Option
                            key={"faq"}
                            title={"FAQ"}
                            onPress={() => navigation.navigate("FAQ")}
                            item={"FAQ"}
                        />
                        <Option
                            key={"about_us"}
                            title={"About Plus2App"}
                            onPress={() => navigation.navigate("More")}
                            item={"About"}
                        />
                        <Option
                            key={"rate"}
                            title={"Rate Us"}
                            // onPress={() => navigation.navigate("More")}
                            item={"Rate"}
                        />
                    </View>
                )}
                {/* Account Options Flatlist */}

                <View Style={styles.optionsContainer}>
                    {user && (
                        <ScrollView>
                            <Option
                                key={"account_settings"}
                                title={"Account Settings"}
                                onPress={() => navigation.navigate(routes.editPersonalDetailScreen, {data: user})}
                                item={"Account Settings"}
                            />
                            <Option
                                key={"my_listing"}
                                title={"My Listings"}
                                onPress={() => navigation.navigate("My Listings")}
                                item={"My Listings"}
                            />
                            <Option
                                key={"my_payments"}
                                title={"My Payments"}
                                onPress={() => navigation.navigate(routes.paymentsScreen)}
                                item={"My Payments"}
                            />
                            {!businessData.title && !professionalData.title ? (
                                <>
                                    <Option
                                        key={"register_business"}
                                        title={businessData.title ? "View my Business Profile" : "Open Business Profile"}
                                        onPress={() => navigation.navigate(businessData.title ? "Business Profile" : "New Business Service", {
                                            category: 498,
                                            business_id: businessData.listing_id
                                        })}
                                        item={"Your Business"}
                                    />
                                    <Option
                                        key={"register_service_provider"}
                                        title={professionalData.title ? "View professional profile" : "Open Professional Profile"}
                                        onPress={() => navigation.navigate(professionalData.title ? "Business Profile" : "New Business Service", {
                                            category: 353,
                                            business_id: professionalData.listing_id
                                        })}
                                        item={"Service Provider"}
                                    />
                                </>
                            ) : (
                                <Option
                                    key={"view_business_or_professional"}
                                    title={professionalData.title ? "View Professional profile" : "View Business Profile"}
                                    onPress={() => navigation.navigate("Business Profile", {
                                        category: professionalData.title ? 353 : 498,
                                        business_id: professionalData.listing_id ? professionalData.listing_id : businessData.listing_id
                                    })}
                                    item={"Service Provider"}
                                />
                            )}
                            <Option
                                key={"advertise"}
                                title={"Advertise With Us"}
                                // onPress={() => navigation.navigate("New Business Service", {category: 338})}
                                item={"Advertise With Us"}
                            />
                            <Option
                                key={"faq"}
                                title={"FAQ"}
                                onPress={() => navigation.navigate("FAQ")}
                                item={"FAQ"}
                            />
                            <Option
                                key={"about_us"}
                                title={"About Plus2App"}
                                onPress={() => navigation.navigate("More")}
                                item={"About"}
                            />
                            <Option
                                key={"rate"}
                                title={"Rate Us"}
                                // onPress={() => navigation.navigate("More")}
                                item={"Rate"}
                            />
                            <View style={styles.logOutWrap}>
                                <Option
                                    title={__(
                                        "accountScreenTexts.logOutButtonText",
                                        appSettings.lng
                                    )}
                                    onPress={() => handleLogout()}
                                    item={{
                                        id: "log_out",
                                    }}
                                />
                            </View>
                        </ScrollView>
                    )}
                </View>
            </View>
        );
    }
;

const styles = StyleSheet.create({
    container: {
        backgroundColor: COLORS.white,
        flex: 1,
    },
    headerMain: {
        alignItems: "center",
        flex: 1,
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: "bold",
        color: COLORS.white,
    },
    headerWrap: {
        backgroundColor: COLORS.primary,
        paddingHorizontal: "3%",
        flexDirection: "row",
        height: 50,
        alignItems: "center",
        justifyContent: "space-between",
    },
    loginButton: {
        paddingVertical: 10,
        borderRadius: 3,
    },
    loginWrap: {
        flexDirection: "row",
        paddingHorizontal: "3%",
        marginVertical: 40,
        alignItems: "center",
        justifyContent: "space-evenly",
    },
    logOutWrap: {
        paddingBottom: 50,
    },
    optionsContainer: {
        flex: 1,
    },
    userNameContainer: {
        paddingHorizontal: 15,
        paddingVertical: 20,
    },
    userNameText: {
        fontSize: 20,
        color: "#444",
        fontFamily: "Poppins Bold"
    },
});

export default AccountScreen;
