import React, {useState, useEffect, useCallback, useRef} from "react";
import {
    View,
    Text,
    StyleSheet,
    FlatList,
    ActivityIndicator,
    Image,
    Dimensions,
    TouchableOpacity, RefreshControl, ScrollView, ImageBackground, TextInput,
} from "react-native";

// Custom Components & Constants
import api from "../api/client";
import {paginationData} from "../app/pagination/paginationData";
import {COLORS} from "../variables/color.js";
import {useStateValue} from "../StateProvider";
import {__} from "../language/stringPicker";
import {routes} from "../navigation/routes";
import TabScreenHeader from "../components/TabScreenHeader";
import AccountScreen from "./AccountScreen";
import {useNavigation} from "@react-navigation/native";
import {DrawerLayout} from "react-native-gesture-handler";
import {Formik} from "formik";
import {Feather} from "@expo/vector-icons";
import {decodeString, stripString} from "../helper/helper";
import PremiumAds from "../components/PremiumAds";

const {width: windowWidth} = Dimensions.get("window");

const allStoresFallBackImages = {
    storeCardLogo: require("../assets/200X150.png"),
};
const {width: screenWidth, height: screenHeight} = Dimensions.get("screen");
const AllStores = () => {
    const [{appSettings}] = useStateValue();
    const [loading, setLoading] = useState(true);
    const [storesData, setStoresData] = useState([]);
    const [refreshing, setRefreshing] = useState(false);
    const [moreLoading, setMoreLoading] = useState(false);
    const [pagination, setPagination] = useState({});
    const [currentPage, setCurrentPage] = useState(
        pagination.page || paginationData.allStores.page
    );
    //  Initial Call
    useEffect(() => {
        getStoresData(paginationData.allStores);
    }, []);

    // Refreshing get listing call
    useEffect(() => {
        if (!refreshing) return;
        setCurrentPage(1);
        setPagination({});
        getStoresData(paginationData.allStores);
    }, [refreshing]);

    // next page get listing call
    useEffect(() => {
        if (!moreLoading) return;
        const data = {
            per_page: paginationData.allStores.per_page,
            page: currentPage,
        };
        getStoresData(data);
    }, [moreLoading]);

    const getStoresData = (paginationData) => {
        api.get("stores", paginationData).then((res) => {
            if (res.ok) {
                if (refreshing) {
                    setRefreshing(false);
                }
                if (moreLoading) {
                    setStoresData((prevStoresData) => [
                        ...prevStoresData,
                        ...res.data.data,
                    ]);
                    setMoreLoading(false);
                } else {
                    setStoresData(res.data.data.splice(0, 16));
                }
                setPagination(res.data.pagination ? res.data.pagination : {});

                if (loading) {
                    setLoading(false);
                }
            } else {
                // print error
                if (refreshing) {
                    setRefreshing(false);
                }
                // TODO handle error
                if (moreLoading) {
                    setMoreLoading(false);
                }
                if (loading) {
                    setLoading(false);
                }
            }
        });
    };

    const renderListItem = useCallback(
        ({item}) => <StoreCard item={item}/>,
        []
    );

    const handleStoreCardPress = (item) => {
        navigation.navigate(routes.storeDetailsScreen, {storeId: item.id});
    };
    const StoreCard = ({item}) => (
        <View style={styles.storeWrap}>
            <View style={{
                height: 80,
                bottom: -10,
                backgroundColor: COLORS.white,
                opacity: .99,
                elevation: 1,
                overflow: "visible",
                width: screenWidth * 0.405,
                alignSelf: "center",
                position: "absolute",
                marginHorizontal: screenWidth * 0.015,
                borderRadius: 10,
                padding: 5,
                shadowColor: "#000",
                shadowRadius: 4,
                shadowOpacity: 0.2,
                shadowOffset: {
                    height: 2,
                    width: 2,
                },
            }}/>
            <TouchableOpacity
                style={styles.storeContent}
                onPress={() => handleStoreCardPress(item)}
            >
                <View style={styles.logoWrap}>
                    {item.logo ? (
                        <Image source={{uri: item.logo}} style={styles.logo}/>
                    ) : (
                        <Image
                            source={allStoresFallBackImages.storeCardLogo}
                            style={styles.logo}
                        />
                    )}
                </View>
                <View style={{
                    flex: 1,
                    flexDirection: "row",
                    justifyContent: "space-between",
                    paddingHorizontal: 10,
                    alignItems: "center"
                }}>
                    {item.title ? (
                        <Text style={styles.storeCardTitle} numberOfLines={1}>
                            {decodeString(item.title)}
                        </Text>
                    ) : (
                        <Text style={styles.storeCardTitle} numberOfLines={1}>
                            No title
                        </Text>
                    )}
                </View>
                <View style={styles.storeCardListingCountWrap}>
                    <Text style={styles.storeCardListingCount}>
                        {item.listings_count ? item.listings_count : 0}{" "}
                        {__("allStoresTexts.storeAdCount", appSettings.lng)}
                    </Text>
                </View>
            </TouchableOpacity>
        </View>
    );

    const keyExtractor = useCallback((item, index) => `${index}`, []);
    const EmptyListComponent = () => (
        <View>
            <Text>{__("allStoresTexts.noShopText", appSettings.lng)}</Text>
        </View>
    );
    const listFooter = () => {
        if (pagination && pagination.total_pages > pagination.current_page) {
            return (
                <View style={styles.loadMoreWrap}>
                    <ActivityIndicator size="small" color={COLORS.primary}/>
                </View>
            );
        } else {
            return null;
        }
    };

    const onRefresh = () => {
        if (moreLoading) return;
        setRefreshing((prevRefreshing) => true);
    };

    const handleNextPageLoading = () => {
        if (refreshing) return;
        if (pagination && pagination.total_pages > pagination.current_page) {
            setCurrentPage((prevCurrentPage) => prevCurrentPage + 1);
            setMoreLoading(true);
        }
    };
    const drawer = useRef(null);
    const [drawerPosition] = useState("left");

    const navigationView = () => (
        // eslint-disable-next-line no-undef
        <View style={[styles.container]}>
            <AccountScreen/>
        </View>
    );
    const navigation = useNavigation();

    const [currentStoresSlideIndex, setCurrentStoresSlideIndex] = React.useState(0);
    const updateCurrentStoresSlideIndex = e => {
        const contentOffsetX = e.nativeEvent.contentOffset.x;
        const currentIndex = Math.round(contentOffsetX / screenWidth);
        setCurrentStoresSlideIndex(currentIndex)
    }

    const [currentPremiumStoresSlideIndex, setCurrentPremiumStoresSlideIndex] = React.useState(0);
    const updateCurrentPremiumStoresSlideIndex = e => {
        const contentOffsetX = e.nativeEvent.contentOffset.x;
        const currentIndex = Math.round(contentOffsetX / screenWidth);
        setCurrentPremiumStoresSlideIndex(currentIndex)
    }

    return (
        <DrawerLayout
            ref={drawer}
            drawerWidth={380}
            drawerPosition={drawerPosition}
            renderNavigationView={navigationView}
            drawerBackgroundColor={"#ffffff"}>
            <View style={styles.contentContainer}>
                <TabScreenHeader
                    drawer
                    showDrawer={() => drawer.current.openDrawer()}
                    style={{elevation: 0, zIndex: 2}}/>
                {loading ? (

                    <View style={styles.loading}>
                        <ActivityIndicator size="large" color={COLORS.primary}/>
                        <Text>{__("allStoresTexts.loadingText", appSettings.lng)}</Text>
                    </View>
                ) : (
                    <ScrollView
                        showsVerticalScrollIndicator={false}
                        refreshControl={
                            <RefreshControl
                                onRefresh={onRefresh}
                                refreshing={refreshing}
                            />
                        }>
                        <View style={styles.imageSearchContainer}>
                            <View style={styles.child}>
                                <PremiumAds admob={false}/>
                                <View style={{position: 'absolute', left: 0, right: 0, top:20,}}>
                                    <View style={styles.listingTop}>
                                        <Formik initialValues={{search: ""}}>
                                            {({handleChange, handleBlur, handleSubmit, values}) => (
                                                <View style={styles.ListingSearchContainer}>
                                                    <TextInput
                                                        style={styles.searchInput}
                                                        placeholder={
                                                            __(
                                                                "homeScreenTexts.listingSearchPlaceholder",
                                                                appSettings.lng
                                                            )
                                                        }
                                                        placeholderTextColor={COLORS.textGray}
                                                        onChangeText={handleChange("search")}
                                                        onBlur={() => {
                                                            handleBlur("search");
                                                        }}
                                                        value={values.search}
                                                        returnKeyType="search"
                                                        onSubmitEditing={handleSubmit}
                                                    />

                                                    <TouchableOpacity
                                                        onPress={handleSubmit}
                                                        style={styles.listingSearchBtnContainer}
                                                    >
                                                        <Feather
                                                            name="search"
                                                            size={20}
                                                            color={values.search ? COLORS.white : COLORS.white}
                                                        />
                                                    </TouchableOpacity>
                                                </View>
                                            )}
                                        </Formik>
                                    </View>
                                </View>
                            </View>
                        </View>
                        <View
                            style={{
                                backgroundColor: "#ffffff",
                                alignItems: "center",
                            }}>

                            {!!storesData.length && (
                                <View
                                    style={{
                                        paddingHorizontal: screenWidth * 0.015,
                                        marginBottom: 230
                                    }}
                                >
                                    <View style={styles.container}>
                                        {/* Stores List */}

                                        <View style={{
                                            alignItems: "center"
                                        }}>
                                            <Text
                                                style={{
                                                    fontSize: 24,
                                                    fontFamily: "Poppins Bold",
                                                    color: COLORS.headingsColor,
                                                    letterSpacing: 1,
                                                    lineHeight: 33,
                                                }}
                                            >Popular Stores</Text>
                                        </View>
                                        <FlatList
                                            data={storesData}
                                            style={{flex: 1}}
                                            renderItem={renderListItem}
                                            keyExtractor={keyExtractor}
                                            horizontal
                                            showsHorizontalScrollIndicator={false}
                                            bounces={false}
                                            contentContainerStyle={{
                                                paddingTop: 20,
                                                marginBottom: -100,
                                            }}
                                        />
                                        {/*<View>*/}
                                        {/*    <TouchableOpacity style={{justifyContent: "flex-end"}}*/}
                                        {/*                      onPress={() => navigation.navigate(routes.allListingScreen)}>*/}
                                        {/*        <Text*/}
                                        {/*            style={{*/}
                                        {/*                fontFamily: "Poppins Bold",*/}
                                        {/*                color: COLORS.primary,*/}
                                        {/*                textAlign: "right",*/}
                                        {/*                paddingRight: 15,*/}
                                        {/*                top: -10*/}
                                        {/*            }}>*/}
                                        {/*            See All*/}
                                        {/*        </Text>*/}
                                        {/*    </TouchableOpacity>*/}
                                        {/*</View>*/}

                                        <View style={{
                                            alignItems: "center"
                                        }}>
                                            <Text
                                                style={{
                                                    fontSize: 24,
                                                    fontFamily: "Poppins Bold",
                                                    color: COLORS.headingsColor,
                                                    letterSpacing: 1,
                                                    lineHeight: 33,
                                                }}
                                            >Latest Stores</Text>
                                        </View>
                                        <FlatList
                                            data={storesData}
                                            style={{flex: 1}}
                                            renderItem={renderListItem}
                                            keyExtractor={keyExtractor}
                                            numColumns={2}
                                            horizontal={false}
                                            showsHorizontalScrollIndicator={false}
                                            bounces={false}
                                            contentContainerStyle={{
                                                paddingTop: 20,
                                                marginBottom: -100,
                                            }}
                                        />
                                        {/*<View>*/}
                                        {/*    <TouchableOpacity style={{justifyContent: "flex-end"}}*/}
                                        {/*                      onPress={() => navigation.navigate(routes.allListingScreen)}>*/}
                                        {/*        <Text*/}
                                        {/*            style={{*/}
                                        {/*                fontFamily: "Poppins Bold",*/}
                                        {/*                color: COLORS.primary,*/}
                                        {/*                textAlign: "right",*/}
                                        {/*                paddingRight: 15,*/}
                                        {/*                top: -10*/}
                                        {/*            }}>*/}
                                        {/*            See All*/}
                                        {/*        </Text>*/}
                                        {/*    </TouchableOpacity>*/}
                                        {/*</View>*/}

                                    </View>
                                </View>
                            )}
                        </View>

                    </ScrollView>
                )}
            </View>
        </DrawerLayout>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.white,
    },
    contentContainer: {
        flex: 1,
        backgroundColor: COLORS.white,
    },
    adContainer: {
        flex: 1,
        borderRadius: 20,
        backgroundColor: COLORS.white,
        elevation: 5,
        top: -100,
        height: 150,
        marginBottom: 30,
        marginHorizontal: 20,
    },
    loading: {
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        opacity: 1,
        backgroundColor: "transparent",
        justifyContent: "center",
        alignItems: "center",
        flex: 1,
    },
    logo: {
        height: screenWidth * 0.4,
        width: screenWidth * 0.4,
        resizeMode: "cover",
    },
    logoWrap: {
        height: screenWidth * 0.4,
        width: screenWidth * 0.4,
        overflow: "hidden",
        borderRadius: 10,
        marginBottom: 10,
        alignSelf: "center"
    },
    storeCardListingCount: {
        fontSize: 13,
        color: COLORS.primary,
        fontFamily: "Poppins Bold"
    },
    storeCardListingCountWrap: {
        backgroundColor: COLORS.primary_soft,
        paddingVertical: 5,
        paddingHorizontal: 10,
        color: COLORS.primary,
        borderRadius: 10
    },
    storeCardTitle: {
        fontFamily: "Poppins Bold",
        fontSize: 14,
    },
    storeContent: {
        height: screenWidth * 0.6,
        width: screenWidth * 0.455,
        backgroundColor: COLORS.white,
        paddingTop: 5,
        elevation: 3,
        borderRadius: 10,
        marginHorizontal: screenWidth * 0.01,
        zIndex: 999,
        overflow: "visible",
        shadowColor: "#000",
        shadowRadius: 4,
        shadowOpacity: 0.2,
        shadowOffset: {
            height: 2,
            width: 2,
        },
    },
    storeWrap: {
        marginHorizontal: 5,
        shadowColor: "#1B31420D",
        shadowRadius: 4,
        shadowOpacity: 0.2,
        shadowOffset: {
            height: 2,
            width: 2,
        },
        marginBottom: 30
    },
    imageSearchContainer: {
        paddingTop: 0,
        marginBottom: 20,
        paddingHorizontal: 15,
        borderBottomRightRadius: 50,
        height: 240,
        width: '100%',
        transform: [{scaleX: 2}],
        borderBottomStartRadius: 200,
        borderBottomEndRadius: 200,
        overflow: 'hidden',
    },
    child: {
        // top: -100,
        flex: 1,
        transform: [{scaleX: 0.5}],
        alignItems: 'center',
        justifyContent: 'center'
    },
    listingTop: {
        width: "100%",
        // paddingTop: 100,
        zIndex: 1,
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: screenWidth * 0.03,
        paddingBottom: 10,
    },
    listingSearchBtnContainer: {
        marginLeft: 5,
        marginRight: -10,
        backgroundColor: COLORS.primary,
        borderRadius: 50,
        padding: 8
    },
    ListingSearchContainer: {
        flex: 1,
        height: 45,
        marginHorizontal: 20,
        backgroundColor: COLORS.white,
        borderRadius: 50,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        paddingHorizontal: 15,
        elevation: 7,
        zIndex: 20,
        shadowColor: "#000",
        shadowRadius: 4,
        shadowOpacity: 0.2,
        shadowOffset: {
            height: -4,
            width: 2,
        },
        borderWidth: 1,
    },
    searchInput: {
        flex: 1,
    },
    indicator: {
        height: 8,
        width: 50,
        backgroundColor: COLORS.gray,
        marginHorizontal: 5,
        borderRadius: 50
    },
    pagination: {
        flexDirection: "row",
        marginBottom: 30,
        justifyContent: "center"
    }
});

export default AllStores;
