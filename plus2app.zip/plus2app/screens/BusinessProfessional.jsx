import React, { useEffect, useState } from 'react';
import {
    ActivityIndicator,
    Dimensions, FlatList,
    ScrollView,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity, TouchableWithoutFeedback,
    View
} from "react-native";
import PremiumAds from "../components/PremiumAds";
import { Formik } from "formik";
import { __ } from "../language/stringPicker";
import { COLORS } from "../variables/color";
import { Feather } from "@expo/vector-icons";
import TabScreenHeader from "../components/TabScreenHeader";
import { useStateValue } from "../StateProvider";
import { useNavigation } from "@react-navigation/native";
import api from "../api/client";
import CategoryImage from "../components/CategoryImage";
import CategoryIcon from "../components/CategoryIcon";
import { decodeString } from "../helper/helper";
import CacheStore from "react-native-cache-store";

const { width: screenWidth } = Dimensions.get("screen");
const { height: screenHeight } = Dimensions.get('window');
const BusinessProfessional = ({ route, parentId, getListData, getOtherData }) => {
    const [{ user, appSettings }] = useStateValue();
    const navigation = useNavigation();
    const [categories, setCategories] = useState([])
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        handleLoadTopCategories();
    }, []);

    const _getTopCategories = () => {
        api.get(`/categories?parent_id=${route.params.directory_id}`).then((res) => {
            console.log(res)
            if (res.ok) {
                CacheStore.set(`topCats${route.params.directory_id}`, res.data, 10);
                setLoading(false)
                setCategories(res.data)
            }
        });
    }

    const handleLoadTopCategories = () => {
        CacheStore.get(`topCats${route.params.directory_id}`)
            .then(data => {
                console.log(data)
                if (data === null) {
                    _getTopCategories()
                } else {
                    const array = [...data];
                    setCategories(array)
                    setLoading(false);
                }
            }).catch((error) => {
                _getTopCategories()
            })
    };

    const handleCategorySelection = (category_id, category_name) => {
        navigation.navigate('CategoryListingsScreen', { category_id: category_id, category_name: category_name })
    };

    return (
        <View style={styles.container}>
            <TabScreenHeader
                right={!user}
                left
                onLeftClick={() => navigation.goBack()}
                style={{ elevation: 0, zIndex: 2 }} />
            {loading ? (
                <View style={styles.loading}>
                    <ActivityIndicator size="large" color={COLORS.primary} />
                    <Text style={styles.text}>
                        {__("homeScreenTexts.loadingMessage", appSettings.lng)}
                    </Text>
                </View>
            ) : (
                <>
                    <ScrollView>
                        <View style={styles.imageSearchContainer}>

                            <View style={styles.categoryTitleWrap}>
                                <Text style={styles.categoryTitle}>
                                    Select {route.params.directory_id === 498 ? 'Business' : 'Professional'} category
                                </Text>
                            </View>
                            {categories && (
                                <View
                                    style={{
                                        flexDirection: "row",
                                        flexWrap: "wrap",
                                        justifyContent: "center"
                                    }}
                                >
                                    {categories.map((_category) => (
                                        <>
                                            <View
                                                style={{
                                                    width: "50%",
                                                }}>
                                                <TouchableWithoutFeedback
                                                    key={_category.term_id}
                                                    onPress={() => {
                                                        handleCategorySelection(_category.term_id, _category.name)
                                                    }}
                                                >
                                                    <View style={{
                                                        backgroundColor: COLORS.white,
                                                        borderRadius: 26,
                                                        elevation: 5,height:120,
                                                        marginBottom: 25,
                                                        shadowColor: '#a9a9a9',
                                                        shadowOffset: {
                                                            width: 0,
                                                            height: 12,
                                                        },
                                                        shadowOpacity: 0.58,
                                                        shadowRadius: 16.00,
                                                        marginHorizontal: 10,
                                                    }}>
                          <View style={{flex:1.5,justifyContent:'flex-start',paddingTop:15,borderTopLeftRadius:10,borderTopRightRadius:10,alignItems:'center'}}>
                                                            {_category?.icon?.url ? (
                                                                <CategoryImage size={47} uri={_category.icon.url} />
                                                            ) : (
                                                                <CategoryIcon
                                                                    iconName={_category.icon.class}
                                                                    iconSize={27}
                                                                    iconColor={COLORS.primary}
                                                                />
                                                            )}
                                                        </View>
                                                        {/* <View style={{
                                                            flexDirection: "row",
                                                            padding: 10,
                                                            alignItems: "center",
                                                            justifyContent: "center"
                                                        }}>
                                                            <Text style={{
                                                                color: "#19191D",
                                                                fontSize: 10,
                                                                lineHeight: 29,
                                                                fontFamily: "Poppins Bold",
                                                                textAlign: "center"
                                                            }}>{decodeString(_category.name)}</Text>
                                                        </View> */}
                                                         <View style={{flex:1.2,paddingHorizontal:'4%',
                borderBottomLeftRadius:10,borderBottomRightRadius:10,
                backgroundColor:_category.description,justifyContent:'center',}}>
               
                        <Text
                    style={{
                        color: COLORS.white,
                        fontSize:11,
                        textAlign: "center",
                        fontFamily: "Poppins Bold"
                    }}
                >
                    {decodeString(_category.name)}
                </Text>
                </View>
                    
                                                    </View>
                                                </TouchableWithoutFeedback>
                                            </View>
                                        </>
                                    ))}
                                </View>
                            )}
                        </View>
                    </ScrollView>
                </>
            )}
        </View>
    );
};
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#ffffff",
    },
    imageSearchContainer: {
        paddingTop: 0,
        paddingHorizontal: 10,
        // borderBottomRightRadius: 50,
        width: '100%',
        // borderBottomStartRadius: 200,
        // borderBottomEndRadius: 200,
        overflow: 'hidden',
    },
    child: {
        // top: -100,
        flex: 1,
        // transform: [{ scaleX: 0.5 }],
        alignItems: 'center',
        justifyContent: 'center'
    },
    listingSearchBtnContainer: {
        marginLeft: 5,
        marginRight: -10,
        backgroundColor: COLORS.primary,
        borderRadius: 50,
        padding: 8
    },
    ListingSearchContainer: {
        flex: 1,
        height: 45,
        marginHorizontal: 20,
        backgroundColor: COLORS.white,
        borderWidth: 1,
        borderRadius: 50,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        paddingHorizontal: 15,
        elevation: 7,
        zIndex: 20,
        shadowColor: "#000",
        shadowRadius: 4,
        shadowOpacity: 0.2,
        shadowOffset: {
            height: -4,
            width: 2,
        },
    },
    listingTop: {
        width: "100%",
        // paddingTop: 100,
        zIndex: 1,
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: screenWidth * 0.03,
        paddingBottom: 10,
    },
    loading: {
        justifyContent: "center",
        alignItems: "center",
        height: screenHeight - 120,
    },
    categoryTitleWrap: {
        alignItems: "center",
        paddingVertical: 15,
    },
    categoryTitle: {
        fontSize: 20,
        fontFamily: "Poppins Bold",
        color: COLORS.headingsColor,
        paddingHorizontal: 10,
        lineHeight: 51,
    },
})
export default BusinessProfessional;