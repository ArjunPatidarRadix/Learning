import React, {useState, useEffect, useCallback,} from "react";
import {
    ActivityIndicator,
    Dimensions,
    Image,
    View,
    StyleSheet,
    Text,
    TouchableOpacity,
    FlatList,
    Modal,
    TouchableWithoutFeedback,
    Linking,
    Alert, ImageBackground, TextInput, ScrollView, RefreshControl,
} from "react-native";

// External Libraries
import moment from "moment";
import {List} from 'react-native-paper';
// Vector Icons
import {Feather, Fontisto} from "@expo/vector-icons";
import {FontAwesome5} from "@expo/vector-icons";
import {EvilIcons} from "@expo/vector-icons";
import {MaterialCommunityIcons} from "@expo/vector-icons";

// Custom Components & Functions
import api from "../api/client";
import {COLORS} from "../variables/color";
import {decodeString, getPrice, numFormatter} from "../helper/helper";
import {useStateValue} from "../StateProvider";
import AppButton from "../components/AppButton";
import AppTextButton from "../components/AppTextButton";
import {paginationData} from "../app/pagination/paginationData";
import {__} from "../language/stringPicker";
import {routes} from "../navigation/routes";
import TabScreenHeader from "../components/TabScreenHeader";
import {Formik} from "formik";
import Stars from 'react-native-stars';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import PremiumAds from "../components/PremiumAds";

const {width: windowWidth, height: windowHeight} = Dimensions.get("window");
const {width: screenWidth, height: screenHeight} = Dimensions.get("screen");

const storeDetailfallbackImage = {
    listingCardImage: require("../assets/100x100.png"),
    logo: require("../assets/100x100.png"),
    banner: require("../assets/200X150.png"),
};
const PublicProfileScreen = ({route, navigation}) => {
    const [{config, user, ios, appSettings}] = useStateValue();
    const [loading, setLoading] = useState(true);
    const [userData, setUserData] = useState();
    const [storeExpired, setStoreExpired] = useState(false);
    const [userId, setUserId] = useState(1);
    const [listHeaderHeight, setListHeaderHeight] = useState(
        windowWidth * 0.06 + 70 + 21 + 78 + 16 + 42 + 25 + 40 + 5
    );
    const [listHeaderHeightChanged, setListHeaderHeightChanged] = useState(false);
    const [initial, setInitial] = useState(true);
    const [userListingSData, setuserListingSData] = useState([]);
    const [modalVisible, setModalVisible] = useState(false);
    const [refreshing, setRefreshing] = useState(false);
    const [moreLoading, setMoreLoading] = useState(false);
    const [pagination, setPagination] = useState({});
    const [currentPage, setCurrentPage] = useState(
        pagination.page || paginationData.storeDetails.page
    );
    // {* Get Store Detail Call *}
    useEffect(() => {
        if (userData) return;
        setUserData(route.params.listingData);
    }, []);
    // {* Get Store Listings Call *}
    useEffect(() => {
        if (!initial && loading) return;
        getUserListings(userId, paginationData.storeDetails);
    }, [loading]);

    // {* Refreshing get listing call *}
    useEffect(() => {
        if (!refreshing) return;
        setCurrentPage(1);
        setPagination({});
        getUserListings(userId, paginationData.storeDetails);
    }, [refreshing]);

    // {* Next page get listing call *}
    useEffect(() => {
        if (!moreLoading) return;
        const tempPaginationData = {
            per_page: paginationData.storeDetails.per_page,
            page: currentPage,
        };
        getUserListings(userId, tempPaginationData);
    }, [moreLoading]);


    const getUserListings = (userId, paginationData) => {
        const args = {...paginationData, author_id: 23};
        api.get("listings/?per_page=100&order_by=locations&order=desc", {...args}).then((res) => {
            if (res.ok) {
                const selected = [];
                if (refreshing) {
                    setRefreshing(false);
                }
                if (moreLoading) {
                    setuserListingSData((prevuserListingSData) => [
                        ...prevuserListingSData,
                        ...res.data.data,
                    ]);
                    setCurrentPage(res.data.pagination.page);
                    setMoreLoading(false);
                } else {
                    const array = res.data.data;
                    const required = [];
                    const leave = user.id;
                    for (let i = 0; i < array.length; i++) {
                        if (array[i].author_id === leave) {
                            // array.splice(i, 1);
                            required.push(array[i])
                        }
                    }
                    setuserListingSData(required);
                }
                setPagination(selected ? selected : {});

                if (initial) {
                    setInitial(false);
                }
                if (loading) {
                    setLoading(false);
                }
            } else {
                // print error
                // TODO handle error
                // if error give retry button and set initial to true only for initial call
                if (refreshing) {
                    setRefreshing(false);
                }
                if (moreLoading) {
                    setMoreLoading(false);
                }
                if (loading) {
                    setLoading(false);
                }
                if (initial) {
                    setInitial(false);
                }
            }
        });
    };
    // console.log(userListingSData);
    const getTexonomy = (items) => {
        if (!items?.length) return false;
        return decodeString(items[items.length - 1].name);
    };

    const renderListItem = useCallback(
        ({item}) => <StoreListingCard item={item}/>,
        []
    );
    const StoreListingCard = ({item}) => (
        <View style={styles.storeListingCardWrap}>
            <TouchableOpacity
                style={styles.storeListingCardContent}
                onPress={() => handleViewListing(item)}
            >
                <View style={styles.listingCardImageWrap}>
                    <Image
                        source={
                            !!item.images.length
                                ? {uri: item.images[0].sizes.thumbnail.src}
                                : storeDetailfallbackImage.listingCardImage
                        }
                        style={styles.listingCardImage}
                    />
                </View>
                <View style={styles.listingCardDetailWrap}>
                    <View style={styles.listingCardDetailContent}>
                        <View style={styles.listingCardDetailLeft}>
                            <View>
                                <Text style={styles.listingCardPrice} numberOfLines={1}>
                                    {getPrice(
                                        config.currency,
                                        {
                                            pricing_type: item.pricing_type,
                                            price_type: item.price_type,
                                            price: item.price,
                                            max_price: item.max_price,
                                        },
                                        appSettings.lng
                                    )}
                                </Text>
                                <Text
                                    style={[
                                        styles.featuredItemCategory,
                                        {paddingBottom: ios ? 3 : 1},
                                    ]}
                                    numberOfLines={1}
                                >
                                    {getTexonomy(item.categories)}
                                </Text>
                                <Text style={styles.listingCardTitle} numberOfLines={1}>
                                    {decodeString(item.title)}
                                </Text>
                                <View
                                    style={{
                                        flexDirection: "row",
                                        alignItems: "center",
                                        marginVertical: 3,
                                    }}
                                >
                                    <View style={styles.iconWrap}>
                                        <FontAwesome5
                                            name="eye"
                                            size={13}
                                            color={COLORS.text_gray}
                                        />
                                    </View>
                                    <Text style={styles.listingCardText}>
                                        {numFormatter(item?.view_count)}
                                    </Text>
                                </View>
                                <View
                                    style={{
                                        flexDirection: "row",
                                        alignItems: "center",
                                        marginVertical: 3,
                                    }}
                                >
                                    <Stars
                                        display={3}
                                        count={5}
                                        half={true}
                                        starSize={80}
                                        fullStar={<Icon name={'star'} style={{color: COLORS.primary}} size={15}/>}
                                        emptyStar={<Icon name={'star-outline'} style={{color: COLORS.primary}}
                                                         size={15}/>}
                                        halfStar={<Icon name={'star-half'} style={{color: COLORS.primary}}
                                                        size={15}/>}
                                        disabled
                                    />
                                    <Text style={{
                                        fontSize: 10,
                                        paddingLeft: 2
                                    }}>3</Text>
                                </View>
                            </View>
                        </View>
                    </View>
                </View>
            </TouchableOpacity>
        </View>
    );

    const handleViewListing = (listing) => {
        navigation.push(routes.listingDetailScreen, {
            listingId: listing.listing_id,
        });
    };

    const keyExtractor = useCallback((item, index) => `${index}`, []);

    const handleHeaderLayout = (e) => {
        if (e.nativeEvent.layout.height > 1 && !listHeaderHeightChanged) {
            setListHeaderHeight(e.nativeEvent.layout.height);
            setListHeaderHeightChanged(true);
        }
        return;
    };

    const EmptyListComponent = () => {
        if (initial) {
            return (
                <View style={styles.view}>
                    <ActivityIndicator size="large" color={COLORS.primary}/>
                </View>
            );
        } else {
            return (
                <View
                    style={{
                        flex: 1,
                        alignItems: "center",
                        justifyContent: "center",
                    }}
                >
                    <Text
                        style={{
                            fontSize: 15,
                            fontFamily: "Poppins Bold",
                            color: COLORS.gray,
                        }}
                    >
                        {/* eslint-disable-next-line react/no-unescaped-entities */}
                        Sorry, you don't have any listing yet!
                    </Text>
                </View>
            );
        }
    };

    const listFooter = () => {
        if (pagination && pagination.total_pages > pagination.current_page) {
            return (
                <View style={styles.loadMoreWrap}>
                    <ActivityIndicator size="small" color={COLORS.primary}/>
                </View>
            );
        } else {
            return null;
        }
    };

    const handleNextPageLoading = () => {
        if (refreshing) return;
        if (pagination && pagination.total_pages > pagination.current_page) {
            setCurrentPage((prevCurrentPage) => prevCurrentPage + 1);
            setMoreLoading(true);
        }
    };

    const handleCall = (number) => {
        setModalVisible(false);
        let phoneNumber = "";
        if (ios) {
            phoneNumber = `telprompt:${number}`;
        } else {
            phoneNumber = `tel:${number}`;
        }
        Linking.openURL(phoneNumber);
    };

    const onRefresh = () => {
        if (moreLoading) return;
        setRefreshing(true);
    };

    const handleGoBack = () => {
        navigation.goBack();
    };
    let [value, setValue] = useState(0);
    const [faqToggle, setFaqToggle] = useState(false);

    return (
        <>
            <TabScreenHeader left onLeftClick={() => navigation.goBack()}/>
            {loading ? (
                // {* Loading Component *}
                <View style={styles.loading}>
                    <ActivityIndicator size="large" color={COLORS.primary}/>
                </View>
            ) : (
                <ScrollView
                    showsVerticalScrollIndicator={false}
                    refreshControl={
                        <RefreshControl
                            onRefresh={onRefresh}
                            refreshing={refreshing}
                        />
                    }
                >
                    <View style={styles.container}>
                        {!!userData && (
                            <>
                                <View style={styles.imageSearchContainer}>
                                    <View style={styles.child}>
                                        <PremiumAds admob={false}/>
                                        <View style={{position: 'absolute', left: 0, right: 0, top: 20,}}>
                                            <View style={styles.listingTop}>
                                                <Formik initialValues={{search: ""}}>
                                                    {({handleChange, handleBlur, handleSubmit, values}) => (
                                                        <View style={styles.ListingSearchContainer}>
                                                            <TextInput
                                                                style={styles.searchInput}
                                                                placeholder={
                                                                    __(
                                                                        "homeScreenTexts.listingSearchPlaceholder",
                                                                        appSettings.lng
                                                                    )
                                                                }
                                                                placeholderTextColor={COLORS.textGray}
                                                                onChangeText={handleChange("search")}
                                                                onBlur={() => {
                                                                    handleBlur("search");
                                                                }}
                                                                value={values.search}
                                                                returnKeyType="search"
                                                                onSubmitEditing={handleSubmit}
                                                            />

                                                            <TouchableOpacity
                                                                onPress={handleSubmit}
                                                                style={styles.listingSearchBtnContainer}
                                                            >
                                                                <Feather
                                                                    name="search"
                                                                    size={20}
                                                                    color={values.search ? COLORS.white : COLORS.white}
                                                                />
                                                            </TouchableOpacity>
                                                        </View>
                                                    )}
                                                </Formik>
                                            </View>
                                        </View>
                                    </View>
                                </View>
                                <View
                                    style={[
                                        styles.storeTop,
                                        {paddingHorizontal: 15}
                                    ]}
                                >
                                    <View
                                        onLayout={(event) => handleHeaderLayout(event)}
                                        style={styles.storeDetailWrap}
                                    >
                                        {/* Logo, Title, Rating, Slogan */}
                                        <View style={styles.storeDetatilTopWrap}>
                                            <View style={styles.storeLogo}>
                                                <Image
                                                    style={styles.logo}
                                                    source={
                                                        userData.author.pp_thumb_url
                                                            ? {uri: userData.author.pp_thumb_url}
                                                            : storeDetailfallbackImage.logo
                                                    }
                                                />
                                            </View>
                                            <View style={styles.storeDetailTopRight}>
                                                <View style={styles.storeTitleRow}>
                                                    <View style={{flex: 1}}>
                                                        <Text style={styles.storeTitle} numberOfLines={1}>
                                                            {userData.author.first_name
                                                                ? decodeString(userData.author.first_name) + " " + decodeString(userData.author.last_name)
                                                                : __("storeDetailsTexts.nullText", appSettings.lng)}
                                                        </Text>
                                                    </View>
                                                    <View style={{flex: 1, flexDirection: "row", marginTop: 4}}>
                                                        <FontAwesome5 name="envelope" size={18} color={COLORS.primary}
                                                                      style={{marginRight: 10}}/>
                                                        <Text style={styles.storeSlogan} numberOfLines={1}>
                                                            {userData.author.email
                                                                ? decodeString(userData.author.email)
                                                                : __("storeDetailsTexts.nullText", appSettings.lng)}
                                                        </Text>
                                                    </View>

                                                </View>
                                            </View>
                                        </View>
                                        {/*<View style={{paddingVertical: 10}}>*/}

                                        {/*    /!*{!!userData.slogan && (*!/*/}
                                        {/*    /!*    <Text style={styles.storeSlogan} numberOfLines={2}>*!/*/}
                                        {/*    /!*        {decodeString(userData.slogan)}*!/*/}
                                        {/*    /!*    </Text>*!/*/}
                                        {/*    /!*)}*!/*/}
                                        {/*</View>*/}

                                        {/* Call, Message, More Details */}
                                        <View style={styles.storeDetatilBottomWrap}>
                                            <View
                                                style={[
                                                    styles.storeContactWrap,
                                                    {
                                                        flex: 1
                                                    },
                                                ]}
                                            >
                                                {!!userData.author.phone && (
                                                    <TouchableOpacity
                                                        style={[
                                                            styles.storeContactButton,
                                                            {backgroundColor: COLORS.black},
                                                        ]}
                                                        onPress={() => {
                                                            if (value === 0) {
                                                                setValue(1);
                                                            } else if (value === 1 || value === 2) {
                                                                setValue(2);
                                                                setModalVisible(true)
                                                            }
                                                        }}
                                                    >
                                                        <FontAwesome5 name="phone-alt" size={18}
                                                                      color={COLORS.white}/>
                                                        <Text
                                                            style={[
                                                                styles.storeContactButtonText,
                                                                {color: COLORS.white},
                                                            ]}
                                                        >
                                                            {value === 0 ? "Show phone number" : userData.author.phone}
                                                        </Text>
                                                    </TouchableOpacity>
                                                )}

                                            </View>
                                        </View>
                                    </View>
                                    {/* Flatlist Title */}
                                    <View
                                        style={{
                                            width: "100%",
                                            alignItems: "center"
                                        }}
                                    >
                                        <Text
                                            style={{
                                                fontSize: 25,
                                                fontFamily: "Poppins Bold",
                                                color: COLORS.headingsColor,
                                                marginTop: 20
                                            }}
                                        >
                                            {route.params.itsMe ? "My Products" : "Products"}
                                        </Text>
                                    </View>
                                </View>
                                {/* Listing FlatList */}
                                <View style={styles.storeBottom}>
                                    <FlatList
                                        data={userListingSData}
                                        renderItem={renderListItem}
                                        keyExtractor={keyExtractor}
                                        horizontal={false}
                                        showsVerticalScrollIndicator={false}
                                        onEndReached={handleNextPageLoading}
                                        onEndReachedThreshold={1}
                                        ListFooterComponent={listFooter}
                                        ListEmptyComponent={EmptyListComponent}
                                    />
                                </View>
                                {/* Call prompt */}
                                <Modal
                                    animationType="slide"
                                    transparent={true}
                                    visible={modalVisible}
                                >
                                    <TouchableWithoutFeedback onPress={() => setModalVisible(false)}>
                                        <View style={styles.modalOverlay}/>
                                    </TouchableWithoutFeedback>
                                    {!!userData.author.phone && (
                                        <View
                                            style={{
                                                flex: 1,
                                                justifyContent: "flex-end",
                                                alignItems: "center",
                                            }}
                                        >
                                            <View
                                                style={{
                                                    paddingHorizontal: "3%",
                                                    padding: 20,
                                                    backgroundColor: COLORS.white,
                                                    width: "100%",
                                                }}
                                            >
                                                <Text style={styles.callText}>
                                                    Call this person?
                                                </Text>
                                                <TouchableOpacity
                                                    onPress={() => handleCall(userData.author.phone)}
                                                    style={styles.phone}
                                                >
                                                    <Text style={styles.phoneText}>{userData.author.phone}</Text>
                                                    <FontAwesome5
                                                        name="phone"
                                                        size={18}
                                                        color={COLORS.primary}
                                                    />
                                                </TouchableOpacity>
                                                {ios && (
                                                    <AppTextButton
                                                        title={__(
                                                            "storeDetailsTexts.cancelButtonTitle",
                                                            appSettings.lng
                                                        )}
                                                        textStyle={{
                                                            fontFamily: "Poppins Bold",
                                                        }}
                                                        style={{marginTop: 20}}
                                                        onPress={() => setModalVisible(false)}
                                                    />
                                                )}
                                            </View>
                                        </View>
                                    )}
                                </Modal>
                            </>
                        )}
                        {storeExpired && (
                            <View style={styles.expiredWrap}>
                                <EvilIcons name="exclamation" size={50} color={COLORS.red}/>
                                <Text style={styles.expiredText}>
                                    {__("storeDetailsTexts.storeExpired", appSettings.lng)}
                                </Text>
                                <AppButton
                                    title={__("storeDetailsTexts.goBackButtonTitle", appSettings.lng)}
                                    onPress={handleGoBack}
                                    style={styles.goBackButton}
                                />
                            </View>
                        )}
                    </View>
                </ScrollView>
            )
            }
        </>
    )
};

const styles = StyleSheet.create({
    banner: {
        height: 200,
        width: "100%",
        resizeMode: "cover",
    },
    bannerWrap: {
        width: "100%",
        height: 200,
    },
    callText: {
        fontSize: 20,
        color: COLORS.text_dark,
        textAlign: "center",
        fontFamily: "Poppins Regular",
    },
    container: {
        flex: 1,
        backgroundColor: "#fafafa",
        width: "100%",
        height: "100%",
    },
    expiredText: {
        fontSize: 15,
        fontFamily: "Poppins Bold",
        color: COLORS.gray,
        textAlign: "center",
        marginVertical: 15,
    },
    expiredWrap: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        padding: "3%",
    },
    goBackButton: {
        width: "40%",
    },
    header: {
        justifyContent: "center",
        alignItems: "center",
        height: 50,
        width: "100%",
        position: "absolute",
        top: 0,
        left: 0,
        zIndex: 2,
    },
    headerBackButton: {
        position: "absolute",
        left: "3%",
        elevation: 2,
        height: 30,
        width: 30,
        alignItems: "center",
        justifyContent: "center",
    },
    iconWrap: {
        width: 30,
        alignItems: "center",
        padding: 3,
        backgroundColor: "#c8c8c8"
    },
    listingCardDetailContent: {
        flex: 1,
    },
    listingCardDetailLeft: {
        flex: 1,
    },
    listingCardDetailRight: {},
    listingCardDetailWrap: {
        flex: 1,
        paddingLeft: 10,
        width: windowWidth * 0.74,
    },
    listingCardImage: {
        height: 100,
        width: 100,
        resizeMode: "cover",
        borderRadius: 10,
    },
    listingCardImageWrap: {
        height: 80,
        width: 80,
        alignItems: "center",
        justifyContent: "center",
        marginRight: 10
    },
    listingCardPrice: {
        fontFamily: "Poppins Bold",
        color: COLORS.primary,
    },
    listingCardText: {
        fontSize: 12,
        color: COLORS.text_gray,
        backgroundColor: "#f5f5f5",
        paddingHorizontal: 10,
        paddingVertical: 2,
        fontFamily: "Poppins Regular",
    },
    listingCardTitle: {
        fontFamily: "Poppins Bold",
        fontSize: 13,
        color: COLORS.text_dark,
    },

    loading: {
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        opacity: 1,
        backgroundColor: "transparent",
        justifyContent: "center",
        alignItems: "center",
        flex: 1,
    },
    logo: {
        height: 70,
        width: 80,
        resizeMode: "contain",
    },
    modalOverlay: {
        position: "absolute",
        top: 0,
        bottom: 0,
        left: 0,
        right: 0,
        backgroundColor: "rgba(0,0,0,0.2)",
    },
    phone: {
        flexDirection: "row",
        alignItems: "flex-end",
        justifyContent: "space-between",
        paddingVertical: 10,
    },
    phoneText: {
        color: COLORS.primary,
        fontFamily: "Poppins Bold",
        fontSize: 18,
    },
    rating: {
        fontSize: 15,
        fontFamily: "Poppins Bold",
        color: COLORS.white,
        marginRight: 5,
        lineHeight: 18,
    },
    screenTitle: {
        fontSize: 20,
        color: COLORS.black,
        fontFamily: "Poppins Bold",
        elevation: 2,
    },
    storeBottom: {
        width: "100%",
        // flex: 1,
        // position: "relative",
        paddingHorizontal: 15
    },
    storeContactButton: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 6,
        width: "100%",
        height: 50,
        marginBottom: 10,
        marginVertical: 10
    },
    storeChatButton: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 3,
        width: "100%",
        height: 50,
        marginBottom: 10,
    },
    storeContactButtonText: {
        fontSize: 14,
        fontFamily: "Poppins Bold",
        marginLeft: 5,
    },
    storeContactWrap: {
        marginVertical: 5,
        // flexDirection: "row",
        alignItems: "center",
    },
    storeDetailMidrow: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
        marginVertical: 5,
    },
    storeDetailMidrowIconWrap: {
        height: 16,
        width: 16,
        alignItems: "center",
        justifyContent: "center",
        // overflow: "hidden",
        marginRight: 5,
    },
    storeDetailMidrowText: {
        fontSize: 14,
        color: COLORS.text_gray,
        fontFamily: "Poppins Regular",
    },
    storeDetailTopRight: {
        flex: 1,
        paddingLeft: 10,
        width: windowWidth * 0.724,
    },
    storeDetatilTopWrap: {
        width: windowWidth * 0.88,
        flexDirection: "row",
        alignItems: "center",
        flex: 1
    },
    storeDetailWrap: {
        backgroundColor: "#fafafa",
        flex: 1
    },
    storeListingCardContent: {
        flexDirection: "row",
        alignItems: "center",
        padding: "2%",
    },
    storeLogo: {
        height: 70,
        width: 80,
        // overflow: "hidden",
        backgroundColor: "#f5f5f5",
        borderRadius: 10
    },
    storeRatingWrap: {
        paddingHorizontal: 10,
        paddingVertical: 3,
        // backgroundColor: COLORS.orange,
        borderRadius: 30,
        alignItems: "center",
        justifyContent: "center",
        flexDirection: "row",
    },
    storeSlogan: {
        fontSize: 15,
        color: COLORS.text_gray,
        marginBottom: 5,
        lineHeight: 18,
        fontFamily: "Poppins Regular",
    },
    storeTitle: {
        fontSize: 16,
        fontFamily: "Poppins Bold",
        color: COLORS.text_dark,
        lineHeight: 25,
    },
    storeTitleRow: {
        // flexDirection: "row",
        alignItems: "flex-start",
    },
    storeTop: {
        flex: 1,
        width: "100%",
        alignItems: "center",
        marginTop: 20
    },
    viewMoreDetailsButton: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
        marginBottom: 5,
    },
    imageSearchContainer: {
        paddingTop: 0,
        paddingHorizontal: 15,
        borderBottomRightRadius: 50,
        height: 240,
        width: '100%',
        transform: [{scaleX: 2}],
        borderBottomStartRadius: 200,
        borderBottomEndRadius: 200,
        overflow: 'hidden',
    },
    child: {
        // top: -100,
        flex: 1,
        transform: [{scaleX: 0.5}],
        alignItems: 'center',
        justifyContent: 'center'
    },
    listingTop: {
        width: "100%",
        // paddingTop: 100,
        zIndex: 1,
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: screenWidth * 0.03,
        paddingBottom: 10,
    },
    listingSearchBtnContainer: {
        marginLeft: 5,
        marginRight: -10,
        backgroundColor: COLORS.primary,
        borderRadius: 50,
        padding: 8
    },
    ListingSearchContainer: {
        flex: 1,
        height: 45,
        marginHorizontal: 20,
        backgroundColor: COLORS.white,
        borderRadius: 50,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        paddingHorizontal: 15,
        elevation: 7,
        zIndex: 20,
        shadowColor: "#000",
        shadowRadius: 4,
        shadowOpacity: 0.2,
        shadowOffset: {
            height: -4,
            width: 2,
        },
        borderWidth: 1,
    },
    searchInput: {
        flex: 1,
        fontFamily: "Poppins Regular",
    },

    featuredItemCategory: {
        fontSize: 12,
        color: COLORS.text_gray,
        fontFamily: "Poppins Regular",
    },
    storeListingCardWrap: {
        backgroundColor: "#ffffff",
        padding: 10,
        margin: 5,
        elevation: 5,
        shadowRadius: 5,
        shadowOpacity: 0.3,
        shadowOffset: {
            height: 2,
            width: 2,
        },
        borderRadius: 10
    },
    dayWrap: {
        paddingHorizontal: 10,
        paddingVertical: 15,
        marginVertical: 5,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        backgroundColor: "#fafafa",
        borderRadius: 10,

    },
    detailWrap: {
        padding: 10,
        borderWidth: 1,
        borderColor: COLORS.red,
    },
});

export default PublicProfileScreen;
