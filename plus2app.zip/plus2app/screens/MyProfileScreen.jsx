/* eslint-disable no-unused-vars */
import React, {useState, useEffect} from "react";
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    Image,
    TouchableOpacity,
    ActivityIndicator,
    Dimensions,
    TouchableWithoutFeedback, ImageBackground, TextInput,
} from "react-native";

// External Libraries
import {ReactNativeZoomableView} from "@dudigital/react-native-zoomable-view/src/ReactNativeZoomableView";

// Vector Icons
import {FontAwesome} from "@expo/vector-icons";
import {FontAwesome5} from "@expo/vector-icons";

// Custom Components & Functions
import {COLORS} from "../variables/color";
import ProfileData from "../components/ProfileData";
import {useStateValue} from "../StateProvider";
import api, {setAuthToken, removeAuthToken} from "../api/client";
import AppSeparator from "../components/AppSeparator";
import FlashNotification from "../components/FlashNotification";
import {__} from "../language/stringPicker";
import {routes} from "../navigation/routes";
import TabScreenHeader from "../components/TabScreenHeader";
import Feather from "react-native-vector-icons/Feather";
import {Formik} from "formik";
import AppButton from "../components/AppButton";

const {width: deviceWidth, height: deviceHeight} = Dimensions.get("window");
const MyProfileScreen = ({navigation}) => {
    const [{ios}] = useStateValue();
    const [{auth_token, user, is_connected, appSettings}, dispatch] =
        useStateValue();
    const [loading, setLoading] = useState(true);
    const [errorMessage, setErrorMessage] = useState();
    const [imageViewer, setImageViewer] = useState(false);
    const [flashNotification, setFlashNotification] = useState(false);
    const [flashNotificationMessage, setFlashNotificationMessage] = useState();

    const handleError = (message) => {
        setFlashNotificationMessage(message);
        setTimeout(() => {
            setFlashNotification(true);
        }, 10);
        setTimeout(() => {
            setFlashNotification(false);
            setFlashNotificationMessage();
        }, 1200);
    };
    useEffect(() => {
        setAuthToken(auth_token);
        api.get("my").then((res) => {
            if (res.ok) {
                dispatch({
                    type: "SET_AUTH_DATA",
                    data: {user: res.data},
                });
                setLoading(false);
                removeAuthToken();
            } else {
                // TODO handle error && add retry button on error

                setErrorMessage(
                    res?.data?.error_message ||
                    res?.data?.error ||
                    res?.problem ||
                    __("myProfileScreenTexts.customResponseError", appSettings.lng)
                );
                handleError(
                    res?.data?.error_message ||
                    res?.data?.error ||
                    res?.problem ||
                    __("myProfileScreenTexts.customResponseError", appSettings.lng)
                );
                setLoading(false);
                removeAuthToken();
            }
        });
    }, []);
    const handleLocationTaxonomy = (locations) => {
        if (!locations) return;
        let result = "";
        for (let i = 0; i < locations.length; i++) {
            if (result.length < 1) {
                result = locations[i].name;
            } else {
                result = result + `, ${locations[i].name}`;
            }
        }
        return result;
    };

    const handleImageViewer = () => {
        if (!user.pp_thumb_url) return;
        setImageViewer(!imageViewer);
    };

    return !!user ? (is_connected ? (
        <>
            <TabScreenHeader
                style={{elevation: 0, zIndex: 2}}/>
            {loading ? (
                <View style={styles.loadingWrap}>
                    <View style={styles.loading}>
                        <ActivityIndicator size="large" color={COLORS.primary}/>
                        <Text style={styles.loadingMessage}>
                            {__("myProfileScreenTexts.loadingMessage", appSettings.lng)}
                        </Text>
                    </View>
                </View>
            ) : (
                <>
                    {!imageViewer && (
                        <View style={styles.container}>
                            <ScrollView showsVerticalScrollIndicator={false}>
                                <View style={styles.imageSearchContainer}>
                                    {/* eslint-disable-next-line no-undef */}
                                    <ImageBackground source={require('../assets/banner.png')} style={{width: "100%"}}
                                                     imageStyle={{resizeMode: "cover"}}>

                                        <View style={{position: 'absolute', left: 0, right: 0, top: -40,}}>
                                            <View style={styles.listingTop}>
                                                <Formik initialValues={{search: ""}}>
                                                    {({handleChange, handleBlur, handleSubmit, values}) => (
                                                        <View style={styles.ListingSearchContainer}>
                                                            <TextInput
                                                                style={styles.searchInput}
                                                                placeholderTextColor={COLORS.textGray}
                                                                onChangeText={handleChange("search")}
                                                                onBlur={() => {
                                                                    handleBlur("search");
                                                                }}
                                                                value={values.search}
                                                                returnKeyType="search"
                                                            />

                                                            <TouchableOpacity
                                                                style={styles.listingSearchBtnContainer}
                                                            >
                                                                <Feather
                                                                    name="search"
                                                                    size={20}
                                                                    color={values.search ? COLORS.white : COLORS.white}
                                                                />
                                                            </TouchableOpacity>
                                                        </View>
                                                    )}
                                                </Formik>
                                            </View>
                                        </View>
                                    </ImageBackground>
                                </View>
                                <View style={styles.profWrapper}>
                                    <Text style={styles.profText}>Profile Info</Text>
                                    <View style={styles.basicWrapper}>
                                        <View style={styles.imageWrap}>
                                            {user.pp_thumb_url ? (
                                                <Image
                                                    source={{uri: user.pp_thumb_url}}
                                                    style={styles.image}
                                                />
                                            ) : (
                                                <FontAwesome
                                                    name="camera"
                                                    size={20}
                                                    color={COLORS.text_gray}
                                                />
                                            )}
                                        </View>
                                        <View style={styles.detail}>
                                            {(!!user.first_name || !!user.last_name) && (
                                                <ProfileData
                                                    value={`${user.first_name} ${user.last_name}`}
                                                />
                                            )}
                                            <Text style={{color: COLORS.primary, fontFamily: "Poppins Regular"}}>Active</Text>
                                            <View style={styles.locYears}>
                                                <FontAwesome5 name="compass" style={{
                                                    color: COLORS.blue,
                                                    fontSize: 15,
                                                    paddingRight: 10
                                                }}/>
                                                <Text style={{color: COLORS.text_gray, paddingRight: 10}}>Jakarta,
                                                    Indonesia</Text>
                                                <View
                                                    style={{height: 20, backgroundColor: COLORS.text_gray, width: 1}}/>
                                                <Text style={{color: COLORS.text_gray, paddingLeft: 10}}>3+ Yrs
                                                    Exp</Text>
                                            </View>
                                            <View style={{
                                                marginHorizontal: 20,
                                                height: 1,
                                                backgroundColor: "#d5d5d5",
                                                width: 280,
                                                marginTop: 20
                                            }}/>
                                            <AppButton title={"View My Public Profile"}
                                                       style={{
                                                           borderRadius: 50,
                                                           marginTop: ios ? deviceHeight * 0.03 : deviceHeight * 0.02
                                                       }}/>
                                        </View>
                                    </View>
                                    <View style={styles.infoWrapper}>
                                        <View>
                                            {!!user.email && (
                                                <ProfileData
                                                    label={__(
                                                        "myProfileScreenTexts.profileInfoLabels.email",
                                                        appSettings.lng
                                                    )}
                                                    value={user.email}
                                                />
                                            )}
                                            <Text style={{color: COLORS.text_gray}}>Validity</Text>
                                            <Text style={{marginBottom: 10,}}>Until: 24 October 2021 @ 3:23pm</Text>
                                            {!!user.phone && (
                                                <ProfileData
                                                    label={__(
                                                        "myProfileScreenTexts.profileInfoLabels.phone",
                                                        appSettings.lng
                                                    )}
                                                    value={user.phone}
                                                />
                                            )}
                                            <Text style={{color: COLORS.text_gray}}>Remaining Ads</Text>
                                            <Text style={{marginBottom: 10,}}>80</Text>
                                            <Text style={{color: COLORS.text_gray}}>Posted</Text>
                                            <Text style={{marginBottom: 10,}}>10</Text>
                                        </View>
                                    </View>
                                    <View style={{
                                        display: "flex",
                                        flexDirection: "row",
                                        marginHorizontal: 20,
                                        marginTop: 30
                                    }}>
                                        <AppButton
                                            title={'Buy Subscription'}
                                            style={{
                                                width: "50%",
                                                backgroundColor: COLORS.black,
                                                paddingLeft: 0,
                                                borderRadius: 50,
                                                marginRight: "5%"
                                            }}
                                        />
                                        <AppButton
                                            title={'Message'}
                                            style={{
                                                width: "45%",
                                                backgroundColor: COLORS.black,
                                                paddingLeft: 0,
                                                borderRadius: 50
                                            }}
                                        />
                                    </View>
                                </View>
                            </ScrollView>
                        </View>
                    )}
                    {imageViewer && !!user.pp_thumb_url && (
                        <View style={styles.imageViewerWrap}>
                            <TouchableOpacity
                                style={styles.imageViewerCloseButton}
                                onPress={handleImageViewer}
                            >
                                <FontAwesome5 name="times" size={24} color={COLORS.primary}/>
                            </TouchableOpacity>

                            <View style={styles.imageViewer}>
                                <ReactNativeZoomableView
                                    maxZoom={1.5}
                                    minZoom={1}
                                    zoomStep={0.5}
                                    initialZoom={1}
                                    bindToBorders={true}
                                    style={{
                                        padding: 10,
                                        backgroundColor: COLORS.bg_dark,
                                    }}
                                >
                                    <Image
                                        style={{
                                            width: deviceWidth,
                                            height: deviceHeight,
                                            resizeMode: "contain",
                                        }}
                                        source={{
                                            uri: user.pp_thumb_url,
                                        }}
                                    />
                                </ReactNativeZoomableView>
                            </View>
                        </View>
                    )}
                </>
            )}
            <FlashNotification
                falshShow={flashNotification}
                flashMessage={flashNotificationMessage}
            />
        </>
    ) : (
        <View style={styles.noInternet}>
            <FontAwesome5
                name="exclamation-circle"
                size={24}
                color={COLORS.primary}
            />
            <Text style={styles.text}>
                {__("myProfileScreenTexts.noInternet", appSettings.lng)}
            </Text>
        </View>
    )) : (
        <>
            <TabScreenHeader/>
            <View style={styles.noUserViewWrap}>
                <View style={styles.noUserTitleWrap}>
                    <Text style={styles.noUserTitle}>
                        {__("newListingScreenTexts.notLoggedIn", appSettings.lng)}
                    </Text>
                    <Text style={styles.noUserMessage}>
                        {__("newListingScreenTexts.loginOrSignUpToSeeProf", appSettings.lng)}
                    </Text>
                    <View style={styles.authButtonWrap}>
                        <AppButton
                            style={styles.authButton}
                            title={__(
                                "newListingScreenTexts.loginOrSignUpButtonTitle",
                                appSettings.lng
                            )}
                            onPress={() => navigation.navigate(routes.loginScreen)}
                        />
                    </View>
                </View>
            </View>
        </>

    );
};

const styles = StyleSheet.create({
    container: {
        backgroundColor: COLORS.white,
        flex: 1,
    },
    image: {
        height: 85,
        width: 85,
        resizeMode: "cover",
        borderRadius: 50,
    },
    imageViewer: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
    },
    imageViewerCloseButton: {
        position: "absolute",
        right: 15,
        top: 15,
        zIndex: 10,
        height: 25,
        width: 25,
        backgroundColor: COLORS.white,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 13,
    },
    imageViewerWrap: {
        position: "absolute",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "white",
        width: "100%",
        height: "100%",
        flex: 1,
    },
    imageWrap: {
        height: 90,
        width: 90,
        borderRadius: 50,
        borderWidth: 1,
        borderColor: "#d5d5d5",
        top: -30,
        backgroundColor: COLORS.white,
        alignItems: "center",
        justifyContent: "center"
    },
    detail: {
        top: -30,
        alignItems: "center"
    },
    loading: {
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        opacity: 0.8,
        backgroundColor: "transparent",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 5,
        flex: 1,
    },
    loadingWrap: {
        justifyContent: "center",
        alignItems: "center",
        flex: 1,
    },
    mainWrap: {
        backgroundColor: COLORS.bg_light,
        paddingVertical: 15,
        paddingHorizontal: "3%",
    },
    name: {
        fontSize: 18,
        color: COLORS.text_dark,
        marginLeft: 10,
    },
    noInternet: {
        alignItems: "center",
        flex: 1,
        backgroundColor: "white",
        justifyContent: "center",
        width: "100%",
        height: "100%",
    },
    phone: {
        marginLeft: 10,
        fontSize: 16,
        color: COLORS.text_gray,
    },
    phoneWrap: {
        flexDirection: "row",
        alignItems: "center",
        marginVertical: 5,
    },
    separator: {
        width: "100%",
        backgroundColor: COLORS.bg_dark,
        marginVertical: 15,
    },
    titleRight: {
        marginLeft: 15,
    },
    titleRow: {
        flexDirection: "row",
        alignItems: "center",
    },
    imageSearchContainer: {
        width: "100%",
        height: 150,
        marginTop: 30,
        marginBottom: 30,
        flexDirection: "row",
        paddingHorizontal: 15,
        borderBottomRightRadius: 50,
    },
    listingSearchBtnContainer: {
        marginLeft: 5,
        marginRight: -10,
        backgroundColor: COLORS.primary,
        borderRadius: 50,
        padding: 8
    },
    ListingSearchContainer: {
        flex: 1,
        height: 45,
        marginHorizontal: 20,
        backgroundColor: COLORS.white,
        borderRadius: 50,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        paddingHorizontal: 15,
        elevation: 7,
        zIndex: 20,
        shadowColor: "#000",
        shadowRadius: 4,
        shadowOpacity: 0.2,
        shadowOffset: {
            height: -4,
            width: 2,
        },
        borderWidth: 1,
    },
    listingTop: {
        width: "100%",
        paddingTop: 20,
        zIndex: 2,
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: deviceWidth * 0.03,
        paddingBottom: 10,
    },
    profWrapper: {
        backgroundColor: COLORS.white,
        flex: 1,
        paddingBottom: 30,
        width: "90%",
        top: -120,
        borderRadius: 20,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
        alignSelf: "center"
    },
    profText: {
        color: COLORS.primary,
        fontSize: 20,
        textAlign: "center",
        fontWeight: "bold",
        paddingTop: 30
    },
    basicWrapper: {
        height: deviceHeight * 0.29,
        borderRadius: 10,
        borderWidth: 1,
        borderColor: "#d5d5d5",
        marginHorizontal: 20,
        marginTop: 40,
        alignItems: "center",
    },
    infoWrapper: {
        height: 300,
        borderRadius: 10,
        borderWidth: 1,
        borderColor: "#d5d5d5",
        marginHorizontal: 20,
        marginTop: 80,
        paddingTop: 20,
        paddingHorizontal: 20
    },
    locYears: {
        display: "flex",
        flexDirection: "row",
        paddingTop: 10,
        alignItems: "center"
    },
    notEligible: {
        alignItems: "center",
        marginVertical: "10%",
    },
    noUserMessage: {
        fontSize: 16,
    },
    noUserTitle: {
        fontSize: 20,
    },
    noUserTitleWrap: {
        alignItems: "center",
    },
    noUserViewWrap: {
        justifyContent: "center",
        alignItems: "center",
        flex: 1,
    },
});

export default MyProfileScreen;
