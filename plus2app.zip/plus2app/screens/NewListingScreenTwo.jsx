/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from "react";
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity,
    BackHandler,
    ActivityIndicator,
    Linking,
    KeyboardAvoidingView, ImageBackground, TextInput, Dimensions, TouchableWithoutFeedback,
} from "react-native";

import { Formik } from "formik";
// Vector Icons
import { FontAwesome5 } from "@expo/vector-icons";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { Octicons } from "@expo/vector-icons";
import { MaterialIcons } from "@expo/vector-icons";

// Custom Components & Functions
import AppSeparator from "../components/AppSeparator";
import { COLORS } from "../variables/color";
import ListingForm from "../components/ListingForm";
import { useStateValue } from "../StateProvider";
import api, { removeAuthToken, setAuthToken } from "../api/client";
import AppButton from "../components/AppButton";
import TabScreenHeader from "../components/TabScreenHeader";
import { decodeString } from "../helper/helper";
import { __ } from "../language/stringPicker";
import { routes } from "../navigation/routes";
import Feather from "react-native-vector-icons/Feather";
import CategoryImage from "../components/CategoryImage";
import CategoryIcon from "../components/CategoryIcon";
import PremiumAds from "../components/PremiumAds";
import CacheStore from "react-native-cache-store";

const { width: screenWidth, height: screenHeight } = Dimensions.get("screen");
const NewListingScreenTwo = ({ navigation,route }) => {
    const [
        {
            NewListingScreenTwo,
            user,
            listing_locations,
            business_or_professional,
            config,
            ios,
            appSettings,
        },
        dispatch,
    ] = useStateValue();
    const [adType, setAdType] = useState("Buy & Sell");
    const [categories, setCategories] = useState({});
    const [currentCategories, setCurrentCategories] = useState([]);
    const [loading, setLoading] = useState(true);
    const [catLoading, setCatLoading] = useState(false);
    const [noSubCat, setNoSubCat] = useState(false);
    const [locationsData, setLocationsData] = useState([]);
    const [newListingConfig, setNewListingConfig] = useState({});
    const [title, setTitle] = useState("Choose Listing Type")
    const item = route.params.item 

    const handleClear = () => {
        setAdType("Buy & Sell");
        setCurrentCategories([]);
        setNoSubCat(false);
        setNewListingConfig({});

        dispatch({
            type: "SET_LISTING_LOCATIONS",
            listing_locations: null,
        });
    };
    let [counter, setCounter] = useState(0);
    const handleBackButtonClick = () => {

        setTitle(item.term_id === 102 ?
             "Choose Property Type" : item.term_id === 277 ?
              "Choose Product Type" : item.term_id === 340 ? "Choose Course Type"
               : item.term_id === 342 ? "Choose Event Type" : item.term_id === 76
                ? "Choose Job Type" : "")
        if (noSubCat === false) {
            navigation.goBack();
        } else {
            setCounter(0);
            setNoSubCat(false)
        }
     
        return true;
        
    };

    //get categories call
    // useEffect(() => {
    //     if (!adType) return;
    //     setLoading(true);
    //     CacheStore.get('categories')
    //         .then(data => {
    //             if (data === null) {
    //                 _getCategories();
    //             } else {
    //                 const arr = [...data];
    //                 const remove = [498, 353];
    //                 for (let i = 0; i < arr.length; i++) {
    //                     for (let j = 0; j < remove.length; j++) {
    //                         if (arr[i].term_id === remove[j]) {
    //                             arr.splice(i, 1);
    //                         }
    //                     }
    //                 }
    //                 setCategories({ 0: arr });
    //                 setLoading(false);
    //             }
    //         }).catch(() => {
    //             _getCategories();
    //         })
    // }, [adType])

    const _getCategories = () => {
        api.get("categories").then((res) => {
            if (res.ok) {
                let arr = res.data;
                CacheStore.set('categories', arr, 24 * 60);
                const remove = [498, 353];
                for (let i = 0; i < arr.length; i++) {
                    for (let j = 0; j < remove.length; j++) {
                        if (arr[i].term_id === remove[j]) {
                            arr.splice(i, 1);
                        }
                    }
                }
                setCategories({ 0: arr });
                setLoading(false);
            } else {
                if (res.problem === "CANCEL_ERROR") {
                    return true;
                }
            }
        });
    }

    const handleSelectedCatPress = (arg) => {
        setCurrentCategories((prevCurrentCategories) =>
            prevCurrentCategories.slice(0, arg)
        );
        const selectedData = {};
        for (let i = 0; i <= arg; i++) {
            selectedData[i] = categories[i];
        }
        setCategories(selectedData);
    };

    const catPicker = (arg) => {
        if (currentCategories.length < arg) return;
        BackHandler.addEventListener("hardwareBackPress", handleBackButtonClick);
        BackHandler.addEventListener("hardwareBackPress", () => {
            handleSelectedCatPress(arg)
        });

        
        var colors = ['#9074F8', '#FBC610', '#FE75F6', '#3AC8FF', '#41E2A0',];
        var drkColors = ["#7A4BFE","#FEA11B","#F72FB1","#19A9FF","#43E170"]
        return (
            <View key={arg}>
                {!currentCategories[arg] && (
                    <View
                        style={{
                            flexDirection: "row",
                            flexWrap: "wrap",
                            justifyContent: "center"
                        }}
                    >
                        {categories[arg].map((_category,index) => (
                            <View
                                key={_category.term_id}
                                style={{
                                    width: "50%",
                                }}>
                                <TouchableWithoutFeedback
                                    key={_category.term_id}
                                    onPress={() => {
                                        
                                        handleCategorySelection(_category)
                                    }}
                                >
                                    <View style={{
backgroundColor:!! _category.description? "#fff":colors[index % colors.length],
                                        borderRadius: 26,
                                        elevation: 5,
                                        marginBottom: 25,
                                        shadowColor: '#a9a9a9',
                                        shadowOffset: {
                                            width: 0,
                                            height: 12,
                                        },
                                        shadowOpacity: 0.58,
                                        shadowRadius: 16.00,
                                        marginHorizontal: 10,height:120,justifyContent:'center'
                                    }}>
                                        <View style={{flex:1, alignItems: "center", paddingTop: 20 }}>
                                            {_category?.icon?.url ? (
                                                <CategoryImage size={40} uri={_category.icon.url} />
                                            ) : (
                                                <CategoryIcon
                                                    iconName={_category.icon.class}
                                                    iconSize={40}
                                                    iconColor={COLORS.primary}
                                                />
                                            )}
                                        </View>
                                        <View style={{
                                            flexDirection: "row",
                                            padding: 10,
                                            alignItems: "center",borderBottomLeftRadius:26,borderBottomRightRadius:26,
                                            justifyContent: "center",
                                              backgroundColor:!! _category.description? _category.description:colors[index % colors.length],
                                        }}>
                                            <Text style={{
                                                color: "#fff",
                                                fontSize: 10,
                                                lineHeight: 29,
                                                fontFamily: "Poppins Bold",
                                                textAlign: "center"
                                            }}>{decodeString(_category.name)}</Text>
                                        </View>
                                    </View>
                                </TouchableWithoutFeedback>
                            </View>
                        ))}
                    </View>
                )}
                {/* Loading Component for Next level Picker Existance Checking */}
                {!currentCategories[arg + 1] && catLoading && (
                    <View style={styles.loading}>
                        <ActivityIndicator size="large" color={COLORS.primary} />
                    </View>
                )}
            </View>
        );
    };

    useEffect(()=>{
        getSubCategoryData(item.term_id)
    },[])

    const handleCategorySelection = (item) => {
        // console.log(item)
        setCounter(1);
        setCurrentCategories((prevCurrentCategories) => [
            ...prevCurrentCategories,
            item,
        ]);
        setCatLoading(true);
        getSubCategoryData(item.term_id);
    };

    const _getSubData = (parent_id) => {
        api.get("categories", {
            parent_id: parent_id,
        })
            .then((res) => {
                console.log(res)
                if (res.ok) {
                    const array = res.data;
                    CacheStore.set(`sub_${parent_id}`, array, 24 * 60);
                    if (res.data.length) {
                        const nwekey = Object.keys(categories).length;
                        setCategories((prevCategories) => {
                            return { ...prevCategories, [nwekey]: res.data };
                        });
                    } else {
                        setNoSubCat(true);
                    }
                    setCatLoading(false);
                } else {
                    //print error
                    // TODO handle error
                }
            });
    }

    const getSubCategoryData = (parent_id) => {
        setTitle(parent_id === 102 ? "Choose Property Type" : parent_id === 277 ? "Choose Product Type" : parent_id === 340 ? "Choose Course Type" : parent_id === 342 ? "Choose Event Type" : parent_id === 76 ? "Choose Job Type" : "")
        CacheStore.get(`sub_${parent_id}`)
            .then(data => {
                console.log(data)
                if (data === null) {
                    _getSubData(parent_id)
                } else {
                    const array = [...data];
                    if (array.length) {
                        const nwekey = Object.keys(categories).length;
                        setCategories((prevCategories) => {
                            return { ...prevCategories, [nwekey]: array };
                        });
                    } else {
                        setNoSubCat(true);
                    }
                    setCatLoading(false);
                }
            }).catch(() => {
                _getSubData(parent_id)
            })
    }

    const getCategoryTaxonomy = () => {
        let parent = currentCategories[0];
        let newArray = [...currentCategories];
        return [decodeString(parent.name), decodeString(newArray.splice(1, 1).map((item) => item.name).join(" > "))];
        // return decodeString(currentCategories.map((item) => item.name).join(" > "));
    };

    const handleLocationButtonPress = () => {
        navigation.navigate(routes.selectLocationScreen, {
            data: locationsData,
            type: "newListing",
        });
    };

    const handleChangeCategoryButtonPress = () => {
        setCurrentCategories([]);
        setAdType();
        setNoSubCat(false);
    };

    const getLocationTaxonomy = () => {
        if (!listing_locations) return;
        return decodeString(
            listing_locations.map((_location) => _location.name).join(" > ")
        );
    };

    const handleChangeLocationButtonPress = () => {
        dispatch({
            type: "SET_LISTING_LOCATIONS",
            listing_locations: [],
        });
    };

    const handleGoBack = () => {
        handleBackButtonClick();
    };

    const handleGoBackonSuccess = () => {
        handleBackButtonClick();
    };


    return user ? (
        <KeyboardAvoidingView
            behavior={ios ? "padding" : "height"}
            style={{ flex: 1, backgroundColor: COLORS.white }}
            keyboardVerticalOffset={ios ? 20 : -20}
        >
            <TabScreenHeader
                left
                onLeftClick={() => {
                    
                    handleSelectedCatPress(0);
                    handleBackButtonClick();
                }}
                style={{ elevation: 0 }}
            />
            <ScrollView>
                <View style={styles.container}>
                    <View style={styles.mainWrap}>
                        {/* Ad Category & Location Selector */}
                        {/* Category Selector Wrap */}
                        {adType && (
                            <View
                                style={
                                    !!currentCategories.length &&
                                        noSubCat
                                        ? styles.displayNone
                                        : styles.categoryWrap
                                }
                            >
                                <View style={styles.imageSearchContainer}>
                                    <View style={styles.child}>
                                        <PremiumAds admob={false}/>
                                        <View style={{ position: 'absolute', left: 0, right: 0, top: 20, }}>
                                            <View style={styles.listingTop}>
                                                <Formik initialValues={{ search: "" }}>
                                                    {() => (
                                                        <View style={styles.ListingSearchContainer}>
                                                            <TextInput
                                                                style={styles.searchInput}
                                                                placeholder={
                                                                    __(
                                                                        "homeScreenTexts.listingSearchPlaceholder",
                                                                        appSettings.lng
                                                                    )
                                                                }
                                                                placeholderTextColor={COLORS.textGray}
                                                                returnKeyType="search"
                                                            />

                                                            <TouchableOpacity
                                                                style={styles.listingSearchBtnContainer}
                                                            >
                                                                                                      <Text style={{color:'#fff'}}>Search</Text>

                                                            </TouchableOpacity>
                                                        </View>
                                                    )}
                                                </Formik>
                                            </View>
                                        </View>
                                    </View>
                                </View>
                                <View style={styles.categoryTitleWrap}>
                                    <Text style={styles.categoryTitle}>
                                        {title}
                                    </Text>
                                </View>
                                {loading && !Object.keys(categories).length ? (
                                    <View style={styles.loading}>
                                        <ActivityIndicator size="large" color={COLORS.primary} />
                                    </View>
                                ) : (
                                    <View style={styles.adCategory}>
                                        {Object.keys(categories).map((_cat, index) =>
                                            catPicker(index)
                                        )}
                                    </View>
                                )}
                            </View>
                        )}
                        {/* Category & Location Change Button Wrap */}
                        <View
                            style={styles.displayNone}
                        >

                            {/* Location Change Button Wrap */}
                            {config.location_type === "local" && (
                                <View
                                    style={[
                                        styles.categoryChangeWrap,
                                        { backgroundColor: COLORS.bg_primary },
                                    ]}
                                >
                                    <View style={{ flex: 1 }}>
                                        <Text style={styles.categoryRoute}>
                                            {getLocationTaxonomy()}
                                        </Text>
                                    </View>
                                    <TouchableOpacity
                                        style={styles.routeChangeIconWrap}
                                        onPress={handleChangeLocationButtonPress}
                                    >
                                        <MaterialIcons
                                            name="mode-edit"
                                            size={14}
                                            color={COLORS.white}
                                        />
                                    </TouchableOpacity>
                                </View>
                            )}
                        </View>
                        {adType &&
                            !!currentCategories.length &&
                            noSubCat && (
                                <ListingForm
                                    catId={
                                        currentCategories[currentCategories.length - 1].term_id
                                    }
                                    type={adType}
                                    catName={currentCategories[currentCategories.length - 1].name}
                                    taxonomy={getCategoryTaxonomy()}
                                    goBack={handleGoBackonSuccess}
                                    parent={currentCategories[0].term_id}
                                />
                            )}
                    </View>
                </View>
            </ScrollView>
        </KeyboardAvoidingView>
    ) : (
        <>

            <TabScreenHeader
                left={user && NewListingScreenTwo}
                onLeftClick={handleGoBack}
                style={{ elevation: 0 }}
            />
            <View style={styles.noUserViewWrap}>
                <View style={styles.noUserTitleWrap}>
                    <Text style={styles.noUserTitle}>
                        {__("NewListingScreenTwoTexts.notLoggedIn", appSettings.lng)}
                    </Text>
                    <Text style={styles.noUserMessage}>
                        {__("NewListingScreenTwoTexts.loginOrSignUp", appSettings.lng)}
                    </Text>
                    <View style={styles.authButtonWrap}>
                        <AppButton
                            style={styles.authButton}
                            title={__(
                                "NewListingScreenTwoTexts.loginOrSignUpButtonTitle",
                                appSettings.lng
                            )}
                            onPress={() => navigation.navigate(routes.signuploginScreen)}
                        />
                    </View>
                </View>
            </View>
        </>
    );
};

const styles = StyleSheet.create({
    adCategory: {
        marginBottom: 5,
    },
    adType: {},
    authButton: {
        borderRadius: 3,
        width: "100%",
        paddingHorizontal: 20,
        paddingVertical: 10,
    },
    authButtonWrap: {
        marginVertical: 20,
        width: "100%",
    },
    button: {
        width: "45%",
    },
    buttonWrap: {
        flexDirection: "row",
        width: "100%",
        alignItems: "center",
        justifyContent: "space-around",
        paddingHorizontal: "3%",
        marginTop: "5%",
    },
    categoryChangeWrap: {
        paddingVertical: 10,
        alignItems: "center",
        justifyContent: "space-between",
        flexDirection: "row",
        paddingHorizontal: "3%",
    },
    categoryPickerFieldText: {
        textTransform: "capitalize",
    },
    categoryPickerFieldWrap: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        borderWidth: 1,
        borderColor: COLORS.gray,
        borderRadius: 3,
        paddingVertical: 5,
        paddingHorizontal: "3%",
        marginVertical: 10,
    },
    categoryPickerOptions: {
        backgroundColor: COLORS.white,
        padding: 8,
        marginVertical: 5,
        marginHorizontal: 3,
        borderRadius: 3,
        borderWidth: 1,
        borderColor: COLORS.bg_dark,
    },
    categoryPickerOptionsText: {
        fontSize: 13,
        fontWeight: "bold",
        color: COLORS.text_gray,
    },
    categoryPickerWrap: {},
    categoryTitle: {
        fontSize: 24,
        fontFamily: "Poppins Bold",
        color: COLORS.headingsColor,
        paddingHorizontal: 10,
        lineHeight: 51,
    },
    categoryRoute: {
        fontSize: 15,
        color: COLORS.text_gray,
        fontWeight: "bold",
    },
    categoryTitleWrap: {
        alignItems: "center",
        paddingVertical: 15,
    },
    categoryWrap: {
        paddingHorizontal: "3%",
    },
    changeCategory: {
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        padding: 5,
        marginTop: 10,
        borderRadius: 3,
        backgroundColor: COLORS.primary,
    },
    changecategoryText: {
        color: COLORS.white,
        paddingRight: 5,
    },
    changeCategoryWrap: {
        marginBottom: 10,
    },
    checkWrap: {
        alignItems: "center",
        marginVertical: "10%",
    },
    container: {
        flex: 1,
        backgroundColor: COLORS.white,
    },
    displayNone: {
        display: "none",
    },
    flashMessage: {
        position: "absolute",
        backgroundColor: "green",
        width: "100%",
        justifyContent: "center",
        alignItems: "center",
        height: 50,
        bottom: 0,
        zIndex: 2,
    },
    formSeparator: {
        width: "100%",
    },
    freeAdText: {
        backgroundColor: COLORS.light_green,
        width: "80%",
        textAlign: "center",
        color: COLORS.dark_green,
        borderRadius: 3,
        paddingVertical: 8,
        fontSize: 16,
    },
    freeAdWrap: {
        paddingHorizontal: "3%",
        alignItems: "center",
        marginVertical: 15,
    },
    locationSelector: {
        justifyContent: "center",
        alignItems: "center",
        padding: 8,
        borderRadius: 3,
        backgroundColor: COLORS.primary,
    },
    locationSelectorText: {
        color: COLORS.white,
        paddingRight: 5,
        fontWeight: "bold",
        fontSize: 13,
    },
    internalSeparator: {
        marginVertical: 10,
        width: "100%",
    },
    locationWrap: {
        marginVertical: 10,
    },
    mainWrap: {},
    mandatory: {
        color: COLORS.red,
        fontSize: 16,
    },
    remainingAdsText: {
        fontSize: 16,
        marginVertical: "2%",
        paddingHorizontal: "3%",
        textAlign: "center",
    },
    routeArrow: {
        color: COLORS.text_gray,
    },
    routeChangeIconWrap: {
        padding: 3,
        backgroundColor: "#ff6600",
        borderRadius: 3,
        alignItems: "center",
        justifyContent: "center",
    },
    separator: {
        width: "100%",
        backgroundColor: COLORS.bg_dark,
    },
    title: {
        fontSize: 18,
        fontWeight: "bold",
        color: COLORS.text_gray,
        paddingVertical: 10,
    },
    titleWrap: {
        paddingHorizontal: "3%",
        alignItems: "center",
    },

    typePickerFieldWrap: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        paddingHorizontal: "3%",
        marginVertical: 15,
    },
    typePickerOptions: {
        marginVertical: 5,
    },
    types: {
        fontWeight: "bold",
        color: COLORS.text_gray,
        paddingLeft: 18,
    },
    typePickerWrap: {
        paddingVertical: 10,
    },
    typeTitle: {
        fontSize: 14,
        fontWeight: "bold",
        color: COLORS.text_dark,
        paddingHorizontal: 10,
    },
    typeTitleWrap: {
        flexDirection: "row",
        alignItems: "center",
        paddingTop: 10,
        paddingBottom: 15,
    },
    typeWrap: {
        paddingHorizontal: "3%",
    },
    loading: {
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        opacity: 0.8,
        backgroundColor: "transparent",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 5,
        flex: 1,
    },
    notEligible: {
        alignItems: "center",
        marginVertical: "10%",
    },
    noUserMessage: {
        fontSize: 16,
    },
    noUserTitle: {
        fontSize: 20,
    },
    noUserTitleWrap: {
        alignItems: "center",
    },
    noUserViewWrap: {
        justifyContent: "center",
        alignItems: "center",
        flex: 1,
    },
    selectedCategory: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",

        padding: 8,
        borderRadius: 3,
        marginVertical: 5,
    },
    selectedCategoryText: {
        fontSize: 13,
        fontWeight: "bold",
        paddingLeft: 18,
    },
    ListingSearchContainer: {
        flex: 1,
        height: 45,
        marginHorizontal: 20,
        backgroundColor: COLORS.white,
        borderWidth: 1,
        borderRadius: 50,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        paddingHorizontal: 15,
        elevation: 7,
        zIndex: 20,
        shadowColor: "#000",
        shadowRadius: 4,
        shadowOpacity: 0.2,
        shadowOffset: {
            height: -4,
            width: 2,
        },
    },
    searchInput: {
        flex: 1,
        fontFamily: "Poppins Regular"
    },
    
    child: {
        // top: -100,
        flex: 1,
        // transform: [{ scaleX: 0.5 }],
        alignItems: 'center',
        justifyContent: 'center'
    },
    listingTop: {
        width: "100%",
        // paddingTop: 100,
        zIndex: 1,
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: screenWidth * 0.03,
        paddingBottom: 10,
    },
    listingSearchBtnContainer: {
        marginLeft: 5,
        marginRight: -10,
        backgroundColor: COLORS.primary,
        borderRadius: 5,
        padding: 8
    },
    ListingSearchContainer: {
        flex: 1,
        height: 45,
        marginHorizontal: 10,
        backgroundColor: COLORS.white,
        borderWidth: 1,
        borderRadius: 4,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        paddingHorizontal: 15,
        elevation: 7,
        zIndex: 20,
        shadowColor: "#000",
        shadowRadius: 4,
        shadowOpacity: 0.2,
        shadowOffset: {
            height: -4,
            width: 2,
        },
    },
    imageSearchContainer: {
        paddingTop: 0,
        paddingHorizontal: 10,
        
        height: 250,
        width: '100%',
        backgroundColor: "#fff",
        // transform: [{ scaleX: 2 }],
        overflow: 'hidden',
    },
});

export default NewListingScreenTwo;
