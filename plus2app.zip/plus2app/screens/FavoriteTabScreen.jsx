/* eslint-disable no-unused-vars */
import React, { useState, useEffect, useCallback, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  Alert,
  ActivityIndicator,
  FlatList,
  ImageBackground,
  TextInput,
  TouchableOpacity,
  Dimensions,
  ScrollView,
  RefreshControl,
} from "react-native";

// vector Icons
import { Feather, FontAwesome } from "@expo/vector-icons";
import { FontAwesome5 } from "@expo/vector-icons";
import TabScreenHeader from "../components/TabScreenHeader";

// Custom Components & Functions
import { useStateValue } from "../StateProvider";
import FavoritesFlatList from "../components/FavoritesFlatList";
import AppButton from "../components/AppButton";
import { COLORS } from "../variables/color";
import api, { setAuthToken, removeAuthToken } from "../api/client";
import FlashNotification from "../components/FlashNotification";
import LoadingIndicator from "../components/LoadingIndicator";
import { paginationData } from "../app/pagination/paginationData";
import { __ } from "../language/stringPicker";
import { routes } from "../navigation/routes";
import AccountScreen from "./AccountScreen";
import { useNavigation } from "@react-navigation/native";
import { DrawerLayout } from "react-native-gesture-handler";
import { Formik } from "formik";
import PremiumAds from "../components/PremiumAds";
import DrawerMenu from "../components/DrawerMenu";

const { width: screenWidth, height: screenHeight } = Dimensions.get("screen");
const FavoritesTabScreen = () => {
  const [{ ios }] = useStateValue();
  const drawer = useRef(null);
  const [drawerPosition] = useState("left");
  const navigation = useNavigation();
  const [{ user, auth_token, is_connected, appSettings }, dispatch] =
    useStateValue();

  const [myFavs, setMyFavs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [initial, setInitial] = useState(true);
  const [errorMessage, setErrorMessage] = useState();
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [moreLoading, setMoreLoading] = useState(false);
  const [pagination, setPagination] = useState({});
  const [currentPage, setCurrentPage] = useState(
    pagination.current_page || paginationData.favourites.page
  );
  const [flashNotification, setFlashNotification] = useState(false);
  const [flashNotificationMessage, setFlashNotificationMessage] = useState();

  // useEffect(() => {
  //     const focused = navigation.addListener('focus', () => {
  //         setLoading(true);
  //         handleLoadFavsList(paginationData.favourites);
  //     });
  //     return focused;
  // }, [navigation]);

  const navigationView = () => (
    // eslint-disable-next-line no-undef
    <View style={[styles.container]}>
      <DrawerMenu close={() => drawer.current.closeDrawer()} />
    </View>
  );

  // Initial get listing call
  useEffect(() => {
    if (!initial) return;
    handleLoadFavsList(paginationData.favourites);
    setInitial(false);
  }, [initial]);

  // initial load conversation
  useEffect(() => {
    if (!user) return;
    handleLoadFavsList(paginationData.favourites);
  }, [user]);

  // Refresh get listing call
  useEffect(() => {
    if (!refreshing) return;
    setCurrentPage(1);
    setPagination({});
    handleLoadFavsList(paginationData.favourites);
  }, [refreshing]);

  // next page get listing call
  useEffect(() => {
    if (!moreLoading) return;
    const data = {
      per_page: paginationData.favourites.per_page,
      page: currentPage,
    };
    handleLoadFavsList(data);
  }, [moreLoading]);

  const handleLoadFavsList = (data) => {
    setAuthToken(auth_token);
    api.get("my/favourites", data).then((res) => {
      if (res.ok) {
        if (refreshing) {
          setRefreshing(false);
          setLoading(false);
        }
        if (moreLoading) {
          setMyFavs((prevMyFavs) => [...prevMyFavs, ...res.data.data]);
          setMoreLoading(false);
        } else {
          setMyFavs(res.data.data);
          setLoading(false);
        }
        setPagination(res?.data?.pagination || {});

        removeAuthToken();
      } else {
        if (refreshing) {
          setRefreshing(false);
        }
        if (moreLoading) {
          setMoreLoading(false);
        }
        handleError(
          res?.data?.error_message ||
            res?.data?.error ||
            res?.problem ||
            __(
              "favoritesScreenTexts.customServerResponseError",
              appSettings.lng
            )
        );
        if (loading) {
          setLoading(false);
        }
        removeAuthToken();
      }
    });
  };

  const handleRemoveFavAlert = (listing) => {
    Alert.alert(
      "",
      __("favoritesScreenTexts.removePromptMessage", appSettings.lng),
      [
        {
          text: __("favoritesScreenTexts.cancelButtonTitle", appSettings.lng),

          style: "cancel",
        },
        {
          text: __("favoritesScreenTexts.removeButtonTitle", appSettings.lng),
          onPress: () => handleRemoveFromFavorites(listing),
        },
      ],
      { cancelable: false }
    );
  };
  const handleRemoveFromFavorites = (listing) => {
    setDeleteLoading(true);
    setAuthToken(auth_token);
    api
      .post("my/favourites", { listing_id: listing.listing_id })
      .then((res) => {
        if (res.ok) {
          setMyFavs(myFavs.filter((fav) => fav != listing));
          removeAuthToken();
          setDeleteLoading(false);
          handleSuccess(
            __("favoritesScreenTexts.favRemoveSuccessMessage", appSettings.lng)
          );
        } else {
          setErrorMessage(
            res?.data?.error_message ||
              res?.data?.error ||
              res?.problem ||
              __(
                "favoritesScreenTexts.favRemoveErrorCustomMessage",
                appSettings.lng
              )
          );
          removeAuthToken();
          setDeleteLoading(false);
          handleError(
            res?.data?.error_message ||
              res?.data?.error ||
              res?.problem ||
              __(
                "favoritesScreenTexts.favRemoveErrorCustomMessage",
                appSettings.lng
              )
          );
        }
      });
  };

  const handleNewListing = () => {
    navigation.navigate(routes.newListingScreen);
    dispatch({
      type: "SET_NEW_LISTING_SCREEN",
      newListingScreen: true,
    });
  };

  const renderFavsItem = ({ item, index }) => (
    <>
      <FavoritesFlatList
        item={item}
        onDelete={() => handleRemoveFavAlert(item)}
        onClick={() => handleViewListing(item)}
      />
      {index % 20 == 19 && (
        // {item.listAd && (
        <View
          style={{
            alignItems: "center",
          }}
        >
          <PremiumAds admob={true} />
        </View>
      )}
    </>
  );

  const handleViewListing = (item) => {
    navigation.navigate(routes.listingDetailScreen, {
      listingId: item.listing_id,
    });
  };

  const keyExtractor = useCallback((item, index) => `${index}`, []);

  const listFooter = () => {
    if (pagination && pagination.total_pages > pagination.current_page) {
      return (
        <View style={styles.loadMoreWrap}>
          <ActivityIndicator size="small" color={COLORS.primary} />
        </View>
      );
    } else {
      return null;
    }
  };

  const onRefresh = () => {
    if (moreLoading) return;
    setRefreshing(true);
  };

  const handleNextPageLoading = () => {
    console.log("handleNextPageLoading");
    if (refreshing) return;
    if (pagination && pagination.total_pages > pagination.current_page) {
      setCurrentPage((prevCurrentPage) => prevCurrentPage + 1);
      setMoreLoading(true);
    }
  };

  const handleSuccess = (message) => {
    setFlashNotificationMessage(message);
    setTimeout(() => {
      setFlashNotification(true);
    }, 10);
    setTimeout(() => {
      setFlashNotification(false);
      setFlashNotificationMessage();
    }, 1000);
  };
  const handleError = (message) => {
    setFlashNotificationMessage(message);
    setTimeout(() => {
      setFlashNotification(true);
    }, 10);
    setTimeout(() => {
      setFlashNotification(false);
      setFlashNotificationMessage();
    }, 1200);
  };

  const isCloseToBottom = ({
    layoutMeasurement,
    contentOffset,
    contentSize,
  }) => {
    return (
      layoutMeasurement.height + contentOffset.y >= contentSize.height - 20
    );
  };

  return (
    <DrawerLayout
      ref={drawer}
      drawerWidth={380}
      drawerPosition={drawerPosition}
      renderNavigationView={navigationView}
      drawerBackgroundColor={"#ffffff"}
    >
      <TabScreenHeader drawer showDrawer={() => drawer.current.openDrawer()} />
      {!!user ? (
        is_connected ? (
          <View
            style={{
              backgroundColor: COLORS.white,
              height: screenHeight,
              flex: 1,
            }}
          >
            {loading ? (
              <View style={styles.loadingWrap}>
                <View style={styles.loading}>
                  <ActivityIndicator size="large" color={COLORS.primary} />
                  <Text style={styles.loadingMessage}>
                    {__("favoritesScreenTexts.loadingMessage", appSettings.lng)}
                  </Text>
                </View>
              </View>
            ) : (
              <>
                {!!deleteLoading && (
                  <View style={styles.deleteLoading}>
                    <View style={styles.deleteLoadingContentWrap}>
                      <LoadingIndicator
                        visible={true}
                        style={{
                          width: "100%",
                          marginLeft: "3.125%",
                        }}
                      />
                    </View>
                  </View>
                )}
                <ScrollView
                  showsVerticalScrollIndicator={false}
                  onScroll={({ nativeEvent }) => {
                    if (isCloseToBottom(nativeEvent)) {
                      console.log("Close to bottom");
                      handleNextPageLoading();
                    }
                  }}
                  refreshControl={
                    <RefreshControl
                      onRefresh={onRefresh}
                      refreshing={refreshing}
                    />
                  }
                >
                  <View style={styles.imageSearchContainer}>
                    <View style={styles.child}>
                      <PremiumAds admob={false} />
                      <View
                        style={{
                          position: "absolute",
                          left: 0,
                          right: 0,
                          top: 20,
                        }}
                      >
                        <View style={styles.listingTop}>
                          <Formik initialValues={{ search: "" }}>
                            {() => (
                              <View style={styles.ListingSearchContainer}>
                                <TextInput
                                  style={styles.searchInput}
                                  placeholder={__(
                                    "homeScreenTexts.listingSearchPlaceholder",
                                    appSettings.lng
                                  )}
                                  placeholderTextColor={COLORS.textGray}
                                />
                                <TouchableOpacity
                                  style={styles.listingSearchBtnContainer}
                                >
                                  {/* <Feather
                                                                    name="search"
                                                                    size={20}
                                                                    color={COLORS.white}
                                                                /> */}
                                  <Text style={{ color: "#fff" }}>Search</Text>
                                </TouchableOpacity>
                              </View>
                            )}
                          </Formik>
                        </View>
                      </View>
                    </View>
                  </View>
                  <View
                    style={{
                      marginHorizontal: "5%",
                      paddingHorizontal: 20,
                      borderRadius: 20,
                      top: -90,
                      backgroundColor: COLORS.white,
                      shadowColor: "#a9a9a9",
                      shadowOffset: {
                        width: 0,
                        height: 12,
                      },
                      shadowOpacity: 0.58,
                      shadowRadius: 16.0,
                      elevation: 24,
                    }}
                  >
                    <Text
                      style={{
                        color: COLORS.primary,
                        textAlign: "center",
                        fontSize: 24,
                        fontFamily: "Poppins Bold",
                        lineHeight: 36,
                        marginTop: 24,
                        paddingTop: 10,
                      }}
                    >
                      Favourites
                    </Text>

                    {!!myFavs.length && (
                      <View
                        style={{
                          backgroundColor: COLORS.white,
                          flex: 1,
                          paddingVertical: 5,
                        }}
                      >
                        <FlatList
                          data={myFavs}
                          renderItem={renderFavsItem}
                          keyExtractor={keyExtractor}
                          horizontal={false}
                          showsVerticalScrollIndicator={false}
                          // onEndReached={handleNextPageLoading}
                          onEndReachedThreshold={0.2}
                          ListFooterComponent={listFooter}
                          contentContainerStyle={{
                            marginTop: 20,
                            paddingTop: ios ? 0 : 5,
                          }}
                        />
                      </View>
                    )}
                    {!myFavs.length && (
                      <View style={styles.noFavWrap}>
                        <FontAwesome
                          name="exclamation-triangle"
                          size={100}
                          color={COLORS.primary_soft}
                        />
                        <Text style={styles.noFavTitle}>
                          {__(
                            "favoritesScreenTexts.noFavoriteMessage",
                            appSettings.lng
                          )}
                        </Text>
                      </View>
                    )}
                  </View>
                </ScrollView>
                <FlashNotification
                  falshShow={flashNotification}
                  flashMessage={flashNotificationMessage}
                />
              </>
            )}
          </View>
        ) : (
          <View style={styles.noInternet}>
            <FontAwesome5
              name="exclamation-circle"
              size={24}
              color={COLORS.primary}
            />
            <Text style={styles.text}>
              {__("myProfileScreenTexts.noInternet", appSettings.lng)}
            </Text>
          </View>
        )
      ) : (
        <>
          <View style={styles.noUserViewWrap}>
            <View style={styles.noUserTitleWrap}>
              <Text style={styles.noUserTitle}>
                {__("newListingScreenTexts.notLoggedIn", appSettings.lng)}
              </Text>
              <Text style={styles.noUserMessage}>
                Please login or sign up to see your favorite ads
              </Text>
              <View style={styles.authButtonWrap}>
                <AppButton
                  style={styles.authButton}
                  title={__(
                    "newListingScreenTexts.loginOrSignUpButtonTitle",
                    appSettings.lng
                  )}
                  textStyle={{ paddingHorizontal: 20 }}
                  onPress={() => navigation.navigate(routes.signuploginScreen)}
                />
              </View>
            </View>
          </View>
        </>
      )}
    </DrawerLayout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fafafa",
  },
  containerNoFavs: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  deleteLoading: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    opacity: 0.8,
    backgroundColor: "rgba(255,255,255,.5)",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 5,
    flex: 1,
    height: "100%",
    width: "100%",
  },
  loading: {
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    opacity: 0.8,
    backgroundColor: "transparent",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 5,
    flex: 1,
  },
  loadingWrap: {
    justifyContent: "center",
    alignItems: "center",
    flex: 1,
  },
  noFavTitle: {
    fontSize: 18,
    color: COLORS.text_gray,
    marginTop: 10,
    textAlign: "center",
    fontFamily: "Poppins Regular",
  },
  noFavWrap: {
    alignItems: "center",
    marginHorizontal: "3%",
    flex: 1,
    justifyContent: "center",
    paddingVertical: 100,
  },
  noInternet: {
    alignItems: "center",
    flex: 1,
    backgroundColor: "white",
    justifyContent: "center",
    width: "100%",
    height: "100%",
  },
  postButton: {
    borderRadius: 3,
    marginTop: 40,
    width: "60%",
  },
  notEligible: {
    alignItems: "center",
    marginVertical: "10%",
  },
  noUserMessage: {
    fontSize: 16,
    color: COLORS.black,
  },
  noUserTitle: {
    fontSize: 20,
    fontFamily: "Poppins Regular",
  },
  noUserTitleWrap: {
    alignItems: "center",
  },
  noUserViewWrap: {
    justifyContent: "center",
    alignItems: "center",
    flex: 1,
  },
  listingSearchBtnContainer: {
    marginLeft: 5,
    marginRight: -10,
    backgroundColor: COLORS.primary,
    borderRadius: 5,
    padding: 8,
  },
  ListingSearchContainer: {
    flex: 1,
    height: 45,
    marginHorizontal: 10,
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderRadius: 4,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 15,
    elevation: 7,
    zIndex: 20,
    shadowColor: "#000",
    shadowRadius: 4,
    shadowOpacity: 0.2,
    shadowOffset: {
      height: -4,
      width: 2,
    },
  },
  imageSearchContainer: {
    paddingTop: 0,
    paddingHorizontal: 10,

    height: 250,
    width: "100%",
    backgroundColor: "#fff",
    // transform: [{ scaleX: 2 }],
    overflow: "hidden",
  },
  child: {
    // top: -100,
    flex: 1,
    // transform: [{scaleX: 0.5}],
    alignItems: "center",
    justifyContent: "center",
  },
  listingTop: {
    width: "100%",
    // paddingTop: 100,
    zIndex: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: screenWidth * 0.03,
    paddingBottom: 10,
  },
  searchInput: {
    flex: 1,
    fontFamily: "Poppins Regular",
  },
  authButton: {
    marginTop: 30,
    borderRadius: 50,
  },
});

export default FavoritesTabScreen;
