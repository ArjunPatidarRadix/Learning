/* eslint-disable no-unused-vars */
/* eslint-disable no-undef */
import React, {
  useState,
  useEffect,
  useCallback,
  useRef,
  useMemo,
} from "react";
import {
  View,
  StyleSheet,
  Text,
  TouchableOpacity,
  TextInput,
  Dimensions,
  Animated,
  ActivityIndicator,
  Keyboard,
  RefreshControl,
  ScrollView,
} from "react-native";
import DrawerLayout from "react-native-gesture-handler/DrawerLayout";
// Vector Fonts
import { Feather } from "@expo/vector-icons";
import { Fontisto } from "@expo/vector-icons";
import { Formik } from "formik";
import Carousel, { Pagination } from "react-native-snap-carousel";
// Custom Components & Constants
import { COLORS } from "../variables/color";
import TabScreenHeader from "../components/TabScreenHeader";
import { useStateValue } from "../StateProvider";
import api, { removeAuthToken, setAuthToken } from "../api/client";
import { decodeString, insertAndShift } from "../helper/helper";
import FlashNotification from "../components/FlashNotification";
import ListingCard from "../components/ListingCard";
import { paginationData } from "../app/pagination/paginationData";
import CategoryIcon from "../components/CategoryIcon";
import CategoryImage from "../components/CategoryImage";
import { __ } from "../language/stringPicker";
import { routes } from "../navigation/routes";
import { useNavigation } from "@react-navigation/native";
import PremiumAds from "../components/PremiumAds";
import { SwiperFlatList } from "react-native-swiper-flatlist";
import DrawerMenu from "../components/DrawerMenu";
import * as Location from "expo-location";
import CacheStore from "react-native-cache-store";
import HorizontalTiles from "../components/HorizontalTiles";
import CategoriesListings from "./CategoriesListings";
import color from "color";
import { G } from "react-native-svg";
import { FlatList } from "react-native";
import PagerView from "react-native-pager-view";
import { admobConfig } from "../app/services/adMobConfig";

const { width: screenWidth, height: screenHeight } = Dimensions.get("screen");

const HomeScreen = () => {
  const drawer = useRef(null);
  const ref = useRef(null);
  const [drawerPosition] = useState("left");
  const navigation = useNavigation();
  const [{ user, config, appSettings }, dispatch] = useStateValue();
  // console.log(user)
  const [topCategoriesData, setTopCategoriesData] = useState([]);
  const [pagination, setPagination] = useState({});
  const [offset, setOffset] = useState(20);

  const [searchData, setSearchData] = useState(() => {
    return {
      ...paginationData.home,
      search: "",
      locations: "",
      categories: "",
      page: 1,
      onScroll: false,
      per_page: offset,
    };
  });

  const [locationsData, setLocationsData] = useState([]);
  const [listingsData, setListingsData] = useState([]);
  const [featuredListingsData, setFeaturedListingsData] = useState([]);
  const [videoListingsData, setVideoListingsData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [moreLoading, setMoreLoading] = useState(false);
  const [initial, setInitial] = useState(true);
  const [flashNotification, setFlashNotification] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [timedOut, setTimedOut] = useState();
  const [networkError, setNetworkError] = useState();
  const [retry, setRetry] = useState(false);
  const [country, setCountry] = useState("");
  const [city, setCity] = useState("");
  const [activeCategorySlide, setActiveSlide] = useState(0);
  const [gettingData, setGettingData] = useState(false);
  const [parentId, setParentId] = useState(null);

  // First we can get categories and locations(from server) when page loaded.
  // After we get location(device), we can get ads and category

  useEffect(() => {
    dispatch({
      type: "SET_NEW_LISTING_SCREEN",
      newListingScreen: false,
    });
    handleLoadTopCategories();
    handleLoadLocations();
  }, []);

  // When country loaded, we can call ads
  useEffect(() => {
    if (country !== "") {
      handleLoadPremiumAds(country);
    }
  }, [country]);

  // Load Listing Data
  useEffect(() => {
    if (locationsData.length > 0 && country !== "") {
      setLoading(true);
      setGettingData(true);
    }
  }, [locationsData, country]);

  useEffect(() => {
    if (!gettingData) return;
    dispatch({
      type: "SET_NEW_LISTING_SCREEN",
      newListingScreen: false,
    });
    handleLoadListingsData();
  }, [gettingData]);

  const _getLocations = () => {
    api.get("locations").then((res) => {
      if (res.ok) {
        setLocationsData(res.data);
        CacheStore.set("locations", res.data, 24 * 60);
      } else {
        if (res.problem === "CANCEL_ERROR") {
          return true;
        }
      }
    });
  };

  const handleLoadLocations = () => {
    CacheStore.get("locations")
      .then((data) => {
        if (data === null) {
          _getLocations();
        } else {
          setLocationsData(data);
        }
      })
      .catch((error) => {});
  };

  useEffect(() => {
    _getListingData();
  }, [country]);

  // Get Listing on Next Page Request
  useEffect(() => {
    if (!searchData.onScroll) return;

    _getListingData(true);
  }, [searchData.onScroll]);

  // console.log(locationsData)
  const _getListingData = (onScroll) => {
    console.log("_getListingData called () ----------");

    const serachLocations =
      country !== ""
        ? locationsData
            .filter((location) => location.name === country)
            .map((location) => location.term_id)
        : [];
    // console.log(city)
    // const searchCities = city !== "" ? locationsData
    // .filter(location => location.name === country)
    // .map((location) => location.term_id) : [];
    setSearchData((prevSearchData) => {
      return {
        ...prevSearchData,
        locations: [609],
        categories: [498, 277, 340, 102, 353, 342, 76],
      };
    });
    const s = { ...searchData, locations: serachLocations };
    console.log("------redddd", s);

    api.get("listings", s).then((res) => {
      // console.log('------redddd',res)
      if (res.ok) {
        const array = res.data.data;
        CacheStore.set("listingData", array, 1);

        for (let i = 0; i < array.length; i++) {
          if (array[i]?.contact.locations[1] !== undefined) {
            if (array[i]?.contact.locations[1].name !== city) {
              insertAndShift(array, i, array.length - 1);
            }
          }
        }

        // console.log(array)
        console.log(
          "_getListingData : set lisitng data ::::-----",
          JSON.stringify(res.data.data.length)
        );
        console.log(
          "_getListingData :res :::::-----",
          JSON.stringify(res.data.pagination)
        );
        console.log("onScroll : ", onScroll);
        // setListingsData(array); //commented and added below code for lazy loading changes
        //lazy loading start
        if (onScroll) {
          if (admobConfig.admobEnabled) {
            setListingsData((prevListingsData) => [
              ...prevListingsData,
              ...res.data.data,
            ]);
          } else {
            setListingsData((prevListingsData) => [
              ...prevListingsData,
              ...res.data.data,
            ]);
          }
          setSearchData((prevSearchData) => {
            return {
              ...prevSearchData,
              onScroll: false,
              page: 1,
            };
          });
        } else {
          setListingsData(res.data.data);
        }
        console.log("setListingsData size :: ", listingsData.length);
        setPagination(res.data.pagination ? res.data.pagination : {});

        //lazy loading end
        setFeaturedListingsData(
          array.filter((data) => data.badges.includes("is-featured"))
        );
        let videoListings = array.filter((data) =>
          data.badges.includes("is-new")
        );
        if (videoListings.length > 10) {
          videoListings = videoListings.slice(1, 10);
        }
        setVideoListingsData(videoListings);

        if (initial) {
          setInitial(false);
        }

        setLoading(false);
      } else {
        if (refreshing) {
          setRefreshing(false);
        }
        if (res.problem === "CANCEL_ERROR") {
          return true;
        }
        if (res.problem === "TIMEOUT_ERROR") {
          setTimedOut(true);
        }
      }
      setMoreLoading(false);
      setGettingData(false);
    });
  };
  // console.log(locationsData)

  //added function for lazy loading
  const handleNextPageLoading = () => {
    console.log("handleNextPageLoading ::::::");
    setMoreLoading(true);

    if (
      pagination &&
      pagination.total_pages > pagination.current_page &&
      !moreLoading
    ) {
      setMoreLoading(true);
      //   _getListingData();
      setSearchData((prevSearchData) => {
        return {
          ...prevSearchData,
          page: pagination.current_page + 1,
          onScroll: true,
          per_page: offset,
        };
      });
    }
  };

  const handleLoadListingsData = () => {
    console.log("handleLoadListingsData called () ----------");
    CacheStore.get("listingData")
      .then((data) => {
        if (data === null) {
          _getListingData();
        } else {
          const array = [...data];

          for (let i = 0; i < array.length; i++) {
            if (array[i]?.contact.locations[1] !== undefined) {
              if (array[i]?.contact.locations[1].name !== city) {
                insertAndShift(array, i, array.length - 1);
              }
            }
          }
          setListingsData((prevListingsData) => [
            ...prevListingsData,
            ...array,
          ]);
          //   setListingsData(array);
          setFeaturedListingsData(
            data.filter((data) => data.badges.includes("is-featured"))
          );
          let videoListings = data.filter((data) =>
            data.badges.includes("is-new")
          );
          if (videoListings.length > 10) {
            videoListings = videoListings.slice(1, 10);
          }
          // console.log(videoListings)
          setVideoListingsData(videoListings);

          setMoreLoading(false);
          setLoading(false);
          setGettingData(false);
        }
      })
      .catch(() => {
        _getListingData();
      });
  };

  const _getCategories = () => {
    api.get("categories").then((res) => {
      if (res.ok) {
        var arr = res.data;
        CacheStore.set("categories", arr, 24 * 60);
        // const remove = [352, 278, 338];
        // for (let i = 0; i < arr.length; i++) {
        //     for (let j = 0; j < remove.length; j++) {
        //         if (arr[i].term_id === remove[j]) {
        //             arr.splice(i, 1);
        //         }
        //     }
        // }
        setTopCategoriesData(arr);
        dispatch({
          type: "SET_CATEGORIES_DATA",
          categories_data: res.data,
        });
      } else {
        if (res.problem === "CANCEL_ERROR") {
          return true;
        }
      }
    });
  };

  useEffect(() => {
    getLocationWiseData();
  }, []);

  const getLocationWiseData = async () => {
    try {
      // console.log('ffffff',user)
      if (user !== null && !!user.latitude) {
        let { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== "granted") {
          setErrorMsg("Permission to access location was denied");
          return;
        }
        let { longitude, latitude } = user;

        let regionName = await Location.reverseGeocodeAsync({
          latitude: parseFloat(latitude),
          longitude: parseFloat(longitude),
        });

        const countryName =
          typeof regionName[0].country === "object"
            ? JSON.stringify(regionName[0].country)
            : regionName[0].country;
        const cityName =
          typeof regionName[0].city === "object"
            ? JSON.stringify(regionName[0].city)
            : regionName[0].city;

        setCountry(countryName);
        console.log("country: " + countryName);
        setCity(cityName);
        dispatch({
          type: "SET_COUNTRY",
          country: countryName,
        });
        dispatch({
          type: "SET_CITY",
          city: cityName,
        });
      } else {
        let { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== "granted") {
          setErrorMsg("Permission to access location was denied");
          return;
        }
        let location = await Location.getCurrentPositionAsync({});
        if (location.coords) {
          let { longitude, latitude } = location.coords;
          let regionName = await Location.reverseGeocodeAsync({
            longitude,
            latitude,
          });
          const countryName =
            typeof regionName[0].country === "object"
              ? JSON.stringify(regionName[0].country)
              : regionName[0].country;
          const cityName =
            typeof regionName[0].city === "object"
              ? JSON.stringify(regionName[0].city)
              : regionName[0].city;

          setCountry(countryName);
          setCity(cityName);
          dispatch({
            type: "SET_COUNTRY",
            country: countryName,
          });
          dispatch({
            type: "SET_CITY",
            city: cityName,
          });
        }
      }
    } catch (err) {
      console.log(err);
      dispatch({
        type: "SET_COUNTRY",
        country: " ",
      });
      setCountry(" ");
      dispatch({
        type: "SET_CITY",
        city: " ",
      });
    }
  };

  const handleLoadTopCategories = () => {
    CacheStore.get("categories").then((data) => {
      if (data === null) {
        _getCategories();
      } else {
        const arr = [...data];
        const remove = [352, 278, 338, 498, 353];
        // for (let i = 0; i < arr.length; i++) {
        //     for (let j = 0; j < remove.length; j++) {
        //         if (arr[i].term_id === remove[j]) {
        //             arr.splice(i, 1);
        //         }
        //     }
        // }
        if (arr.length > 0) {
          if (arr[0]?.term_id == 498) {
            setParentId(arr[0]?.directory_id);
          } else if (arr[0]?.term_id == 353) {
            setParentId(arr[0].directory_id);
          } else {
            setParentId(arr[0]?.term_id);
          }
        }
        setTopCategoriesData(arr);
        dispatch({
          type: "SET_CATEGORIES_DATA",
          categories_data: data,
        });
      }
    });
  };

  const handleSelectCategory = (item, index) => {
    setActiveSlide(index);

    // if (item.term_id === 498) {
    //     setParentId(item.directory_id)

    // } else if (item.term_id === 353) {
    //     setParentId(item.directory_id)

    // } else {
    //     setParentId(item.term_id)

    // }
    if (item.term_id === 498) {
      navigation.navigate("BusinessProfessional", {
        directory_id: 498,
        country: country,
        city: city,
      });
      return false;
    } else if (item.term_id === 353) {
      navigation.navigate("BusinessProfessional", {
        directory_id: 353,
        country: country,
        city: city,
      });
      return false;
    } else {
      navigation.navigate("CategoriesListings", {
        parent_id: item.term_id,
        country: country,
        city: city,
      });
      return false;
    }
  };

  const handleLoadPremiumAds = (country) => {
    // alert(country)
    api.get("premium-ads?country=" + country).then((res) => {
      if (res.ok) {
        console.log("ads", res.data);
        // alert(JSON.stringify(res.data))
        dispatch({
          type: "SET_PREMIUM_ADS",
          premium_ads: res.data,
        });
      } else {
        console.log("errors now");
      }
    });
  };

  const Category = ({ onPress, item, index, colors, drkColors }) => (
    <TouchableOpacity
      onPress={() => onPress(item)}
      style={{
        alignItems: "center",
        padding: 5,
        marginTop: 15,
      }}
    >
      {/* <View
                style={{
                    justifyContent: "center",
                    alignItems: "center",
                }}
            >
                <View
                    style={{
                        backgroundColor: "#FFFFFF66",
                        padding: 5,
                        borderRadius: 50,
                        shadowColor: '#a9a9a9',
                        shadowOffset: {
                            width: 0,
                            height: 12,
                        },
                        shadowOpacity: 0.58,
                        shadowRadius: 16.00,
                        elevation: 24,
                    }}
                >
                    <View
                        style={{
                            backgroundColor: "#FFFFFF",
                            padding: 15,
                            borderRadius: 50,
                        }}
                    >
                        {item?.icon?.url ? (
                            <CategoryImage size={35} uri={item.icon.url} />
                        ) : (
                            <CategoryIcon
                                iconName={item.icon.class}
                                iconSize={35}
                                iconColor={COLORS.primary}
                            />
                        )}
                    </View>
                </View>
                <Text
                    style={{
                        marginTop: 5,
                        color: COLORS.black,
                        fontSize: 11,
                        textAlign: "center",
                        fontFamily: "Poppins Bold"
                    }}
                >
                    {decodeString(item.name) === "Skilled Professionals" ? "Skilled \n Professionals" : decodeString(item.name)}
                </Text>
            </View> */}
      <View
        style={{
          backgroundColor: colors[index % colors.length],
          width: (screenWidth * 0.985 - 10) / 3.2,
          height: 170,
          borderRadius: 10,
        }}
      >
        <View
          style={{
            flex: 2,
            backgroundColor: colors[index % colors.length],
            justifyContent: "flex-start",
            paddingTop: 15,
            borderTopLeftRadius: 10,
            borderTopRightRadius: 10,
            alignItems: "center",
          }}
        >
          {item?.icon?.url ? (
            <CategoryImage size={70} uri={item.icon.url} />
          ) : (
            <CategoryIcon
              iconName={item.icon.class}
              iconSize={70}
              iconColor={COLORS.primary}
            />
          )}
        </View>
        <View
          style={{
            flex: 1.2,
            paddingHorizontal: "4%",
            borderBottomLeftRadius: 10,
            borderBottomRightRadius: 10,
            backgroundColor: drkColors[index % drkColors.length],
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Text
            numberOfLines={2}
            style={{
              width: "95%",
              marginTop: 5,
              color: COLORS.white,
              fontSize: 11,
              textAlign: "center",
              fontFamily: "Poppins Bold",
            }}
          >
            {decodeString(item.name) === "Skilled Professionals"
              ? "Skilled \n Professionals"
              : decodeString(item.name)}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  const keyExtractor = useCallback((item, index) => `${index}`, []);

  const renderFeaturedItem = useCallback(
    ({ item }) => (
      <View style={{ paddingBottom: 10 }}>
        <ListingCard
          onPress={() =>
            navigation.navigate(routes.listingDetailScreen, {
              listingId: item.listing_id,
            })
          }
          data={item}
        />
      </View>
    ),
    [refreshing, config]
  );

  const handleSearch = (values) => {
    Keyboard.dismiss();
    navigation.navigate(routes.searchScreen, { searchData: values.search });
  };

  const handleReset = () => {
    // setSearchData({
    //   categories: "",
    //   locations: "",
    //   onScroll: false,
    //   page: 1,
    //   per_page: offset,
    //   search: "",
    // });
    setSearchData((prevSearchData) => {
      return {
        ...prevSearchData,
        page: 1,
        onScroll: false,
        per_page: offset,
      };
    });
    setMoreLoading(false);
    setPagination({});
    setLoading(true);
    _getListingData();
  };

  const navigationView = () => (
    <View style={[styles.container]}>
      <DrawerMenu close={() => drawer.current.closeDrawer()} />
    </View>
  );

  const renderTopCategories = () => {
    let slidesData = [];
    var colors = ["#9074F8", "#FBC610", "#FE75F6", "#3AC8FF", "#41E2A0"];
    var drkColors = ["#7A4BFE", "#FEA11B", "#F72FB1", "#19A9FF", "#43E170"];
    if (topCategoriesData.length < 9) {
      slidesData = [...slidesData, topCategoriesData];
    } else {
      for (let i = 0; i < topCategoriesData.length; ) {
        var slides = [];
        for (let j = 0; j < 9; j += 1) {
          slides = [...slides, topCategoriesData[i]];
          i += 1;
          if (i === topCategoriesData.length) break;
        }
        slidesData = [...slidesData, slides];
      }
    }

    return (
      <>
        <FlatList
          data={topCategoriesData}
          keyExtractor={keyExtractor}
          renderItem={({ item, index }) => {
            return (
              <View>
                <Category
                  onPress={() => {
                    console.log(index);
                    handleSelectCategory(item, index);
                  }}
                  key={index}
                  colors={colors}
                  drkColors={drkColors}
                  index={index}
                  item={item}
                />
              </View>
            );
          }}
          horizontal
          showsHorizontalScrollIndicator={false}
        />
        {/*<Carousel*/}
        {/*    layout={'default'}*/}
        {/*    layoutCardOffset={18}*/}
        {/*    firstItem={activeCategorySlide}*/}
        {/*    data={topCategoriesData}*/}
        {/*    sliderWidth={screenWidth}*/}
        {/*    itemWidth={(screenWidth * 0.985 - 10) / 3}*/}
        {/*    // loop={true}*/}
        {/*    activeAnimationType='spring'*/}
        {/*    style={{justifyContent: 'flex-start', backgroundColor: 'white'}}*/}
        {/*    renderItem={({item, index}) => {*/}
        {/*        return (*/}
        {/*            <View>*/}
        {/*                <Category onPress={() => {*/}
        {/*                    console.log(index)*/}
        {/*                    handleSelectCategory(item, index)*/}
        {/*                }} key={index} colors={colors}*/}
        {/*                          drkColors={drkColors} index={index} item={item}/>*/}
        {/*            </View>*/}
        {/*        )*/}
        {/*    }}*/}
        {/*    // activeSlideOffset={0}*/}
        {/*    activeSlideAlignment='start'*/}
        {/*    pagingEnabled={false}*/}
        {/*    inactiveSlideScale={1}*/}
        {/*    onSnapToItem={index => {*/}
        {/*        console.log(index)*/}
        {/*        // handleSelectCategory(topCategoriesData[index])*/}
        {/*        setActiveSlide(index)*/}
        {/*    }}*/}

        {/*/>*/}
      </>
    );
  };

  const featuredListFooter = () => {
    if (
      pagination &&
      pagination.total_pages > pagination.current_page &&
      moreLoading
    ) {
      return (
        <View style={styles.loadMoreWrap}>
          <ActivityIndicator size="small" color={COLORS.primary} />
        </View>
      );
    } else {
      return null;
    }
  };

  const isCloseToBottom = ({
    layoutMeasurement,
    contentOffset,
    contentSize,
  }) => {
    return (
      layoutMeasurement.height + contentOffset.y >= contentSize.height - 20
    );
  };

  return (
    <DrawerLayout
      ref={drawer}
      drawerWidth={380}
      drawerPosition={drawerPosition}
      renderNavigationView={navigationView}
      drawerBackgroundColor={"#ffffff"}
    >
      <View style={styles.container}>
        <TabScreenHeader
          drawer
          user={user}
          right={!user}
          showDrawer={() => drawer.current.openDrawer()}
          style={{ elevation: 0, zIndex: 2 }}
        />
        {/* Loading Animation */}
        {loading ? (
          <View style={styles.loading}>
            <ActivityIndicator size="large" color={COLORS.primary} />
            <Text style={styles.text}>
              {__("homeScreenTexts.loadingMessage", appSettings.lng)}
            </Text>
          </View>
        ) : (
          <ScrollView
            refreshing={false}
            showsVerticalScrollIndicator={false}
            style={{ backgroundColor: "#fff" }}
            onScroll={({ nativeEvent }) => {
              if (isCloseToBottom(nativeEvent)) {
                console.log("Close to bottom");
                handleNextPageLoading();
              }
            }}
            scrollEventThrottle={1}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={handleReset} />
            }
          >
            <View>
              <View style={styles.imageSearchContainer}>
                <View style={[[{ backgroundColor: "white" }]]}>
                  <PremiumAds admob={false} />
                  <View
                    style={{ position: "absolute", left: 0, right: 0, top: 20 }}
                  >
                    <View style={styles.listingTop}>
                      <Formik
                        initialValues={{ search: "" }}
                        onSubmit={handleSearch}
                      >
                        {({
                          handleChange,
                          handleBlur,
                          handleSubmit,
                          values,
                        }) => (
                          <View style={styles.ListingSearchContainer}>
                            <TextInput
                              style={styles.searchInput}
                              placeholder={
                                searchData.search ||
                                __(
                                  "homeScreenTexts.listingSearchPlaceholder",
                                  appSettings.lng
                                )
                              }
                              placeholderTextColor={COLORS.textGray}
                              onChangeText={handleChange("search")}
                              onBlur={() => {
                                handleBlur("search");
                              }}
                              value={values.search}
                              returnKeyType="search"
                              onSubmitEditing={handleSubmit}
                            />

                            <TouchableOpacity
                              onPress={() =>
                                navigation.navigate(routes.searchScreen, {
                                  searchData: values.search,
                                })
                              }
                              disabled={
                                !values.search || timedOut || networkError
                              }
                              style={styles.listingSearchBtnContainer}
                            >
                              {/* <Feather
                                                            name="search"
                                                            size={20}
                                                            color={values.search ? COLORS.white : COLORS.white}
                                                        /> */}
                              <Text style={{ color: "#fff" }}>Search</Text>
                            </TouchableOpacity>
                          </View>
                        )}
                      </Formik>
                    </View>
                  </View>
                </View>
              </View>
              {/* FlatList */}
              <View
                style={{ backgroundColor: "#fff", alignItems: "flex-start" }}
              >
                {!!listingsData.length && (
                  <>
                    <View style={{ paddingHorizontal: screenWidth * 0.015 }}>
                      {/* <View
                                        style={{
                                            flexDirection: "row",
                                            flex: 1,
                                            // flexWrap: "wrap",
                                            justifyContent: 'center',
                                            alignItems: 'center',
                                        }}
                                    >
                                    {/* <HorizontalTiles arr={topCategoriesData}/> */}
                      {/* <ScrollView horizontal>
                                        {
                                            topCategoriesData.map((item, index) => (                                                
                                                    <Category onPress={handleSelectCategory} key = {index} item={item}/>                                            
                                                ))
                                        }        
                                        </ScrollView>                                 
                                    </View> */}

                      <View
                        style={{
                          paddingHorizontal: 10,
                          paddingTop: 15,
                          // alignItems: "center"
                        }}
                      >
                        <Text
                          style={{
                            fontSize: 20,
                            fontFamily: "Poppins Bold",
                            color: COLORS.headingsColor,
                            letterSpacing: 1,
                            lineHeight: 33,
                          }}
                        >
                          Categories
                        </Text>
                      </View>

                      {renderTopCategories()}
                      {/* <CategoriesListings parentId={parentId}
                                            getListData={(data) => { console.log(data) }}
                                            getOtherData={(data) => { console.log(data) }}
                                            route={{
                                                params: {
                                                    parent_id: parentId
                                                }
                                            }} /> */}
                      {/* <>
                                            <FlatList
                                                data={topCategoriesData}
                                                renderItem={renderCategory}
                                                keyExtractor={keyExtractor}
                                                horizontal={false}
                                                key={4}
                                                numColumns={3}
                                                contentContainerStyle={{
                                                    paddingHorizontal: 10,
                                                    paddingVertical: 20,
                                                    alignItems: "center",
                                                    backgroundColor: "#ffffff"
                                                }}
                                                bounces={false}
                                                scrollEnabled={false}
                                                showsHorizontalScrollIndicator={false}
                                            />
                                        </> */}

                      {!!videoListingsData.length && (
                        <View style={{ flex: 1, top: -130 }}>
                          <View
                            style={{
                              paddingHorizontal: 10,
                              // alignItems: "center"
                            }}
                          >
                            <Text
                              style={{
                                fontSize: 20,
                                fontFamily: "Poppins Bold",
                                color: COLORS.headingsColor,
                                letterSpacing: 1,
                                lineHeight: 33,
                              }}
                            >
                              Featured
                            </Text>
                          </View>

                          <SwiperFlatList
                            ref={ref}
                            data={videoListingsData}
                            style={{ flex: 1 }}
                            renderItem={renderFeaturedItem}
                            keyExtractor={keyExtractor}
                            horizontal
                            legacyImplementation={false}
                            showsHorizontalScrollIndicator={false}
                            bounces={false}
                            contentContainerStyle={{
                              justifyContent: "center",
                              paddingTop: 20,
                            }}
                            autoplay
                            autoplayDelay={3}
                            autoplayLoop
                          />
                        </View>
                      )}

                      {/* {!!featuredListingsData.length && (
                                            <View style={{ flex: 1 }}>
                                                <View style={{
                                                    paddingHorizontal: 10,
                                                    // alignItems: "center"
                                                }}>
                                                    <Text
                                                        style={{
                                                            fontSize: 20,
                                                            fontFamily: "Poppins Bold",
                                                            color: COLORS.headingsColor,
                                                            letterSpacing: 1,
                                                            lineHeight: 33,
                                                        }}
                                                    >Featured</Text>
                                                </View>

                                                <SwiperFlatList
                                                    ref={ref}
                                                    data={featuredListingsData}
                                                    style={{ flex: 1 }}
                                                    renderItem={renderFeaturedItem}
                                                    keyExtractor={keyExtractor}
                                                    horizontal
                                                    legacyImplementation={false}
                                                    showsHorizontalScrollIndicator={false}
                                                    bounces={false}
                                                    contentContainerStyle={{
                                                        justifyContent: 'center',
                                                        paddingTop: 20,
                                                    }}
                                                    autoplay
                                                    autoplayDelay={3}
                                                    autoplayLoop
                                                />
                                            </View>
                                        )} */}

                      <View style={{ flex: 1, top: -300 }}>
                        <View
                          style={{
                            paddingHorizontal: 10,
                            // alignItems: "center",
                          }}
                        >
                          <Text
                            style={{
                              fontSize: 20,
                              fontFamily: "Poppins Bold",
                              color: COLORS.headingsColor,
                              letterSpacing: 1,
                              lineHeight: 33,
                            }}
                          >
                            Latest
                          </Text>
                        </View>
                        <View
                          style={{
                            flexDirection: "row",
                            flexWrap: "wrap",
                            marginBottom:
                              listingsData.slice(0, offset).length > 20
                                ? 250
                                : 200,
                          }}
                        >
                          {/* {
                                                    listingsData.slice(0, offset).map((item, index) => (
                                                        <View style={{ flexDirection: 'column' }}>
                                                            <View key={item.listing_id} style={{
                                                                paddingBottom: 10,
                                                                width: (screenWidth * 0.985 - 10) / 2,
                                                                paddingLeft: 5
                                                            }}>
                                                                <ListingCard
                                                                    onPress={() =>
                                                                        navigation.navigate(routes.listingDetailScreen, {
                                                                            listingId: item.listing_id,
                                                                        })
                                                                    }
                                                                    data={item}
                                                                    key={item.listing_id}
                                                                />
                                                                <View />
                                                            </View>
                                                            {index % 20 == 19 && <View style={{
                                                                alignItems: 'center', 
                                                                left: -((screenWidth * 0.985 - 10) / 2.1),height:280,
                                                                
                                                            }}>
                                                                <PremiumAds admob={true}/>
                                                            </View>}
                                                        </View>
                                                    ))
                                                } */}
                          <Animated.FlatList
                            data={listingsData}
                            style={{ flex: 1 }}
                            // onEndReached={handleNextPageLoading}
                            onEndReachedThreshold={0.1}
                            maxToRenderPerBatch={7}
                            windowSize={41}
                            ListFooterComponent={featuredListFooter}
                            nestedScrollEnabled={true}
                            bounces={false}
                            keyExtractor={keyExtractor}
                            renderItem={({ item, index }) => {
                              return (
                                <View style={{ flexDirection: "column" }}>
                                  <ListingCard
                                    onPress={() =>
                                      navigation.navigate(
                                        routes.listingDetailScreen,
                                        {
                                          listingId: item.listing_id,
                                        }
                                      )
                                    }
                                    data={item}
                                    key={item.listing_id}
                                  />

                                  {index % 20 == 19 && (
                                    // {item.listAd && (
                                    <View
                                      style={{
                                        alignItems: "center",
                                        left: -(
                                          (screenWidth * 0.985 - 10) /
                                          2.1
                                        ),
                                        minHeight: 100,
                                      }}
                                    >
                                      <PremiumAds admob={true} />
                                    </View>
                                  )}
                                </View>
                              );
                            }}
                            pagingEnabled
                            numColumns={2}
                            showsHorizontalScrollIndicator={false}
                            contentContainerStyle={{
                              paddingVertical: 20,
                              // backgroundColor: COLORS.red
                            }}
                          />
                        </View>

                        {/* commented out because we will load alla data here */}
                        {/* {
                          // (listingsData.length >= 20 && listingsData.length >= offset) && (
                          listingsData.length >= offset && (
                            <View
                              style={{
                                flex: 1,
                                marginBottom: 250,
                              }}
                            >
                              <TouchableOpacity
                                style={{ justifyContent: "flex-end" }}
                                onPress={() =>
                                  navigation.navigate("All Listings Screen", {
                                    parent_id: "all",
                                  })
                                }
                                // onPress={() => {
                                //     setOffset(offset + 20)
                                // }}
                              >
                                <Text
                                  style={{
                                    fontFamily: "Poppins Bold",
                                    color: COLORS.primary,
                                    textAlign: "right",
                                    paddingRight: 15,
                                  }}
                                >
                                  See All
                                </Text>
                              </TouchableOpacity>
                            </View>
                          )
                        } */}
                      </View>
                    </View>
                  </>
                )}
                {/* No Listing Found */}
                {/* Timeout & Network Error notice */}
                {!listingsData.length && !timedOut && !networkError && (
                  <View style={styles.noListingsWrap}>
                    <Fontisto
                      name="frowning"
                      size={100}
                      color={COLORS.primary_soft}
                    />
                    <Text style={styles.noListingsMessage}>
                      {/* eslint-disable-next-line react/no-unescaped-entities */}
                      Sorry... No listings found!
                    </Text>
                    <Text style={{ color: COLORS.primary }}>
                      Scroll to view all listings
                    </Text>
                    <Feather
                      name="chevrons-down"
                      size={24}
                      color={COLORS.primary}
                    />
                  </View>
                )}
              </View>

              {/* No Listing Found */}
              {/* Flash notification */}
              <FlashNotification
                falshShow={flashNotification}
                flashMessage="Hello World!"
              />
            </View>
          </ScrollView>
        )}
      </View>
    </DrawerLayout>
  );
};

const styles = StyleSheet.create({
  categoriesRowWrap: {},
  container: {
    flex: 1,
    backgroundColor: "#f1f1f1",
  },
  item: {
    backgroundColor: "#f9c2ff",
    padding: 20,
    marginVertical: 8,
  },
  header: {
    fontSize: 32,
    backgroundColor: "#fff",
  },
  title: {
    fontSize: 24,
  },
  featuredListingTop: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: screenWidth * 0.015,
    paddingBottom: 15,
    paddingTop: 5,
    backgroundColor: "#fafafa",
  },
  itemSeparator: {
    height: "100%",
    width: 1.333,
    backgroundColor: COLORS.bg_dark,
  },
  listingSearchBtnContainer: {
    marginLeft: 5,
    marginRight: -10,
    backgroundColor: COLORS.primary,
    borderRadius: 5,
    padding: 8,
  },
  ListingSearchContainer: {
    flex: 1,
    height: 45,
    marginHorizontal: 10,
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderRadius: 4,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 15,
    elevation: 7,
    zIndex: 20,
    shadowColor: "#000",
    shadowRadius: 4,
    shadowOpacity: 0.2,
    shadowOffset: {
      height: -4,
      width: 2,
    },
  },
  imageSearchContainer: {
    paddingTop: 0,
    paddingHorizontal: 10,
    height: 250,
    width: "100%",
    backgroundColor: "#fff",
    // transform: [{ scaleX: 2 }],
    overflow: "hidden",
  },
  child: {
    // top: -40,
    flex: 1,
    // transform: [{ scaleX: 0.5 }],
    alignItems: "center",
    justifyContent: "center",
    zIndex: 22,
  },
  listingTop: {
    width: "100%",
    // paddingTop: 100,
    zIndex: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: screenWidth * 0.03,
    paddingBottom: 10,
  },
  locationWrap: {
    maxWidth: screenWidth * 0.25,
    marginHorizontal: screenWidth * 0.015,
    backgroundColor: COLORS.white,
    borderRadius: 5,
    padding: 7,
  },
  locationContent: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%",
  },
  locationContentText: {
    paddingHorizontal: 5,
    color: COLORS.text_gray,
  },
  loadMoreWrap: {
    marginBottom: 10,
  },
  loading: {
    justifyContent: "center",
    alignItems: "center",
    height: screenHeight - 120,
  },
  noListingsMessage: {
    fontSize: 18,
    color: COLORS.text_gray,
    marginVertical: 10,
    marginHorizontal: 20,
    textAlign: "center",
  },
  noListingsWrap: {
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    paddingTop: 100,
  },
  resetButton: {
    borderRadius: 5,
    borderWidth: 1,
    borderColor: COLORS.orange,
    paddingVertical: 6,
    paddingHorizontal: 12,
    marginHorizontal: screenWidth * 0.015,
  },
  retryButton: {
    width: "30%",
    alignItems: "center",
    justifyContent: "center",
  },
  searchInput: {
    flex: 1,
    fontFamily: "Poppins Regular",
  },
  selectedCat: {
    fontSize: 12,
  },
  topCatSliderWrap: {
    position: "absolute",
    top: 244,
    paddingTop: 10,
    justifyContent: "center",
    backgroundColor: "#fafafa",
  },
  logo: {
    height: screenWidth * 0.3,
    width: screenWidth * 0.35,
    resizeMode: "cover",
  },
  logoWrap: {
    height: screenWidth * 0.3,
    width: screenWidth * 0.35,
    overflow: "hidden",
    borderRadius: 10,
    marginBottom: 5,
    alignSelf: "center",
  },
  storeCardListingCount: {
    fontSize: 13,
    color: COLORS.primary,
    fontFamily: "Poppins Bold",
  },
  storeCardListingCountWrap: {
    backgroundColor: COLORS.primary_soft,
    paddingVertical: 5,
    paddingHorizontal: 10,
    color: COLORS.primary,
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
    alignItems: "center",
  },
  storeCardTitle: {
    fontFamily: "Poppins Bold",
    fontSize: 14,
  },
  storeContent: {
    height: screenWidth * 0.5,
    width: screenWidth * 0.455,
    backgroundColor: COLORS.white,
    paddingTop: 5,
    elevation: 3,
    borderRadius: 10,
    marginHorizontal: screenWidth * 0.01,
    zIndex: 999,
    overflow: "visible",
    shadowColor: "#000",
    shadowRadius: 4,
    shadowOpacity: 0.2,
    shadowOffset: {
      height: 2,
      width: 2,
    },
  },
  storeWrap: {
    marginHorizontal: 2,
    shadowColor: "#1B31420D",
    shadowRadius: 4,
    shadowOpacity: 0.2,
    shadowOffset: {
      height: 2,
      width: 2,
    },
    marginBottom: 30,
  },
  indicator: {
    height: 8,
    width: 50,
    backgroundColor: COLORS.gray,
    marginHorizontal: 5,
    borderRadius: 50,
  },
  pagination: {
    flexDirection: "row",
    marginBottom: 30,
    justifyContent: "center",
    backgroundColor: "#ffffff",
  },
  catItem: {
    flexDirection: "column",
  },
});

export default HomeScreen;
