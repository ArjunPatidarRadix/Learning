import React, {useState, useEffect, useRef} from "react";
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    Dimensions, TextInput, TouchableOpacity, ActivityIndicator, Image, TouchableWithoutFeedback, Modal, Linking,
} from "react-native";
import DrawerLayout from 'react-native-gesture-handler/DrawerLayout';

// Custom Components & Variables
import {COLORS} from "../variables/color";
import {useStateValue} from "../StateProvider";
import PremiumAds from "../components/PremiumAds";
import TabScreenHeader from "../components/TabScreenHeader";
import AccountScreen from "./AccountScreen";
import {Formik} from "formik";
import {__} from "../language/stringPicker";
import {Feather, FontAwesome5} from "@expo/vector-icons";
import {decodeString} from "../helper/helper";
import api, {removeAuthToken, setAuthToken} from "../api/client";
import listingCardFallbackImageUrl from "../assets/100x100.png";
import AppTextButton from "../components/AppTextButton";
import {ReactNativeZoomableView} from "@dudigital/react-native-zoomable-view";

const {width: windowWidth, height: windowHeight} = Dimensions.get("window");


const {width: screenWidth, height: screenHeight} = Dimensions.get("screen");

const BusinessProfileScreen = ({route, navigation}) => {
    const [{ios, auth_token, appSettings, rtl_support}] = useStateValue();
    const [loading, setLoading] = useState(true);
    const [imageViewer, setImageViewer] = useState(false);
    const [data, setData] = useState([]);
    const [socials, setSocials] = useState([]);
    const [modalVisible, setModalVisible] = useState(false);
    const [value, setValue] = useState(0);
    const [date, setDate] = useState("0");
    const [currentSlide, setCurrentSlide] = useState(0);
    const [viewingImage, setViewingImage] = useState()

    useEffect(() => {
        const focused = navigation.addListener('focus', () => {
            setData([])
            setValue(0)
            setLoading(true);
            setAuthToken(auth_token);
            api.get(`listings/${route.params.business_id}`).then((res) => {
                if (res.ok) {
                    const array = res.data;
                    console.log(res.data)
                    setData(array)
                    setDate(array.created_at.substr(0, 4))
                    setLoading(false)
                    const myArray = []
                    for (let i = 0; i < array.custom_fields.length; i++) {
                        if (array.custom_fields[i].slug === 'facebook' ||
                            array.custom_fields[i].slug === 'linkedin' ||
                            array.custom_fields[i].slug === 'instagram' ||
                            array.custom_fields[i].slug === 'twitter') {
                            myArray.push(array.custom_fields[i])
                        }
                    }
                    setSocials(myArray)
                    removeAuthToken();
                } else {
                    setData([]);
                }
            })
        });

        return focused;
    }, [navigation]);

    const handleCall = (number) => {
        setModalVisible(false);
        let phoneNumber = "";
        if (ios) {
            phoneNumber = `telprompt:${number}`;
        } else {
            phoneNumber = `tel:${number}`;
        }
        Linking.openURL(phoneNumber);
    };
    const handleScroll = (e) => {
        // if (playing) {
        //     setPlaying(false);
        // }
        setCurrentSlide(Math.round(e.nativeEvent.contentOffset.x / windowWidth));
    };

    const getTotalSlideCount = () => {
        if (!data?.video_urls?.length) {
            return data.images.length;
        }
        if (!data?.images?.length) {
            return data.video_urls.length;
        }
        return data.images.length + data.video_urls.length;
    };

    const handleImageZoomView = (image) => {
        setViewingImage(image);
        setTimeout(() => {
            setImageViewer(true);
        }, 20);
    };

    const handleImageViewerClose = () => {
        setImageViewer((prevImageViewer) => false);
    };


    return (
        <View style={styles.container}>
            <TabScreenHeader
                left
                onLeftClick={() => navigation.goBack()}
                style={{elevation: 0, zIndex: 2}}/>
            {/* Loading Animation */}
            <ScrollView showsHorizontalScrollIndicator={false}>
                <View style={styles.imageSearchContainer}>
                    <View style={styles.child}>
                        <PremiumAds admob={false}/>
                        <View style={{position: 'absolute', left: 0, right: 0, top: 20,}}>
                            <View style={styles.listingTop}>
                                <Formik initialValues={{search: ""}}>
                                    <View style={styles.ListingSearchContainer}>
                                        <TextInput
                                            style={styles.searchInput}
                                            placeholder={
                                                __(
                                                    "homeScreenTexts.listingSearchPlaceholder",
                                                    appSettings.lng
                                                )
                                            }
                                            placeholderTextColor={COLORS.text_gray}
                                            returnKeyType="search"
                                        />

                                        <TouchableOpacity
                                            style={styles.listingSearchBtnContainer}
                                        >
                                            <Feather
                                                name="search"
                                                size={20}
                                                color={COLORS.white}
                                            />
                                        </TouchableOpacity>
                                    </View>
                                </Formik>
                            </View>
                        </View>
                    </View>
                </View>
                {loading ? (
                    <View style={styles.loading}>
                        <ActivityIndicator size="large" color={COLORS.primary}/>
                    </View>
                ) : (
                    <View style={{marginHorizontal: 15}}>
                        <View style={styles.card}>
                            <View style={{flexDirection: "row", marginTop: 10}}>
                                <View>
                                    <Image
                                        style={{height: 90, width: 90}}
                                        source={
                                            data?.images?.length
                                                ? {
                                                    uri: data.images[0].sizes.thumbnail.src,
                                                }
                                                : listingCardFallbackImageUrl
                                        }
                                    />
                                </View>
                                <View style={{marginLeft: 10, justifyContent: "center", flex: 1}}>
                                    <Text style={{
                                        fontFamily: "Poppins Bold",
                                        marginRight: 20,
                                    }}>{data.title ? decodeString(data.title) : "No Title"} - {data.categories[0].name}</Text>

                                    <View style={{
                                        flexDirection: "row",
                                    }}>
                                        <View style={{
                                            backgroundColor: COLORS.inputCommon,
                                            paddingVertical: 10,
                                            paddingLeft: 10,
                                            borderTopLeftRadius: 5,
                                            borderBottomLeftRadius: 5
                                        }}>
                                            <FontAwesome5 name="map-marker-alt" color={COLORS.primary} size={15}/>
                                        </View>
                                        <View style={{
                                            backgroundColor: COLORS.inputCommon,
                                            paddingVertical: 10,
                                            paddingRight: 10,
                                            borderTopRightRadius: 5,
                                            borderBottomRightRadius: 5
                                        }}>
                                            <Text style={{
                                                fontFamily: "Poppins Regular",
                                                marginLeft: 10,
                                                fontSize: 15,
                                            }}>{data.contact.locations.length> 0 ? decodeString(data.contact.locations[1].name) : "No address"}</Text>
                                        </View>
                                    </View>
                                    <View style={{flexDirection: "row", alignItems: "center"}}>
                                        <FontAwesome5 name="user-check" color={COLORS.primary}/>
                                        <Text style={{fontFamily: "Poppins Regular", marginLeft: 5}}>Member
                                            since {date}</Text>
                                    </View>
                                </View>
                            </View>

                            {/* Call, Message, More Details */}
                            <View style={styles.storeDetatilBottomWrap}>
                                <View
                                    style={[styles.storeContactWrap,]}
                                >
                                    {!!data.custom_fields.filter(object => object.meta_key === "_field_6869") && (
                                        <TouchableOpacity
                                            style={[
                                                styles.busServContactButton,
                                                {backgroundColor: COLORS.inputCommon},
                                            ]}
                                            onPress={() => {
                                                if (value === 0) {
                                                    setValue(1);
                                                } else if (value === 1 || value === 2) {
                                                    setValue(2);
                                                    setModalVisible(true)
                                                }
                                            }}
                                        >
                                            <FontAwesome5 name="phone" size={18}
                                                          color={COLORS.primary}/>
                                            <Text
                                                style={[
                                                    styles.busServContactButtonText,
                                                    {color: COLORS.black},
                                                ]}
                                            >
                                                {value === 0 ? "Show phone number" : !!data.custom_fields.filter(object => object.meta_key === "_field_8375")[0].value?data.custom_fields.filter(object => object.meta_key === "_field_8375")[0].value:""}
                                            </Text>
                                        </TouchableOpacity>
                                    )}
                                    {!!data.custom_fields[4].value && (
                                        <View
                                            style={[
                                                styles.busServContactButton1,
                                                {backgroundColor: COLORS.inputCommon},
                                            ]}
                                        >
                                            <FontAwesome5 name="envelope" size={18}
                                                          color={COLORS.primary}/>
                                            <Text
                                                style={[
                                                    styles.busServContactButtonText,
                                                    {color: COLORS.black},
                                                ]}
                                            >
                                                {data.custom_fields[4].value}
                                            </Text>
                                        </View>
                                    )}

                                </View>
                            </View>
                            {/* Call, Message, More Details */}

                        </View>

                        <View style={[styles.card, {marginTop: 15, paddingVertical: 20}]}>

                            {/*about business or professional*/}
                            <>
                                <Text style={{fontFamily: "Poppins Bold", fontSize: 16}}>About {data.title}</Text>
                                <Text style={{
                                    fontFamily: "Poppins Regular",
                                    fontSize: 14,
                                    paddingHorizontal: 10,
                                    paddingVertical: 5
                                }}>{data.description !== "" ? data.description : "----"}</Text>
                            </>
                            {/*about business or professional*/}
                        </View>
                        <View style={[styles.card, {marginTop: 15, paddingVertical: 20}]}>
                            {/*social media*/}
                            <>
                                <Text style={{fontFamily: "Poppins Bold", fontSize: 16}}>Socials</Text>
                                <View style={{flexDirection: "row", justifyContent: "center"}}>
                                    {socials.map((item, index) => (
                                        <>
                                            <TouchableOpacity
                                                onPress={() => {
                                                    let url = item.value
                                                    const PREFIX = "www.";
                                                    if (url.startsWith(PREFIX)) {
                                                        // PREFIX is exactly at the beginning
                                                        url = url.replace(PREFIX, "https://")
                                                    }
                                                    Linking.openURL(url)
                                                }}
                                                style={{
                                                    backgroundColor: item.slug === "twitter" ? "#00acee" :
                                                        item.slug === "linkedin" ? "#0e76a8" :
                                                            item.slug === "facebook" ? "#3b5998" : "#fff",
                                                    // paddingHorizontal: 20,
                                                    paddingVertical: item.slug === "instagram" ? 0 : 15,
                                                    borderRadius: 100,
                                                    marginRight: 5,
                                                    height: 50,
                                                    width: 50,
                                                    alignItems: "center"
                                                }} key={index}>
                                                {item.slug === "instagram" ? (
                                                    <Image source={require("../assets/instagram_.png")}
                                                           style={{height: 50, width: 50, borderRadius: 100}}/>
                                                ) : (
                                                    <FontAwesome5
                                                        name={item.slug === "facebook" ? "facebook-f" :
                                                            item.slug === "linkedin" ? "linkedin-in" :
                                                                item.slug === "twitter" ? "twitter" : ""}
                                                        color={COLORS.white} size={20}/>
                                                )}
                                            </TouchableOpacity>
                                        </>
                                    ))
                                    }
                                </View>
                            </>
                            {/*social media*/}
                        </View>
                        <View style={[styles.card1, {marginTop: 15, paddingVertical: 20, marginHorizontal: 7}]}>
                            <Text style={{fontFamily: "Poppins Bold", fontSize: 16}}>Gallery</Text>
                            {/* Media Slider */}
                            {(!!data?.images?.length ||
                                !!data?.video_urls?.length) && (
                                <View style={styles.imageSlider}>
                                    <ScrollView
                                        horizontal
                                        pagingEnabled
                                        onScroll={handleScroll}
                                        scrollEventThrottle={16}
                                        showsHorizontalScrollIndicator={false}
                                    >
                                        {data.images.map((image) => (
                                            <TouchableWithoutFeedback
                                                key={image.ID}
                                                onPress={() => handleImageZoomView(image)}>
                                                <Image
                                                    style={{
                                                        width: windowWidth,
                                                        // height: 300,
                                                        height: windowWidth * 0.75,
                                                        resizeMode: "contain",
                                                    }}
                                                    source={{
                                                        uri: image.sizes.full.src,
                                                    }}
                                                />
                                            </TouchableWithoutFeedback>
                                        ))}
                                    </ScrollView>

                                    {(data?.images?.length > 1 ||
                                        data?.video_urls?.length > 0) && (
                                        <>
                                            {rtl_support ? (
                                                <Text style={styles.scrollProgress}>
                                                    {getTotalSlideCount()}
                                                    {" / "}
                                                    {currentSlide + 1}
                                                </Text>
                                            ) : (
                                                <Text style={styles.scrollProgress}>
                                                    {currentSlide + 1} / {getTotalSlideCount()}
                                                </Text>
                                            )}
                                        </>
                                    )}
                                </View>
                            )}

                        </View>
                        <Modal
                            animationType="slide"
                            transparent={true}
                            visible={modalVisible}
                        >
                            <TouchableWithoutFeedback onPress={() => setModalVisible(false)}>
                                <View style={styles.modalOverlay}/>
                            </TouchableWithoutFeedback>
                            {!!data.custom_fields.filter(object => object.meta_key === "_field_8375") && (
                                <View
                                    style={{
                                        flex: 1,
                                        justifyContent: "flex-end",
                                        alignItems: "center",
                                    }}
                                >
                                    <View
                                        style={{
                                            paddingHorizontal: "3%",
                                            padding: 20,
                                            backgroundColor: COLORS.white,
                                            width: "100%",
                                        }}
                                    >
                                        <Text style={styles.callText}>
                                            Call this person?
                                        </Text>
                                        <TouchableOpacity
                                            onPress={() => handleCall(data.custom_fields.filter(object => object.meta_key === "_field_8375")[0].value)}
                                            style={styles.phone}
                                        >
                                            <Text
                                                style={styles.phoneText}>{!!data.custom_fields.filter(object => object.meta_key === "_field_8375")[0] && data.custom_fields.filter(object => object.meta_key === "_field_8375")[0].value}</Text>
                                            <FontAwesome5
                                                name="phone"
                                                size={18}
                                                color={COLORS.primary}
                                            />
                                        </TouchableOpacity>
                                        {ios && (
                                            <AppTextButton
                                                title={__(
                                                    "storeDetailsTexts.cancelButtonTitle",
                                                    appSettings.lng
                                                )}
                                                textStyle={{
                                                    fontFamily: "Poppins Bold",
                                                }}
                                                style={{marginTop: 20}}
                                                onPress={() => setModalVisible(false)}
                                            />
                                        )}
                                    </View>
                                </View>
                            )}

                        </Modal>


                    </View>
                )}
            </ScrollView>
            {imageViewer && (
                <View style={styles.imageViewerWrapq}>
                    <TouchableOpacity
                        style={styles.imageViewerCloseButton}
                        onPress={handleImageViewerClose}
                    >
                        <FontAwesome5 name="times" size={24} color="black"/>
                    </TouchableOpacity>

                    <View style={styles.imageViewer}>
                        <ReactNativeZoomableView
                            maxZoom={2}
                            minZoom={1}
                            zoomStep={0.5}
                            initialZoom={1}
                            bindToBorders={true}
                            style={{
                                padding: 10,
                                backgroundColor: COLORS.black,
                            }}
                        >
                            <Image
                                style={{
                                    width: windowWidth,
                                    height: windowHeight,
                                    resizeMode: "contain",
                                }}
                                source={{
                                    uri: viewingImage.sizes.full.src,
                                }}
                            />
                        </ReactNativeZoomableView>
                    </View>
                </View>
            )}
        </View>
    )
        ;
};

const styles = StyleSheet.create({
    modalOverlay: {
        position: "absolute",
        top: 0,
        bottom: 0,
        left: 0,
        right: 0,
        backgroundColor: "rgba(0,0,0,0.2)",
    },
    card: {
        backgroundColor: COLORS.white,
        paddingHorizontal: 10,
        paddingVertical: 10,
        marginTop: 10,
        width: "96%",
        borderRadius: 20,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
        alignSelf: "center"
    },
    card1: {
        flex: 1,
        backgroundColor: COLORS.white,
        paddingHorizontal: 10,
        paddingVertical: 10,
        marginBottom: 40,
        borderRadius: 20,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
        alignSelf: "center"
    },
    busServContactButtonText: {
        fontSize: 14,
        fontWeight: "bold",
        marginLeft: 5,
    },
    busServContactButton: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 3,
        width: "100%",
        height: 50,
        marginBottom: 10,
        marginVertical: 10
    },
    busServContactButton1: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 3,
        width: "100%",
        height: 50,
        marginBottom: 10,
        marginVertical: 5
    },
    container: {
        flex: 1,
        backgroundColor: COLORS.white,
    },

    child: {
        // top: -100,
        flex: 1,
        // transform: [{scaleX: 0.5}],
        alignItems: 'center',
        justifyContent: 'center'
    },
    listingTop: {
        width: "100%",
        // paddingTop: 100,
        zIndex: 1,
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: screenWidth * 0.03,
        paddingBottom: 10,
    },
    searchInput: {
        flex: 1,
        fontFamily: "Poppins Regular"
    },
    listingSearchBtnContainer: {
        marginLeft: 5,
        marginRight: -10,
        backgroundColor: COLORS.primary,
        borderRadius: 5,
        padding: 8
    },
    ListingSearchContainer: {
        flex: 1,
        height: 45,
        marginHorizontal: 10,
        backgroundColor: COLORS.white,
        borderWidth: 1,
        borderRadius: 4,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        paddingHorizontal: 15,
        elevation: 7,
        zIndex: 20,
        shadowColor: "#000",
        shadowRadius: 4,
        shadowOpacity: 0.2,
        shadowOffset: {
            height: -4,
            width: 2,
        },
    },
    imageSearchContainer: {
        paddingTop: 0,
        paddingHorizontal: 10,

        height: 250,
        width: '100%',
        backgroundColor: "#fff",
        // transform: [{ scaleX: 2 }],
        overflow: 'hidden',
    },
    loading: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center"
    },
    phone: {
        flexDirection: "row",
        alignItems: "flex-end",
        justifyContent: "space-between",
        paddingVertical: 10,
    },
    phoneText: {
        color: COLORS.primary,
        fontWeight: "bold",
        fontSize: 18,
    },
    callText: {
        fontSize: 20,
        color: COLORS.text_dark,
        textAlign: "center",
    },
    storeTop: {
        flex: 1,
        width: "100%",
        alignItems: "center",
    },
    imageSlider: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        paddingTop: 15,
    },
    imageViewer: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
    },
    imageViewerCloseButton: {
        position: "absolute",
        right: 15,
        top: 15,
        zIndex: 10,
        height: 25,
        width: 25,
        backgroundColor: COLORS.white,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 13,
    },
    imageViewerWrap: {
        position: "absolute",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "white",
        width: "100%",
        height: "100%",
        flex: 1,
    },
    imageViewerWrapq: {
        position: "absolute",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "white",
        width: "100%",
        // height: "100%",
        zIndex: 2,
        top: 0,
        bottom: 0,
        left: 0,
        right: 0,
    },

});

export default BusinessProfileScreen;
