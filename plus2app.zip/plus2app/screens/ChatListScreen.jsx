import React, {useEffect, useState, useCallback, useRef} from "react";
import {
    View,
    Text,
    StyleSheet,
    FlatList,
    Image,
    Dimensions,
    ActivityIndicator,
    Alert,
    RefreshControl,
    TouchableWithoutFeedback, ImageBackground, TextInput, TouchableOpacity, ScrollView,
} from "react-native";

// External Libraries
import moment from "moment";

// Vector Icons
import {FontAwesome} from "@expo/vector-icons";
import {FontAwesome5} from "@expo/vector-icons";
import {Feather} from "@expo/vector-icons";

// Custom Components & Functions
import TabScreenHeader from "../components/TabScreenHeader";
import {COLORS} from "../variables/color";
import AppButton from "../components/AppButton";
import {useStateValue} from "../StateProvider";
import api, {setAuthToken, removeAuthToken} from "../api/client";
import LoadingIndicator from "../components/LoadingIndicator";
import FlashNotification from "../components/FlashNotification";
import {__} from "../language/stringPicker";
import {decodeString, stripString} from "../helper/helper";
import {routes} from "../navigation/routes";
import AccountScreen from "./AccountScreen";
import {useNavigation} from "@react-navigation/native";
import {DrawerLayout} from "react-native-gesture-handler";
import {Formik} from "formik";
import PremiumAds from "../components/PremiumAds";
import DrawerMenu from "../components/DrawerMenu";

const {height: screenHeight} = Dimensions.get("screen");

const chatListItemFallbackImageUrl = require("../assets/200X150.png");

const {width: screenWidth} = Dimensions.get("screen");
const ChatListScreen = () => {
    const drawer = useRef(null);
    const [drawerPosition] = useState("left");
    const navigation = useNavigation();
    const [
        {user, auth_token, is_connected, newListingScreen, appSettings},
        dispatch,
    ] = useStateValue();
    const [chatListData, setChatListData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [autoload, setAutoload] = useState(false);
    const [deleteLoading, setDeleteLoading] = useState(false);
    const [refreshing, setRefreshing] = useState(false);
    const [flashNotification, setFlashNotification] = useState(false);
    const [flashNotificationMessage, setFlashNotificationMessage] = useState();

    // useEffect(() => {
    //     const focused = navigation.addListener('focus', () => {
    //         setLoading(true);
    //         handleLoadConversations()
    //     });
    //     return focused;
    // }, [navigation]);

    const navigationView = () => (
        // eslint-disable-next-line no-undef
        <View style={[styles.container]}>
            <DrawerMenu close={() => drawer.current.closeDrawer()}/>
        </View>
    )

    // initial for externel event
    useEffect(() => {
        if (newListingScreen) {
            dispatch({
                type: "SET_NEW_LISTING_SCREEN",
                newListingScreen: false,
            });
        }
        dispatch({
            type: "SET_CHAT_BADGE",
            chat_badge: null,
        });
    }, []);

    // initial load conversation
    useEffect(() => {
        if (!user) return;
        handleLoadConversations();
    }, [user]);

    // refreshing load conversation
    useEffect(() => {
        if (!refreshing) return;
        handleLoadConversations();
    }, [refreshing]);
    const handleLoadConversations = () => {
        if (autoload) return;
        setAutoload(true);
        setAuthToken(auth_token);
        api.get("my/chat").then((res) => {
            if (res.ok) {
                setChatListData((chatListData) => res.data);
                removeAuthToken();
                setLoading(false);
                setAutoload(false);
                if (refreshing) {
                    setRefreshing(false);
                }
            } else {
                //TODO print error
                removeAuthToken();
                setLoading(false);
                setAutoload(false);
                setRefreshing(false);
            }
        });
    };
    const handleDeleteAlert = (item) => {
        Alert.alert(
            "",
            `${__("chatListScreenTexts.deletePromptMessage", appSettings.lng)}`,
            [
                {
                    text: __("chatListScreenTexts.cancelButtonTitle", appSettings.lng),
                },
                {
                    text: __("chatListScreenTexts.deleteButtonTitle", appSettings.lng),
                    onPress: () => handleDeleteConversation(item),
                },
            ],
            {cancelable: false}
        );
    };
    const handleDeleteConversation = (item) => {
        setDeleteLoading(true);
        setAuthToken(auth_token);
        api.delete("my/chat/conversation", {con_id: item.con_id}).then((res) => {
            if (res.ok) {
                setChatListData(chatListData.filter((message) => message != item));
                removeAuthToken();
                setDeleteLoading(false);
                handleSuccess(
                    __("chatListScreenTexts.chatDeleteSuccessText", appSettings.lng)
                );
            } else {
                setDeleteLoading(false);
                removeAuthToken();
                handleError(
                    res?.data?.error_message ||
                    res?.data?.error ||
                    res?.problem ||
                    __("chatListScreenTexts.chatDeleteErrorText", appSettings.lng)
                );
            }
        });
    };
    const Chat = ({
                      thumb,
                      chatTitle,
                      addTitle,
                      lastmessage,
                      onPress,
                      time,
                      onLongPress,
                      is_read,
                      source_id,
                  }) => (
        <TouchableWithoutFeedback onPress={onPress} onLongPress={onLongPress}>
            <View style={styles.message}>
                <View style={styles.chatImageContainer}>
                    <Image
                        style={styles.chatImage}
                        source={
                            thumb === null
                                ? chatListItemFallbackImageUrl
                                : {
                                    uri: thumb,
                                }
                        }
                    />
                </View>
                <View style={styles.chatDetails}>
                    <View style={styles.titleRow}>
                        <Text style={styles.chatTitle} numberOfLines={1}>
                            {decodeString(chatTitle)}
                        </Text>
                        <Text>{time}</Text>
                    </View>
                    <View style={{flexDirection: "row", justifyContent: "space-between"}}>
                        <Text
                            numberOfLines={1}
                            style={
                                is_read == 0 && user.id != source_id ? {fontWeight: "bold"} : {}
                            }
                        >
                            {lastmessage.length > 20 ? decodeString(lastmessage).substr(0, 20) + "..." : decodeString(lastmessage)}
                        </Text>
                        <View style={{marginLeft: 10}}>
                            <TouchableOpacity onPress={onLongPress}>
                                <FontAwesome name="trash-o" color={COLORS.red} size={20}/>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </View>
        </TouchableWithoutFeedback>
    );

    const renderChats = ({item}) => (
        <Chat
            onPress={() =>
                navigation.navigate(routes.chatScreen, {
                    ...item,
                    from: "list",
                    item: item.display_name,
                    thumb: item.listing.images
                })
            }
            thumb={
                item.listing.images.length > 0
                    ? item.listing.images[0].sizes.thumbnail.src
                    : null
            }
            chatTitle={item.display_name}
            lastmessage={item.last_message}
            time={moment(item.last_message_created_at).fromNow()}
            onLongPress={() => handleDeleteAlert(item)}
            is_read={item.is_read}
            source_id={item.source_id}
        />
    );

    const onRefresh = () => {
        setRefreshing(true);
    };

    const keyExtractor = useCallback((item, index) => `${index}`, []);

    const itemSeparator = () => <View style={styles.itemSeparator}/>;
    const handleSuccess = (message) => {
        setFlashNotificationMessage(message);
        setTimeout(() => {
            setFlashNotification(true);
        }, 10);
        setTimeout(() => {
            setFlashNotification(false);
            setFlashNotificationMessage();
        }, 1000);
    };
    const handleError = (message) => {
        setFlashNotificationMessage(message);
        setTimeout(() => {
            setFlashNotification(true);
        }, 10);
        setTimeout(() => {
            setFlashNotification(false);
            setFlashNotificationMessage();
        }, 1200);
    };

    const EmptyChatList = () => (
        <View style={styles.noChatWrap}>
            <Text style={styles.noChatTitle}>
                {__("chatListScreenTexts.noChatTitleMessage", appSettings.lng)}
            </Text>
            <View style={styles.noChatIcon}>
                <FontAwesome name="envelope" size={100} color={COLORS.primary_soft}/>
                <Image style={styles.shadow} source={require("../assets/NoChat.png")}/>
            </View>
        </View>
    );
    return (
        <DrawerLayout
            ref={drawer}
            drawerWidth={380}
            drawerPosition={drawerPosition}
            renderNavigationView={navigationView}
            drawerBackgroundColor={"#ffffff"}>
            <TabScreenHeader drawer showDrawer={() => drawer.current.openDrawer()}/>
            {!!user ? (is_connected ? (
                <>
                    {/* Screen Header Component */}
                    {user && loading && (
                        // {* Loading Component *}
                        <View style={styles.loadingWrap}>
                            <View style={styles.loading}>
                                <ActivityIndicator size="large" color={COLORS.primary}/>
                                <Text style={styles.loadingMessage}>
                                    {__("chatListScreenTexts.loadingMessage", appSettings.lng)}
                                </Text>
                            </View>
                        </View>
                    )}
                    <ScrollView
                        style={{backgroundColor: "#ffffff"}}
                        showsVerticalScrollIndicator={false}
                        refreshControl={
                            <RefreshControl
                                refreshing={refreshing}
                                onRefresh={onRefresh}
                            />
                        }>
                        <>
                            {(!loading || false) && (
                                <View
                                    style={[
                                        user && !chatListData.length ? styles.bgWhite : styles.bgDark
                                    ]}
                                >
                                    {/*user logged in and has chat data */}
                                    {!!user && !loading && (
                                        <View style={styles.chatListWrap}>

                                            <View style={styles.imageSearchContainer}>
                                                <View style={styles.child}>
                                                    <PremiumAds admob={false}/>
                                                    <View style={{position: 'absolute', left: 0, right: 0, top: 20,}}>
                                                        <View style={styles.listingTop}>
                                                            <Formik initialValues={{search: ""}}>
                                                                {() => (
                                                                    <View style={styles.ListingSearchContainer}>
                                                                        <TextInput
                                                                            style={styles.searchInput}
                                                                            placeholder={__(
                                                                                "homeScreenTexts.listingSearchPlaceholder",
                                                                                appSettings.lng
                                                                            )
                                                                            }
                                                                            placeholderTextColor={COLORS.textGray}
                                                                        />
                                                                        <TouchableOpacity
                                                                            style={styles.listingSearchBtnContainer}
                                                                        >
                                                                            {/* <Feather
                                                                                name="search"
                                                                                size={20}
                                                                                color={COLORS.white}
                                                                            />
                                                                             */}
                                                        <Text style={{color:'#fff'}}>Search</Text>

                                                                        </TouchableOpacity>
                                                                    </View>
                                                                )}
                                                            </Formik>
                                                        </View>
                                                    </View>
                                                </View>
                                            </View>
                                            <View style={styles.chatListWrapper}>
                                                <Text style={{
                                                    color: COLORS.primary,
                                                    textAlign: "center",
                                                    fontSize: 25,
                                                    fontFamily: "Poppins Bold",
                                                }}>Messages</Text>
                                                {!!deleteLoading && (
                                                    <View style={styles.deleteLoading}>
                                                        <View style={styles.deleteLoadingContentWrap}>
                                                            <LoadingIndicator
                                                                visible={true}
                                                                style={{
                                                                    width: "100%",
                                                                    marginLeft: "3.125%",
                                                                }}
                                                            />
                                                        </View>
                                                    </View>
                                                )}
                                                {/*<View style={{*/}
                                                {/*    flexDirection: "row",*/}
                                                {/*    alignItems: "center",*/}
                                                {/*    justifyContent: "space-between"*/}
                                                {/*}}>*/}
                                                {/*    <Text style={{*/}
                                                {/*        color: COLORS.black,*/}
                                                {/*        fontSize: 15,*/}
                                                {/*        fontFamily: "Poppins Bold",*/}
                                                {/*        paddingVertical: 10,*/}
                                                {/*        paddingHorizontal: 15*/}
                                                {/*    }}>Conversations</Text>*/}
                                                {/*    <TouchableOpacity style={{paddingRight: 15}}>*/}
                                                {/*        <View style={{*/}
                                                {/*            backgroundColor: "#F4F9FD",*/}
                                                {/*            padding: 10,*/}
                                                {/*            borderRadius: 10*/}
                                                {/*        }}>*/}
                                                {/*            <FontAwesome5 name="search" size={23}/>*/}
                                                {/*        </View>*/}
                                                {/*    </TouchableOpacity>*/}
                                                {/*</View>*/}
                                                <FlatList
                                                    data={chatListData}
                                                    renderItem={renderChats}
                                                    showsVerticalScrollIndicator={false}
                                                    keyExtractor={keyExtractor}
                                                    ListEmptyComponent={EmptyChatList}
                                                    contentContainerStyle={{
                                                        paddingHorizontal: 15
                                                    }}
                                                />
                                            </View>
                                        </View>
                                    )}
                                </View>
                            )}
                            {/* Flash Notification Component */}
                            <FlashNotification
                                falshShow={flashNotification}
                                flashMessage={flashNotificationMessage}
                            />
                        </>
                    </ScrollView>
                </>
            ) : (
                <View style={styles.noInternet}>
                    <FontAwesome5
                        name="exclamation-circle"
                        size={24}
                        color={COLORS.primary}
                    />
                    <Text style={styles.text}>
                        {__("myProfileScreenTexts.noInternet", appSettings.lng)}
                    </Text>
                </View>
            )) : (
                <>
                    <View style={styles.noUserViewWrap}>
                        <View style={styles.noUserTitleWrap}>
                            <Text style={styles.noUserTitle}>
                                {__("newListingScreenTexts.notLoggedIn", appSettings.lng)}
                            </Text>
                            <Text style={styles.noUserMessage}>
                                Please login or sign up and start chatting
                            </Text>
                            <View style={styles.authButtonWrap}>
                                <AppButton
                                    style={styles.authButton}
                                    title={__(
                                        "newListingScreenTexts.loginOrSignUpButtonTitle",
                                        appSettings.lng
                                    )}
                                    textStyle={{paddingHorizontal: 20}}
                                    onPress={() => navigation.navigate(routes.signuploginScreen)}
                                />
                            </View>
                        </View>
                    </View>
                </>
            )}
        </DrawerLayout>

    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#fafafa",
    },
    addTitle: {
        color: COLORS.text_gray,
        fontFamily: "Poppins Bold",
        marginRight: "30%",
    },
    bgWhite: {
        backgroundColor: COLORS.white,
        flex: 1,
    },
    bgDark: {
        backgroundColor: COLORS.bg_dark,
        flex: 1,
    },
    chatDetails: {
        marginLeft: 10,
        display: "flex",
        flex: 1,
    },
    chatImage: {
        height: 60,
        width: 60,
        resizeMode: "cover",
    },
    chatImageContainer: {
        height: 60,
        width: 60,
        borderColor: COLORS.gray,
        borderWidth: 1,
        borderRadius: 30,
        overflow: "hidden",
        alignItems: "center",
        justifyContent: "center",
    },
    chatListWrap: {
        backgroundColor: COLORS.white,
        height: screenHeight,
    },
    chatLogIn: {
        width: "60%",
        paddingVertical: 10,
        borderRadius: 3,
        marginVertical: 40,
    },
    chatTitle: {
        fontSize: 15,
        color: COLORS.text_dark,
        fontFamily: "Poppins Bold"
    },
    deleteLoading: {
        position: "absolute",
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        backgroundColor: "rgba(255,255,255,.7)",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 5,
        flex: 1,
        height: "100%",
        width: "100%",
    },
    deleteLoadingContentWrap: {
        paddingHorizontal: "3%",

        width: "100%",
        alignItems: "center",
        justifyContent: "center",
    },
    itemSeparator: {
        height: 1,
        width: "100%",
        backgroundColor: COLORS.bg_dark,
    },
    loading: {
        opacity: 1,
        backgroundColor: "transparent",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 5,
        flex: 1,
    },
    message: {
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: COLORS.white,
        fontFamily: "Poppins Bold",
        padding: 10,
    },
    noChatIcon: {
        marginVertical: 30,
        alignItems: "center",
    },
    noChatMessage: {
        color: COLORS.text_gray,
        fontFamily: "Poppins Regular"
    },
    noChatTitle: {
        fontSize: 16,
        color: COLORS.text_dark,
        fontFamily: "Poppins Bold"
    },
    noChatWrap: {
        paddingTop: 100,
        backgroundColor: COLORS.white,
        width: "100%",
        alignItems: "center",
        justifyContent: "center",
    },
    noUserWrap: {
        alignItems: "center",
        flex: 1,
        backgroundColor: "white",
        width: "100%",
        alignContent: "center"
    },
    noInternet: {
        alignItems: "center",
        flex: 1,
        backgroundColor: "white",
        justifyContent: "center",
    },
    shadow: {
        width: 110,
        resizeMode: "contain",
    },
    titleRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        flex: 1,
        alignItems: "center",
    },
    listingSearchBtnContainer: {
        marginLeft: 5,
        marginRight: -10,
        backgroundColor: COLORS.primary,
        borderRadius: 5,
        padding: 8
    },
    ListingSearchContainer: {
        flex: 1,
        height: 45,
        marginHorizontal: 10,
        backgroundColor: COLORS.white,
        borderWidth: 1,
        borderRadius: 4,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        paddingHorizontal: 15,
        elevation: 7,
        zIndex: 20,
        shadowColor: "#000",
        shadowRadius: 4,
        shadowOpacity: 0.2,
        shadowOffset: {
            height: -4,
            width: 2,
        },
    },
    imageSearchContainer: {
        paddingTop: 0,
        paddingHorizontal: 10,
        
        height: 250,
        width: '100%',
        backgroundColor: "#fff",
        // transform: [{ scaleX: 2 }],
        overflow: 'hidden',
    },
    child: {
        // top: -100,
        flex: 1,
        // transform: [{scaleX: 0.5}],
        alignItems: 'center',
        justifyContent: 'center'
    },
    listingTop: {
        width: "100%",
        // paddingTop: 100,
        zIndex: 1,
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: screenWidth * 0.03,
        paddingBottom: 10,
    },
    notEligible: {
        alignItems: "center",
        marginVertical: "10%",
    },
    noUserMessage: {
        fontSize: 16,
        color: COLORS.black,
    },
    noUserTitle: {
        fontSize: 20,
        fontFamily: "Poppins Regular"
    },
    noUserTitleWrap: {
        alignItems: "center",
    },
    noUserViewWrap: {
        justifyContent: "center",
        alignItems: "center",
        flex: 1,
    },
    loadingWrap: {
        justifyContent: "center",
        alignItems: "center",
        flex: 1,
        backgroundColor: COLORS.white
    },

    chatListWrapper: {
        marginHorizontal: 20,
        backgroundColor: COLORS.white,
        flex: 1,
        paddingTop: 30,
        top: -90,
        borderRadius: 20,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
    },
    searchInput: {
        flex: 1,
        fontFamily: "Poppins Regular"
    },
    authButton: {
        marginTop: 30,
        borderRadius: 50,
    }
});

export default ChatListScreen;
