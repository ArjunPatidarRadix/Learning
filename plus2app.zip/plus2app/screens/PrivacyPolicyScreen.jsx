import React, {useState} from "react";
import {View, Text, StyleSheet, ScrollView, Linking} from "react-native";

// Vector Icons
import {MaterialCommunityIcons} from "@expo/vector-icons";

// Custom Components & Functions
import {COLORS} from "../variables/color";
import {useStateValue} from "../StateProvider";
import {getPrivacyPolicy} from "../language/stringPicker";
import Unorderedlist from "react-native-unordered-list";

const PrivacyPolicyScreen = () => {
    const [{appSettings}] = useStateValue();
    const [privacyPolicyData, setPrivacyPolicyData] = useState(
        getPrivacyPolicy(appSettings.lng)
    );
    return (
        <View style={styles.container}>
            <ScrollView showsVerticalScrollIndicator={false}>
                <View style={styles.mainWrap}>
                    <View style={styles.ccontainer}>
                        <View style={styles.right}>
                            <Text style={styles.title}>Introduction</Text>
                            <Text style={styles.detail}>
                                Welcome to Plus2App (the &quot;Service&quot;). The following Terms of Use apply when you
                                view or use the Service located at: http://www.plus2app.com. Please review the
                                following terms carefully. By accessing or using the Service, you signify your
                                agreement to these Terms of Use. If you do not agree to these Terms of Use, you may
                                not access or use the Service.{"\n"}
                            </Text>

                            <Text style={styles.title}>Purposes of Processing</Text>
                            <Text style={styles.subTitle}>What is personal data?</Text>
                            <Text style={styles.detail}>
                                We collect information about you in a range of forms, including personal data.
                                As used in this Policy, “personal data” is as defined in the General Data Protection
                                Regulation,
                                this includes any information which, either alone or in combination with other
                                information
                                we process about you, identifies you as an individual, including, for example, your
                                name, postal
                                address, email address and telephone number.{"\n"}
                            </Text>

                            <Text style={styles.subTitle}>Why do we need your personal data?</Text>
                            <Text style={styles.detail}>
                                We will only process your personal data in accordance with applicable
                                data protection and privacy laws. We need certain personal data in order
                                to provide you with access to the website. If you registered with us,
                                you will have been asked to tick to agree to provide this information
                                in order to access our services, purchase our products, or view our
                                content. This consent provides us with the legal basis we require under
                                applicable law to process your data. You maintain the right to withdraw
                                such consent at any time. If you do not agree to our use of your personal
                                data in line with this Policy, please do not use our website.{"\n"}
                            </Text>

                            <Text style={styles.title}>Collecting Your Personal Data</Text>
                            <Text style={styles.detail}>We collect information about you in the following
                                ways:{'\n'}</Text>
                            <Text style={styles.subTitle}>Information You Give Us. </Text>
                            <Text style={styles.detail}>
                                This includes:{"\n"}
                            </Text>
                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.detail}>
                                    The personal data you provide when you register to use our website, including your
                                    name, postal address, email address, telephone number, username, password and
                                    demographic information (such as your gender);
                                </Text>
                            </Unorderedlist>
                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.detail}>
                                    The personal data that may be contained in any video, comment or other submission
                                    you upload or post to the website;
                                </Text>
                            </Unorderedlist>
                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.detail}>
                                    The personal data you provide in connection with our rewards program and other
                                    promotions we run on the website;
                                </Text>
                            </Unorderedlist>
                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.detail}>
                                    The personal data you provide when you report a problem with our website or when we
                                    provide you with customer support;
                                </Text>
                            </Unorderedlist>
                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.detail}>
                                    The personal data you provide when you make a purchase thorough our website; and
                                </Text>
                            </Unorderedlist>
                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.detail}>
                                    The personal data you provide when you correspond with us by phone, email or
                                    otherwise.{'\n'}
                                </Text>
                            </Unorderedlist>

                            <Text style={styles.subTitle}>Information from Social Networking Websites.</Text>
                            <Text style={styles.detail}>
                                Our website includes interfaces that allow you to connect with social networking sites
                                (each a “SNS”). If you connect to a SNS through our website, you authorize us to access,
                                use and store the information that you agreed the SNS could provide to us based on your
                                settings on that SNS. We will access, use and store that information in accordance with
                                this Policy. You can revoke our access to the information you provide in this way at any
                                time by amending the appropriate settings from within your account settings
                                on the applicable SNS.
                            </Text>

                            <Text style={styles.subTitle}>Information Automatically Collected.</Text>
                            <Text style={styles.detail}>
                                We automatically log information about you and your computer or mobile device when you
                                access our website. For example, when visiting our website, we log your computer or
                                mobile
                                device operating system name and version, manufacturer and model, browser type, browser
                                language,
                                screen resolution, the website you visited before browsing to our website, pages you
                                viewed,
                                how long you spent on a page, access times and information about your use of and actions
                                on
                                our website. We collect this information about you using cookies.
                            </Text>

                            <Text style={styles.subTitle}>Automated Decision Making and Profiling.</Text>
                            <Text style={styles.detail}>
                                We do not use your personal data for the purposes of automated decision-making. However,
                                we may do so in order to fulfill obligations imposed by law, in which case we will
                                inform you of any such processing and provide you with an opportunity to object.{'\n'}
                            </Text>

                            <Text style={styles.title}>Cookies</Text>
                            <Text style={styles.subTitle}>What are cookies?</Text>
                            <Text style={styles.detail}>
                                We may collect information using “cookies.” Cookies are small data files stored on the
                                hard drive of your computer or mobile device by a website. We may use both session
                                cookies (which expire once you close your web browser) and persistent cookies (which
                                stay on your computer or mobile device until you delete them) to provide you with a more
                                personal and interactive experience on our website.{'\n'}{'\n'}

                                We use two broad categories of cookies: (1) first party cookies, served directly by us
                                to your computer or mobile device, which are used only by us to recognize your computer
                                or mobile device when it revisits our website; and (2) third party cookies, which are
                                served by service providers on our website, and can be used by such service providers to
                                recognize your computer or mobile device when it visits other websites.{'\n'}
                            </Text>

                            <Text style={styles.subTitle}>Cookies we use</Text>
                            <Text style={styles.detail}>
                                Our website uses the following types of cookies for the purposes set out below:{'\n'}
                            </Text>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.subTitle}>
                                    Essential Cookies
                                </Text>
                                <Text style={styles.detail}>
                                    These cookies are essential to provide you with services available through our
                                    website and to enable you to use some of its features. For example, they allow
                                    you to log in to secure areas of our website and help the content of the pages
                                    you request load quickly. Without these cookies, the services that you have
                                    asked for cannot be provided, and we only use these cookies to provide you with
                                    those services.
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.subTitle}>
                                    Functionality Cookies
                                </Text>
                                <Text style={styles.detail}>
                                    These cookies allow our website to remember choices you make when you use our
                                    website, such as remembering your language preferences, remembering your login
                                    details and remembering the changes you make to other parts of our website which you
                                    can customize. The purpose of these cookies is to provide you with a more personal
                                    experience and to avoid you having to re-enter your preferences every time you visit
                                    our website.{'\n'}
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.subTitle}>
                                    Analytics and Performance Cookies
                                </Text>
                                <Text style={styles.detail}>
                                    These cookies are used to collect information about traffic to our website and how
                                    users use our website. The information gathered does not identify any individual
                                    visitor. It includes the number of visitors to our website, the websites that
                                    referred them to our website, the pages they visited on our website, what time of
                                    day they visited our website, whether they have visited our website before, and
                                    other similar information. We use this information to help operate our website more
                                    efficiently, to gather broad demographic information and to monitor the level of
                                    activity on our website.{'\n'}{'\n'}

                                    We use Google Analytics for this purpose. Google Analytics uses its own cookies. It
                                    is only used to improve how our website works. You can find out more information
                                    about Google Analytics cookies here:
                                    https://developers.google.com/analytics/resources/concepts/gaConceptsCookies{'\n'}{'\n'}

                                    You can find out more about how Google protects your data here:
                                    https://policies.google.com/privacy{'\n'}{'\n'}

                                    You can prevent the use of Google Analytics relating to your use of our website by
                                    downloading and installing the browser plugin available via this link:
                                    http://tools.google.com/dlpage/gaoptout?hl=en-GB
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.subTitle}>
                                    Targeted and advertising cookies
                                </Text>
                                <Text style={styles.detail}>
                                    These cookies track your browsing habits to enable us to show advertising which is
                                    more likely to be of interest to you. These cookies use information about your
                                    browsing history to group you with other users who have similar interests. Based on
                                    that information, and with our permission, third party advertisers can place cookies
                                    to enable them to show adverts which we think will be relevant to your interests
                                    while you are on third party websites.
                                    You can disable cookies which remember your browsing habits and target advertising
                                    at you by visiting http://www.youronlinechoices.com/uk/your-ad-choices. If you
                                    choose to remove targeted or advertising cookies, you will still see adverts but
                                    they may not be relevant to you. Even if you do choose to remove cookies by the
                                    companies listed at the above link, not all companies that serve online behavioral
                                    advertising are included in this list, and so you may still receive some cookies and
                                    tailored adverts from companies that are not listed.{'\n'}
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.subTitle}>
                                    Social Media Cookies
                                </Text>
                                <Text style={styles.detail}>
                                    These cookies are used when you share information using a social media sharing
                                    button or “like” button on our website or you link your account or engage with our
                                    content on or through a social networking website such as Facebook, Twitter or
                                    Google+. The social network will record that you have done this.{'\n'}
                                </Text>
                            </Unorderedlist>

                            <Text style={styles.subTitle}>Disabling cookies</Text>
                            <Text style={styles.detail}>
                                You can typically remove or reject cookies via your browser settings. In order to do
                                this, follow the instructions provided by your browser (usually located within the
                                “settings,” “help” “tools” or “edit” facility). Many browsers are set to accept cookies
                                until you change your settings.{'\n \n'}
                                If you do not accept our cookies, you may experience some inconvenience in your use of
                                our website. For example, we may not be able to recognize your computer or mobile device
                                and you may need to log in every time you visit our website.{'\n'}
                            </Text>

                            <Text style={styles.title}>Advertising</Text>
                            <Text style={styles.detail}>
                                We may use other companies to serve third-party advertisements when you visit and use
                                the website. These companies may collect and use click stream information, browser type,
                                time and date, subject of advertisements clicked or scrolled over during your visits to
                                the website and other websites in order to provide advertisements about goods and
                                services likely to be of interest to you. These companies typically use tracking
                                technologies to collect this information. Other companies' use of their tracking
                                technologies is subject to their own privacy policies.{'\n'}
                            </Text>

                            <Text style={styles.subTitle}>Using Your Personal Data</Text>
                            <Text style={styles.detail}>
                                We may use your personal data as follows:
                            </Text>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.detail}>
                                    To operate, maintain, and improve our website, products, and services;{'\n'}
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.detail}>
                                    To manage your account, including to communicate with you regarding your account, if
                                    you have an account on our website;
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.detail}>
                                    To operate and administer our rewards program and other promotions you participate
                                    in on our website;
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.detail}>
                                    To respond to your comments and questions and to provide customer service;
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.detail}>
                                    To send information including technical notices, updates, security alerts, and
                                    support and administrative messages;
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.detail}>
                                    With your consent, to send you marketing e-mails about upcoming promotions, and
                                    other news, including information about products and services offered by us and our
                                    affiliates.{'\n \n'}

                                    You may opt-out of receiving such information at any time: such marketing emails
                                    tell you how to “opt-out.” Please note, even if you opt out of receiving marketing
                                    emails, we may still send you non-marketing emails. Non-marketing emails include
                                    emails about your account with us (if you have one) and our business dealings with
                                    you;
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.detail}>
                                    To process payments you make via our website;
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.detail}>
                                    As we believe necessary or appropriate (a) to comply with applicable laws; (b) to
                                    comply with lawful requests and legal process, including to respond to requests from
                                    public and government authorities; (c) to enforce our Policy; and (d) to protect our
                                    rights, privacy, safety or property, and/or that of you or others;
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.detail}>
                                    For analysis and study services; and
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.detail}>
                                    As described in the “Sharing of your Personal Data” section below.{'\n'}
                                </Text>
                            </Unorderedlist>

                            <Text style={styles.subTitle}>Sharing Your Personal Data</Text>
                            <Text style={styles.detail}>
                                We may share your personal data as follows: {'\n'}
                            </Text>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.subTitle}>
                                    Third Parties Designated by You.
                                </Text>
                                <Text style={styles.detail}>
                                    We may share your personal data with third parties where you have provided your
                                    consent to do so.
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.subTitle}>
                                    Our Third Party Service Providers.
                                </Text>
                                <Text style={styles.detail}>
                                    We may share your personal data with our third party service providers who provide
                                    services such as data analysis, payment processing, information technology and
                                    related infrastructure provision, customer service, email delivery, auditing and
                                    other similar services.
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.subTitle}>
                                    Third Party Sites{'\n'}
                                </Text>
                            </Unorderedlist>

                            <Text style={styles.detail}>
                                Our website may contain links to third party websites and features. This Policy does not
                                cover the privacy practices of such third parties. These third parties have their own
                                privacy policies and we do not accept any responsibility or liability for their
                                websites, features or policies. Please read their privacy policies before you submit any
                                data to them.{'\n'}
                            </Text>

                            <Text style={styles.subTitle}>User Generated Content</Text>
                            <Text style={styles.detail}>
                                You may share personal data with us when you submit user generated content to our
                                website, including via our rewards program, forums, message boards and Websites on our
                                website. Please note that any information you post or disclose on our website will
                                become public information, and will be available to other users of our website and to
                                the general public. We urge you to be very careful when deciding to disclose your
                                personal data, or any other information, on our website. Such personal data and other
                                information will not be private or confidential once it is published on our
                                website.{'\n \n'}

                                If you provide feedback to us, we may use and disclose such feedback on our website,
                                provided we do not associate such feedback with your personal data. If you have provided
                                your consent to do so, we may post your first and last name along with your feedback on
                                our website. We will collect any information contained in such feedback and will treat
                                the personal data in it in accordance with this Policy.
                            </Text>

                            <Text style={styles.subTitle}>International Data Transfer</Text>
                            <Text style={styles.detail}>
                                Your information, including personal data that we collect from you, may be transferred
                                to, stored at and processed by us outside the country in which you reside, where data
                                protection and privacy regulations may not offer the same level of protection as in
                                other parts of the world. By accepting this Policy, you agree to this transfer, storing
                                or processing. We will take all steps reasonably necessary to ensure that your data is
                                treated securely and in accordance with this Policy.{'\n'}
                            </Text>

                            <Text style={styles.subTitle}>Security</Text>
                            <Text style={styles.detail}>
                                We seek to use reasonable organizational, technical and administrative measures to
                                protect personal data within our organization. Unfortunately, no transmission or storage
                                system can be guaranteed to be completely secure, and transmission of information via
                                the Internet is not completely secure. If you have reason to believe that your
                                interaction with us is no longer secure (for example, if you feel that the security of
                                any account you might have with us has been compromised), please immediately notify us
                                of the problem by contacting us.{'\n'}
                            </Text>

                            <Text style={styles.subTitle}>Retention</Text>
                            <Text style={styles.detail}>
                                We will only retain your personal data as long reasonably required for you to use the
                                website until you close your account/cancel your subscription unless a longer retention
                                period is required or permitted by law (for example for regulatory purposes).{'\n'}
                            </Text>

                            <Text style={styles.title}>Our Policy on Children</Text>
                            <Text style={styles.detail}>
                                Our website is/are not directed to children under 16. If a parent or guardian becomes
                                aware that his or her child has provided us with information without their consent, he
                                or she should contact us. We will delete such information from our files as soon as
                                reasonably practicable.{'\n'}
                            </Text>

                            <Text style={styles.subTitle}>Your Rights</Text>
                            <Text style={styles.detail}>
                                Our website is/are not directed to children under 16. If a parent or guardian becomes
                                aware that his or her child has provided us with information without their consent, he
                                or she should contact us. We will delete such information from our files as soon as
                                reasonably practicable.{'\n'}
                            </Text>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.subTitle}>
                                    Opt-Out
                                </Text>
                                <Text style={styles.detail}>
                                    You may contact us anytime to opt-out of: (i) direct marketing communications; (ii)
                                    automated decision-making and/or profiling; (iii) our collection of sensitive
                                    personal data; (iv) any new processing of your personal data that we may carry out
                                    beyond the original purpose; or (v) the transfer of your personal data outside the
                                    EEA. Please note that your use of some of the website may be ineffective upon
                                    opt-out.
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.subTitle}>
                                    Access
                                </Text>
                                <Text style={styles.detail}>
                                    You may access the information we hold about you at any time via your
                                    profile/account or by contacting us directly.
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.subTitle}>
                                    Amend
                                </Text>
                                <Text style={styles.detail}>
                                    You can also contact us to update or correct any inaccuracies in your personal data.
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.subTitle}>
                                    Move
                                </Text>
                                <Text style={styles.detail}>
                                    Your personal data is portable – i.e. you to have the flexibility to move your data
                                    to other service providers as you wish.
                                </Text>
                            </Unorderedlist>

                            <Unorderedlist style={{marginLeft: 20}}>
                                <Text style={styles.subTitle}>
                                    Erase and forget
                                </Text>
                                <Text style={styles.detail}>
                                    In certain situations, for example when the information we hold about you is no
                                    longer relevant or is incorrect, you can request that we erase your data.
                                </Text>
                            </Unorderedlist>

                            <Text style={styles.detail}>
                                If you wish to exercise any of these rights, please contact us. In your request, please
                                make clear: (i) <Text style={styles.subTitle}>what</Text> personal data is concerned;
                                and (ii) <Text style={styles.subTitle}>which of the above rights</Text> you
                                would like to enforce. For your protection, we may only implement requests with respect
                                to the personal data associated with the particular email address that you use to send
                                us your request, and we may need to verify your identity before implementing your
                                request. We will try to comply with your request as soon as reasonably practicable and
                                in any event, within one month of your request. Please note that we may need to retain
                                certain information for record-keeping purposes and/or to complete any transactions that
                                you began prior to requesting such change or deletion.{'\n'}
                            </Text>

                            <Text style={styles.title}>Complaints</Text>
                            <Text style={styles.detail}>
                                We are committed to resolve any complaints about our collection or use of your personal
                                data. If you would like to make a complaint regarding this Policy or our practices in
                                relation to your personal data, please contact us through the information listed on our
                                website. We will reply to your complaint as soon as we can and in any event, within 30
                                days. We hope to resolve any complaint brought to our attention, however if you feel
                                that your complaint has not been adequately resolved, you reserve the right to contact
                                your local data protection supervisory authority{'\n'}
                            </Text>

                            <Text style={styles.title}>Contact Information</Text>
                            <Text style={styles.detail}>
                                We welcome your comments or questions about this Policy. You may contact us in writing
                                or through our website.
                            </Text>

                        </View>
                    </View>
                </View>
            </ScrollView>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        backgroundColor: COLORS.white,
        flex: 1,
    },
    mainWrap: {
        paddingTop: 10,
    },
    detail: {
        fontSize: 14,
        color: COLORS.text_gray,
        textAlign: "justify",
        lineHeight: 22,
    },
    title: {
        fontSize: 17,
        color: "#4D4B4B",
        fontWeight: "bold",
        marginBottom: 5,
    },
    subTitle: {
        fontSize: 14,
        color: "#4D4B4B",
        fontWeight: "bold",
        marginBottom: 5,
    },
    right: {
        flex: 1,
    },
    ccontainer: {
        flexDirection: "row",
        alignItems: "center",
        paddingVertical: 10,
        paddingHorizontal: "3%",
    },
});

export default PrivacyPolicyScreen;
