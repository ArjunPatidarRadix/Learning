/* eslint-disable no-unused-vars */
import React, {useState, useEffect, useRef} from "react";
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    Image,
    TouchableOpacity,
    ActivityIndicator,
    Dimensions,
    TextInput,
    Alert
} from "react-native";

import {FontAwesome5} from "@expo/vector-icons";

// Custom Components & Functions
import {COLORS} from "../variables/color";
import {useStateValue} from "../StateProvider";
import api, {setAuthToken, removeAuthToken} from "../api/client";
import FlashNotification from "../components/FlashNotification";
import {__} from "../language/stringPicker";
import {routes} from "../navigation/routes";
import TabScreenHeader from "../components/TabScreenHeader";
import Feather from "react-native-vector-icons/Feather";
import {Formik} from "formik";
import AppButton from "../components/AppButton";
import {useNavigation} from "@react-navigation/native";
import {DrawerLayout} from "react-native-gesture-handler";
import PremiumAds from "../components/PremiumAds";
import {decodeString} from "../helper/helper";
import AppTextButton from "../components/AppTextButton";
import DrawerMenu from "../components/DrawerMenu";

const listingCardFallbackImageUrl = require("../assets/100x100.png");
const {width: deviceWidth, height: deviceHeight} = Dimensions.get("window");
const {width: screenWidth} = Dimensions.get("screen");
const MyProfileTabScreen = ({route}) => {
    const drawer = useRef(null);
    const [drawerPosition] = useState("left");

    const navViewLoading = () => (
        // eslint-disable-next-line no-undef
        <View style={[styles.container, {alignItems: "center", justifyContent: "center"}]}>
            <Text>Loading. Please wait...</Text>
        </View>
    );
    const navigation = useNavigation();
    const [{auth_token}] = useStateValue();
    const [{business_or_professional, user, is_connected, appSettings}, dispatch] =
        useStateValue();
    const [loading, setLoading] = useState(false);
    const [imageViewer, setImageViewer] = useState(false);
    const [flashNotification, setFlashNotification] = useState(false);
    const [flashNotificationMessage, setFlashNotificationMessage] = useState();


    const navigationView = () => (
        <View style={[styles.container]}>
            <DrawerMenu close={() => drawer.current.closeDrawer()}/>
        </View>
    );



    const deleteProfile = ({category, business_id}) => {
        Alert.alert(
            "Delete Profile",
            "Are you sure you want to delete this profile?",
            [
                {
                    text: "Cancel",
                    // onPress: () => Alert.alert("Cancel Pressed"),
                    style: "cancel",
                },
                {
                    text: "Yes",
                    onPress: () => {
                        setLoading(true)
                        setAuthToken(auth_token);
                        api.delete('my/listings', {listing_id: business_id})
                            .then(res => {
                                setLoading(false)
                                dispatch({
                                    type: "SET_BUSINESS_OR_PROFESSIONAL",
                                    business_or_professional: [],
                                })
                            })
                            .catch((error) => {
                                setLoading(false);
                                console.log(error)
                            })
                    }
                }
            ],
            {
                cancelable: true,
            }
        );


    }

    return (
        <DrawerLayout
            ref={drawer}
            drawerWidth={380}
            drawerPosition={drawerPosition}
            renderNavigationView={loading ? navViewLoading : navigationView}
            drawerBackgroundColor={"#ffffff"}>
            <TabScreenHeader
                drawer
                showDrawer={() => drawer.current.openDrawer()}
                style={{elevation: 0, zIndex: 2}}/>
            {!!user ? (is_connected ? (
                <>
                    {loading ? (
                        <View style={styles.loadingWrap}>
                            <View style={styles.loading}>
                                <ActivityIndicator size="large" color={COLORS.primary}/>
                                <Text style={styles.loadingMessage}>
                                    {__("myProfileScreenTexts.loadingMessage", appSettings.lng)}
                                </Text>
                            </View>
                        </View>
                    ) : (
                        <>
                            {!imageViewer && (
                                <View style={styles.container}>
                                    <ScrollView showsVerticalScrollIndicator={false}>
                                        <View style={styles.imageSearchContainer}>
                                            <View style={styles.child}>
                                                <PremiumAds admob={false}/>

                                                <View style={{position: 'absolute', left: 0, right: 0, top:20,}}>
                                                    <View style={styles.listingTop}>
                                                        <Formik initialValues={{search: ""}}>
                                                            {({handleChange, handleBlur, handleSubmit, values}) => (
                                                                <View style={styles.ListingSearchContainer}>
                                                                    <TextInput
                                                                        placeholder={
                                                                            __(
                                                                                "homeScreenTexts.listingSearchPlaceholder",
                                                                                appSettings.lng
                                                                            )
                                                                        }
                                                                        style={styles.searchInput}
                                                                        placeholderTextColor={COLORS.textGray}
                                                                        onChangeText={handleChange("search")}
                                                                        onBlur={() => {
                                                                            handleBlur("search");
                                                                        }}
                                                                        value={values.search}
                                                                        returnKeyType="search"
                                                                    />

                                                                    <TouchableOpacity
                                                                        style={styles.listingSearchBtnContainer}
                                                                    >
                                                                                                                               <Text style={{color:'#fff'}}>Search</Text>

                                                                    </TouchableOpacity>
                                                                </View>
                                                            )}
                                                        </Formik>
                                                    </View>
                                                </View>
                                            </View>
                                        </View>
                                        <View style={{marginBottom: 50, flex: 1, marginHorizontal: 20}}>
                                            {!business_or_professional || business_or_professional.length === 0 ? (
                                                <View style={{
                                                    justifyContent: "center",
                                                    alignItems: "center",
                                                    marginTop: 50
                                                }}>
                                                    <Text style={{
                                                        fontFamily: "Poppins Bold",
                                                        textAlign: "center",
                                                        fontSize: 15
                                                    }}>
                                                        YOU CURRENTLY HAVE A <Text style={{color: COLORS.primary}}>PERSONAL
                                                        PROFILE</Text>
                                                    </Text>
                                                    <View style={{
                                                        alignItems: "center",
                                                        marginTop: 50
                                                    }}>
                                                        <View>
                                                            <TouchableOpacity style={{
                                                                borderWidth: 1,
                                                                borderColor: '#e0e0e0',
                                                                justifyContent: 'center',
                                                                alignItems: 'center',
                                                                paddingVertical: 20,
                                                                borderRadius: 10,
                                                                marginBottom: 20,
                                                                width: screenWidth - 50
                                                            }}
                                                                              onPress={() => navigation.navigate("New Business Service", {
                                                                                  category: 498,
                                                                                  business_id: business_or_professional.listing_id
                                                                              })}>
                                                                <Image source={require('../assets/business.jpg')}
                                                                       style={{width: 80, height: 80}}/>
                                                                <Text style={{
                                                                    fontFamily: "Poppins Bold",
                                                                    textAlign: "center",
                                                                    fontSize: 15
                                                                }}>
                                                                    OPEN A <Text style={{color: COLORS.primary}}>BUSINESS
                                                                    PROFILE</Text>
                                                                </Text>
                                                            </TouchableOpacity>
                                                        </View>
                                                        <View>
                                                            <TouchableOpacity style={{
                                                                borderWidth: 1,
                                                                borderColor: '#e0e0e0',
                                                                justifyContent: 'center',
                                                                alignItems: 'center',
                                                                paddingVertical: 20,
                                                                borderRadius: 10,
                                                                marginBottom: 20,
                                                                width: screenWidth - 50
                                                            }}
                                                                              onPress={() => navigation.navigate("New Business Service", {
                                                                                  category: 353,
                                                                                  business_id: business_or_professional.listing_id
                                                                              })}>
                                                                <Image source={require('../assets/professional.jpg')}
                                                                       style={{width: 80, height: 80}}/>
                                                                <Text style={{
                                                                    fontFamily: "Poppins Bold",
                                                                    textAlign: "center",
                                                                    fontSize: 15
                                                                }}>
                                                                    OPEN A <Text style={{color: COLORS.primary}}>PROFESSIONAL
                                                                    PROFILE</Text>
                                                                </Text>
                                                            </TouchableOpacity>
                                                        </View>

                                                    </View>
                                                </View>

                                            ) : (
                                                <View style={[styles.profWrapper, {
                                                    marginTop: 20,
                                                    paddingBottom: 0,
                                                }]}>
                                                    <View style={{
                                                        backgroundColor: COLORS.primary,
                                                        borderTopEndRadius: 20,
                                                        borderTopLeftRadius: 20
                                                    }}>
                                                        <Text
                                                            style={styles.profText}>{business_or_professional.categories[0].term_id === 353 ? "Professional Profile" : "Business Profile"}</Text>
                                                    </View>
                                                    <View style={{flexDirection: "row", flex: 1, justifyContent: "space-between"}}>
                                                        <Image
                                                            style={styles.imageWrapStore}
                                                            source={
                                                                business_or_professional?.images?.length
                                                                    ? {
                                                                        uri: business_or_professional.images[0].sizes.thumbnail.src,
                                                                    }
                                                                    : listingCardFallbackImageUrl
                                                            }
                                                        />
                                                        <View
                                                            style={{
                                                                flexDirection: "column",
                                                                justifyContent: "center",
                                                                flex: 1,
                                                            }}>
                                                            <View style={{
                                                                paddingLeft: 20,
                                                                paddingTop: 10,
                                                                paddingBottom: 5
                                                            }}>
                                                                <Text style={{
                                                                    fontFamily: "Poppins Bold",
                                                                    fontSize: 10
                                                                }}>{decodeString(business_or_professional.title)}</Text>
                                                            </View>
                                                            <View style={{
                                                                paddingLeft: 20,
                                                                flexDirection: "row",
                                                                alignItems: "center"
                                                            }}>
                                                                <FontAwesome5 name="compass" size={10}
                                                                              color={COLORS.gray}/>
                                                                <Text style={{
                                                                    fontFamily: "Poppins Bold",
                                                                    fontSize: 10,
                                                                    paddingTop: 4,
                                                                    paddingLeft: 5,
                                                                    color: COLORS.gray
                                                                }}>
                                                                     {business_or_professional.contact.locations.length > 0 ? decodeString(business_or_professional.contact.locations[1].name) : "No address"}
                                                                    </Text>
                                                          </View>
                                                            <View style={{
                                                                paddingLeft: 20,
                                                                flexDirection: "row",
                                                                alignItems: "center"
                                                            }}>
                                                                <Text style={{
                                                                    fontFamily: "Poppins Regular",
                                                                    fontSize: 8,
                                                                    paddingTop: 4,
                                                                    // paddingLeft: 5,
                                                                    color: COLORS.gray
                                                                }}>Member
                                                                    since {business_or_professional.created_at.substr(0, 4)}</Text>
                                                            </View>
                                                        </View>
                                                        <View style={{
                                                            // paddingHorizontal: 10,
                                                            paddingVertical: 15,
                                                            // paddingLeft: 40,
                                                            justifyContent: "center",
                                                            // flex: 1
                                                            paddingRight: 20
                                                        }}>
                                                            <View>
                                                                <TouchableOpacity
                                                                    onPress={() => navigation.navigate(routes.editProfile, {
                                                                        item: business_or_professional,
                                                                    })}
                                                                    style={{
                                                                        flexDirection: "row",
                                                                        alignItems: "center",
                                                                        marginBottom: 5
                                                                    }}>
                                                                    <FontAwesome5 name="edit" color={COLORS.primary}
                                                                                  size={10}/>
                                                                    <Text style={{
                                                                        fontFamily: "Poppins Bold",
                                                                        paddingLeft: 2,
                                                                        fontSize: 10,
                                                                        paddingTop: 5
                                                                    }}>Edit</Text>
                                                                </TouchableOpacity>
                                                            </View>
                                                            <View>
                                                                <TouchableOpacity
                                                                    onPress={() => deleteProfile({
                                                                        category: business_or_professional.categories[0].parent,
                                                                        business_id: business_or_professional.listing_id
                                                                    })}
                                                                    style={{
                                                                        flexDirection: "row",
                                                                        alignItems: "center",
                                                                        marginBottom: 5
                                                                    }}>
                                                                    <FontAwesome5 name="trash-alt"
                                                                                  color={COLORS.primary} size={10}/>
                                                                    <Text style={{
                                                                        fontFamily: "Poppins Bold",
                                                                        paddingLeft: 2,
                                                                        fontSize: 10,
                                                                        paddingTop: 5
                                                                    }}>Delete</Text>
                                                                </TouchableOpacity>
                                                            </View>
                                                            <View>
                                                                <TouchableOpacity
                                                                    style={{flexDirection: "row", alignItems: "center"}}
                                                                    onPress={() => navigation.navigate("Business Profile", {
                                                                        category: business_or_professional.categories[0].parent,
                                                                        business_id: business_or_professional.listing_id
                                                                    })}>
                                                                    <FontAwesome5 name="eye" color={COLORS.primary}
                                                                                  size={10}/>
                                                                    <Text style={{
                                                                        fontFamily: "Poppins Bold",
                                                                        paddingLeft: 2,
                                                                        fontSize: 10,
                                                                        paddingTop: 5
                                                                    }}>View</Text>
                                                                </TouchableOpacity>
                                                            </View>
                                                        </View>
                                                    </View>
                                                </View>
                                            )}
                                        </View>
                                    </ScrollView>
                                </View>
                            )}
                        </>
                    )}
                    <FlashNotification
                        falshShow={flashNotification}
                        flashMessage={flashNotificationMessage}
                    />
                </>
            ) : (
                <View style={styles.noInternet}>
                    <FontAwesome5
                        name="exclamation-circle"
                        size={24}
                        color={COLORS.primary}
                    />
                    <Text style={styles.text}>
                        {__("myProfileScreenTexts.noInternet", appSettings.lng)}
                    </Text>
                </View>
            )) : (
                <>
                    <View style={styles.noUserViewWrap}>
                        <View style={styles.noUserTitleWrap}>
                            <Text style={styles.noUserTitle}>
                                {__("newListingScreenTexts.notLoggedIn", appSettings.lng)}
                            </Text>
                            <Text style={styles.noUserMessage}>
                                {__("newListingScreenTexts.loginOrSignUpToSeeProf", appSettings.lng)}
                            </Text>
                            <View style={styles.authButtonWrap}>
                                <AppButton
                                    style={styles.authButton}
                                    title={__(
                                        "newListingScreenTexts.loginOrSignUpButtonTitle",
                                        appSettings.lng
                                    )}
                                    textStyle={{paddingHorizontal: 20}}
                                    onPress={() => navigation.navigate(routes.signuploginScreen)}
                                />
                            </View>
                        </View>
                    </View>
                </>
            )}
        </DrawerLayout>

    );
};

const styles = StyleSheet.create({
    container: {
        backgroundColor: COLORS.white,
        flex: 1,
    },
    image: {
        height: 85,
        width: 85,
        resizeMode: "cover",
        borderRadius: 50,
    },
    imageViewer: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
    },
    imageViewerCloseButton: {
        position: "absolute",
        right: 15,
        top: 15,
        zIndex: 10,
        height: 25,
        width: 25,
        backgroundColor: COLORS.white,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 13,
    },
    imageViewerWrap: {
        position: "absolute",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "white",
        width: "100%",
        height: "100%",
        flex: 1,
    },
    imageWrap: {
        height: 90,
        width: 90,
        borderRadius: 50,
        borderWidth: 1,
        borderColor: "#d5d5d5",
        top: -30,
        backgroundColor: COLORS.white,
        alignItems: "center",
        justifyContent: "center"
    },
    imageWrapStore: {
        height: 100,
        width: "30%",
        marginVertical: 10,
        marginLeft: 10,
        borderRadius: 5
    },
    detail: {
        top: -30,
        alignItems: "center"
    },
    loading: {
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        opacity: 0.8,
        backgroundColor: "transparent",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 5,
        flex: 1,
    },
    loadingWrap: {
        justifyContent: "center",
        alignItems: "center",
        flex: 1,
    },
    mainWrap: {
        backgroundColor: COLORS.bg_light,
        paddingVertical: 15,
        paddingHorizontal: "3%",
    },
    name: {
        fontSize: 18,
        color: COLORS.text_dark,
        marginLeft: 10,
    },
    noInternet: {
        alignItems: "center",
        flex: 1,
        backgroundColor: "white",
        justifyContent: "center",
        width: "100%",
        height: "100%",
    },
    phone: {
        marginLeft: 10,
        fontSize: 16,
        color: COLORS.text_gray,
    },
    phoneWrap: {
        flexDirection: "row",
        alignItems: "center",
        marginVertical: 5,
    },
    separator: {
        width: "100%",
        backgroundColor: COLORS.bg_dark,
        marginVertical: 15,
    },
    titleRight: {
        marginLeft: 15,
    },
    titleRow: {
        flexDirection: "row",
        alignItems: "center",
    },

    child: {
        // top: -100,
        flex: 1,
        // transform: [{scaleX: 0.5}],
        alignItems: 'center',
        justifyContent: 'center'
    },
    listingTop: {
        width: "100%",
        // paddingTop: 100,
        zIndex: 1,
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: screenWidth * 0.03,
        paddingBottom: 10,
    },
    listingSearchBtnContainer: {
        marginLeft: 5,
        marginRight: -10,
        backgroundColor: COLORS.primary,
        borderRadius: 5,
        padding: 8
    },
    ListingSearchContainer: {
        flex: 1,
        height: 45,
        marginHorizontal: 10,
        backgroundColor: COLORS.white,
        borderWidth: 1,
        borderRadius: 4,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        paddingHorizontal: 15,
        elevation: 7,
        zIndex: 20,
        shadowColor: "#000",
        shadowRadius: 4,
        shadowOpacity: 0.2,
        shadowOffset: {
            height: -4,
            width: 2,
        },
    },
    imageSearchContainer: {
        paddingTop: 0,
        paddingHorizontal: 10,

        height: 250,
        width: '100%',
        backgroundColor: "#fff",
        // transform: [{ scaleX: 2 }],
        overflow: 'hidden',
    },
    profWrapper: {
        backgroundColor: COLORS.white,
        borderRadius: 20,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
    },
    profText: {
        color: COLORS.white,
        fontSize: 10,
        textAlign: "center",
        fontFamily: "Poppins Bold",
        paddingTop: 10
    },
    basicWrapper: {
        height: deviceHeight * 0.29,
        borderRadius: 10,
        borderWidth: 1,
        borderColor: "#d5d5d5",
        marginHorizontal: 20,
        marginTop: 40,
        alignItems: "center",
    },
    infoWrapper: {
        height: 300,
        borderRadius: 10,
        borderWidth: 1,
        borderColor: "#d5d5d5",
        marginHorizontal: 20,
        marginTop: 80,
        paddingTop: 20,
        paddingHorizontal: 20
    },
    locYears: {
        display: "flex",
        flexDirection: "row",
        paddingTop: 10,
        alignItems: "center"
    },
    notEligible: {
        alignItems: "center",
        marginVertical: "10%",
    },
    noUserMessage: {
        fontSize: 16,
    },
    noUserTitle: {
        fontSize: 20,
        fontFamily: "Poppins Regular"
    },
    noUserTitleWrap: {
        alignItems: "center",
    },
    noUserViewWrap: {
        justifyContent: "center",
        alignItems: "center",
        flex: 1,
    },
    searchInput: {
        flex: 1,
        fontFamily: "Poppins Regular"
    },
    authButton: {
        marginTop: 30,
        borderRadius: 50,
    }
});

export default MyProfileTabScreen;
