/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from "react";
import {
  View,
  StyleSheet,
  Text,
  TextInput,
  Keyboard,
  KeyboardAvoidingView,
  Modal,
  Dimensions,
  ScrollView,
  SafeAreaView,
  TouchableOpacity,
} from "react-native";
import RNPickerSelect, { defaultStyles } from "react-native-picker-select";
// External Libraries
import { Formik } from "formik";
import * as Yup from "yup";

// Custom Components & Functions
import Constants from "expo-constants";
import AppButton from "../components/AppButton";
import api from "../api/client";
import { COLORS } from "../variables/color";
import FlashNotification from "../components/FlashNotification";
import { useStateValue } from "../StateProvider";
import { __ } from "../language/stringPicker";
import { getTnC } from "../language/stringPicker";
import { FontAwesome5, MaterialCommunityIcons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";

const { width: screenWidth, height: screenHeight } = Dimensions.get("screen");

const SignUpScreen = () => {
  const navigation = useNavigation();
  const [{ ios, appSettings }] = useStateValue();
  const [validationSchema, setValidationSchema] = useState(
    Yup.object().shape({
      first_name: Yup.string().required(
        __("signUpScreenTexts.formFieldLabels.first_name", appSettings.lng) +
          " " +
          __("signUpScreenTexts.formValidation.requiredField", appSettings.lng)
      ),
      last_name: Yup.string().required(
        __("signUpScreenTexts.formFieldLabels.last_name", appSettings.lng) +
          " " +
          __("signUpScreenTexts.formValidation.requiredField", appSettings.lng)
      ),
      username: Yup.string(),
      country: Yup.number().required(
        __("signUpScreenTexts.formFieldLabels.country", appSettings.lng) +
          " " +
          __("signUpScreenTexts.formValidation.requiredField", appSettings.lng)
      ),
      phone: Yup.string()
        .required(
          __("signUpScreenTexts.formFieldLabels.phone", appSettings.lng) +
            " " +
            __(
              "signUpScreenTexts.formValidation.requiredField",
              appSettings.lng
            )
        )
        .min(
          5,
          __("signUpScreenTexts.formFieldLabels.phone", appSettings.lng) +
            " " +
            __(
              "signUpScreenTexts.formValidation.minimumLength5",
              appSettings.lng
            )
        ),
      email: Yup.string()
        .required(
          __("signUpScreenTexts.formFieldLabels.email", appSettings.lng) +
            " " +
            __(
              "signUpScreenTexts.formValidation.requiredField",
              appSettings.lng
            )
        )
        .email(
          __("signUpScreenTexts.formValidation.validEmail", appSettings.lng)
        ),
      password: Yup.string()
        .required(
          __("signUpScreenTexts.formFieldLabels.password", appSettings.lng) +
            " " +
            __(
              "signUpScreenTexts.formValidation.requiredField",
              appSettings.lng
            )
        )
        .min(
          6,
          __("signUpScreenTexts.formFieldLabels.password", appSettings.lng) +
            " " +
            __(
              "signUpScreenTexts.formValidation.minimumLength6",
              appSettings.lng
            )
        ),
    })
  );
  const [responseErrorMessage, setResponseErrorMessage] = useState();
  const [loading, setLoading] = useState(false);
  const [flashNotification, setFlashNotification] = useState(false);
  const [flashNotificationMessage, setFlashNotificationMessage] = useState();
  const [tnCData, setTnCData] = useState(getTnC(appSettings.lng));
  const [tnCToggle, setTnCToggle] = useState(false);
  const [tnCVisible, setTnCVisible] = useState(false);
  const [countries, setCountries] = useState([]);
  const [icon, setIcon] = useState("eye-slash");
  const [hidePassword, setHidePassword] = useState(true);
  const [phoneCode, setPhoneCode] = useState("");

  const _changeIcon = () => {
    icon === "eye-slash"
      ? (setIcon("eye"), setHidePassword(false))
      : (setIcon("eye-slash"), setHidePassword(true));
  };

  useEffect(() => {
    getCountries();
  }, []);

  const getCountries = () => {
    api
      .get("get_countries")
      .then((res) => {
        if (res.ok) {
          const countryData = res.data.map((country) => {
            return {
              label: country.name,
              value: country.term_id,
            };
          });
          //   setCountries(countryData); //commented because we need to set only two countries

          setCountries([
            {
              label: "Somalia",
              value: 582,
            },
            {
              label: "Somaliland",
              value: 583,
            },
          ]);
        } else {
          console.log(res);
        }
      })
      .catch((error) => {
        console.log("error:", error);
      });
  };

  const handleSignup = (values) => {
    setResponseErrorMessage();
    // setLoading(true);
    Keyboard.dismiss();
    values = {
      ...values,
      phone: `${phoneCode}${values.phone}`,
    };
    console.log("vals :: ", values);
    // api.post("signup", values).then((res) => {
    //   if (res.ok) {
    //     handleSuccess(
    //       __("signUpScreenTexts.signupSuccessMessage", appSettings.lng)
    //     );
    //   } else {
    //     if (res.problem === "TIMEOUT_ERROR") {
    //       setResponseErrorMessage(
    //         __("signUpScreenTexts.errorMessage.timeoutError", appSettings.lng)
    //       );
    //       handleError(
    //         __("signUpScreenTexts.errorMessage.timeoutError", appSettings.lng)
    //       );
    //     } else {
    //       setResponseErrorMessage(
    //         res?.data?.error_message ||
    //           res?.data?.error ||
    //           res?.problem ||
    //           __("signUpScreenTexts.errorMessage.serverError", appSettings.lng)
    //       );
    //       handleError(
    //         res?.data?.error_message ||
    //           res?.data?.error ||
    //           res?.problem ||
    //           __("signUpScreenTexts.errorMessage.serverError", appSettings.lng)
    //       );
    //     }
    //   }
    // });
  };

  const handleTnCShow = () => {
    setTnCVisible(!tnCVisible);
  };
  const handleSuccess = (message) => {
    setFlashNotificationMessage(message);
    setTimeout(() => {
      setFlashNotification(true);
    }, 10);
    setTimeout(() => {
      setFlashNotification(false);
      setLoading(false);
      navigation.goBack();
    }, 800);
  };
  const handleError = (message) => {
    setFlashNotificationMessage(message);
    setTimeout(() => {
      setFlashNotification(true);
    }, 10);
    setTimeout(() => {
      setFlashNotification(false);
      setLoading(false);
    }, 4000);
  };

  return (
    <KeyboardAvoidingView
      behavior="padding"
      style={{ flex: 1 }}
      keyboardVerticalOffset={80}
    >
      <View style={[styles.container, { paddingBottom: 50 }]}>
        <View style={styles.signUpForm}>
          <Formik
            initialValues={{
              first_name: "",
              last_name: "",
              username: "",
              phone: "",
              country: "",
              email: "",
              password: "",
            }}
            validationSchema={validationSchema}
            onSubmit={handleSignup}
          >
            {({
              handleChange,
              handleSubmit,
              values,
              errors,
              setFieldTouched,
              touched,
            }) => (
              <View style={{ width: "100%", paddingHorizontal: "3%" }}>
                <Text
                  style={{
                    fontFamily: "Poppins Regular",
                  }}
                >
                  {__(
                    "signUpScreenTexts.formFieldLabels.first_name",
                    appSettings.lng
                  )}
                  <Text style={styles.required}> *</Text>
                </Text>
                <TextInput
                  style={[styles.inputCommon, styles.nameInput]}
                  onChangeText={handleChange("first_name")}
                  onBlur={() => setFieldTouched("first_name")}
                  value={values.first_name}
                  placeholder={__(
                    "signUpScreenTexts.formFieldPlaceholders.first_name",
                    appSettings.lng
                  )}
                />
                <View style={styles.errorWrap}>
                  {touched.first_name && errors.first_name && (
                    <Text style={styles.errorMessage}>{errors.first_name}</Text>
                  )}
                </View>
                <Text
                  style={{
                    fontFamily: "Poppins Regular",
                  }}
                >
                  {__(
                    "signUpScreenTexts.formFieldLabels.last_name",
                    appSettings.lng
                  )}
                  <Text style={styles.required}> *</Text>
                </Text>
                <TextInput
                  style={[styles.inputCommon, styles.nameInput]}
                  onChangeText={handleChange("last_name")}
                  onBlur={() => setFieldTouched("last_name")}
                  value={values.last_name}
                  placeholder={__(
                    "signUpScreenTexts.formFieldPlaceholders.last_name",
                    appSettings.lng
                  )}
                />
                <View style={styles.errorWrap}>
                  {touched.last_name && errors.last_name && (
                    <Text style={styles.errorMessage}>{errors.last_name}</Text>
                  )}
                </View>
                <Text
                  style={{
                    fontFamily: "Poppins Regular",
                    display: "none",
                  }}
                >
                  {__(
                    "signUpScreenTexts.formFieldLabels.username",
                    appSettings.lng
                  )}
                  <Text style={styles.required}> *</Text>
                </Text>
                <TextInput
                  style={[styles.inputCommon, { display: "none" }]}
                  onChangeText={handleChange("username")}
                  onBlur={() => setFieldTouched("username")}
                  value={values.first_name + "." + values.last_name}
                  placeholder={__(
                    "signUpScreenTexts.formFieldPlaceholders.username",
                    appSettings.lng
                  )}
                  autoCapitalize="none"
                />
                <View style={[styles.errorWrap, { display: "none" }]}>
                  {touched.username && errors.username && (
                    <Text style={styles.errorMessage}>{errors.username}</Text>
                  )}
                </View>
                <Text
                  style={{
                    fontFamily: "Poppins Regular",
                  }}
                >
                  {__(
                    "signUpScreenTexts.formFieldLabels.email",
                    appSettings.lng
                  )}
                  <Text style={styles.required}> *</Text>
                </Text>
                <TextInput
                  style={[styles.inputCommon, styles.emailImput]}
                  onChangeText={handleChange("email")}
                  onBlur={() => setFieldTouched("email")}
                  value={values.email}
                  placeholder={__(
                    "signUpScreenTexts.formFieldPlaceholders.email",
                    appSettings.lng
                  )}
                  keyboardType="email-address"
                />
                <View style={styles.errorWrap}>
                  {touched.email && errors.email && (
                    <Text style={styles.errorMessage}>{errors.email}</Text>
                  )}
                </View>

                {/* For Country */}
                <Text
                  style={{
                    fontFamily: "Poppins Regular",
                  }}
                >
                  {__(
                    "signUpScreenTexts.formFieldLabels.country",
                    appSettings.lng
                  )}
                  <Text style={styles.required}> *</Text>
                </Text>
                <RNPickerSelect
                  placeholder={{ label: "Select Country", value: 0 }}
                  useNativeAndroidPickerStyle={false}
                  items={countries}
                  onValueChange={(value, index) => {
                    values.country = value;
                    handleChange("country");
                    if (index !== 0) {
                      setPhoneCode("+252");
                    } else {
                      setPhoneCode("");
                    }
                  }}
                  onClose={() => {
                    setFieldTouched("country");
                  }}
                  style={{
                    inputAndroid: {
                      color: COLORS.black,
                      backgroundColor: COLORS.inputCommon,
                      borderRadius: 10,
                      paddingHorizontal: 10,
                      minHeight: 50,
                      textAlignVertical: "center",
                    },
                    inputIOS: {
                      color: COLORS.black,
                      backgroundColor: COLORS.inputCommon,
                      borderRadius: 10,
                      paddingHorizontal: 5,
                      minHeight: 50,
                    },
                    iconContainer: {
                      minHeight: 50,
                      justifyContent: "center",
                    },
                  }}
                  Icon={() => {
                    return (
                      <FontAwesome5
                        name={"chevron-down"}
                        size={14}
                        color={COLORS.gray}
                        style={{ paddingRight: 10 }}
                      />
                    );
                  }}
                />

                <View style={styles.errorWrap}>
                  {touched.country && errors.country && (
                    <Text style={styles.errorMessage}>{errors.email}</Text>
                  )}
                </View>
                <Text
                  style={{
                    fontFamily: "Poppins Regular",
                  }}
                >
                  {__(
                    "signUpScreenTexts.formFieldLabels.phone",
                    appSettings.lng
                  )}
                  <Text style={styles.required}> *</Text>
                </Text>
                <View style={{ flexDirection: "row" }}>
                  <TextInput
                    editable={false}
                    style={[styles.inputCommon, styles.countryCodeInput]}
                    value={phoneCode}
                  />
                  <TextInput
                    style={[styles.inputCommon, styles.phoneInput]}
                    onChangeText={handleChange("phone")}
                    onBlur={() => setFieldTouched("phone")}
                    value={values.phone}
                    placeholder={__(
                      "signUpScreenTexts.formFieldPlaceholders.phone",
                      appSettings.lng
                    )}
                    keyboardType="phone-pad"
                  />
                </View>
                <View style={styles.errorWrap}>
                  {touched.phone && errors.phone && (
                    <Text style={styles.errorMessage}>{errors.phone}</Text>
                  )}
                </View>

                <Text
                  style={{
                    fontFamily: "Poppins Regular",
                  }}
                >
                  {__(
                    "signUpScreenTexts.formFieldLabels.password",
                    appSettings.lng
                  )}
                  <Text style={styles.required}> *</Text>
                </Text>
                <View style={styles.inputWrap}>
                  <View style={{ flexDirection: "row", alignItems: "center" }}>
                    <TextInput
                      style={styles.input}
                      onChangeText={handleChange("password")}
                      onBlur={() => setFieldTouched("password")}
                      value={values.password}
                      placeholder={__(
                        "loginScreenTexts.formFieldsPlaceholder.password",
                        appSettings.lng
                      )}
                      type="password"
                      autoCorrect={false}
                      autoCapitalize="none"
                      onFocus={() => setFieldTouched("password")}
                      secureTextEntry={hidePassword}
                    />
                    <FontAwesome5
                      name={icon}
                      size={20}
                      onPress={() => _changeIcon()}
                      style={{
                        position: "absolute",
                        right: 10,
                      }}
                    />
                  </View>
                  <View style={styles.errorFieldWrap}>
                    {touched.password && errors.password && (
                      <Text style={styles.errorMessage}>{errors.password}</Text>
                    )}
                  </View>
                </View>
                {/* Terms & Conditions Toggle */}
                <TouchableOpacity
                  style={styles.tnCToggle}
                  onPress={() => setTnCToggle(!tnCToggle)}
                >
                  {/*<MaterialCommunityIcons*/}
                  {/*    name={*/}
                  {/*        tnCToggle ? "checkbox-marked" : "checkbox-blank-outline"*/}
                  {/*    }*/}
                  {/*    size={24}*/}
                  {/*    color={COLORS.primary}*/}
                  {/*/>*/}
                  <View style={{ flex: 1 }}>
                    <Text style={styles.tnCToggleText}>
                      {__("listingFormTexts.tnCToggleText", appSettings.lng)}
                      <Text style={styles.tncText} onPress={handleTnCShow}>
                        {__("listingFormTexts.tncText", appSettings.lng)}
                      </Text>
                    </Text>
                  </View>
                </TouchableOpacity>
                <AppButton
                  onPress={handleSubmit}
                  title={__(
                    "signUpScreenTexts.signUpButtonTitle",
                    appSettings.lng
                  )}
                  style={styles.signUpBtn}
                  textStyle={styles.signUpBtnTxt}
                  disabled={
                    Object.keys(errors).length > 0
                    // Object.keys(touched).length === 0
                    // !tnCToggle
                  }
                  loading={loading}
                />
                <View style={styles.responseErrorWrap}>
                  <Text style={styles.responseErrorMessage}>
                    {responseErrorMessage}
                  </Text>
                </View>
              </View>
            )}
          </Formik>
        </View>

        <FlashNotification
          falshShow={flashNotification}
          flashMessage={flashNotificationMessage}
          containerStyle={styles.flashContainerStyle}
        />
      </View>
      {/* Terms & Conditions */}
      <Modal animationType="slide" transparent={true} visible={tnCVisible}>
        <SafeAreaView
          style={[styles.tncModal, { marTop: Constants.statusBarHeight }]}
        >
          <ScrollView contentContainerStyle={styles.tnCModalContent}>
            <Text
              style={{
                textAlign: "center",
                fontFamily: "Poppins Bold",
                marginTop: 10,
                fontSize: 17,
              }}
            >
              {__("listingFormTexts.tncTitleText", appSettings.lng)}
            </Text>
            <View
              style={{
                alignItems: "center",
                justifyContent: "center",
                flex: 1,
                paddingVertical: 10,
                paddingHorizontal: 10,
              }}
            >
              {tnCData.map((_tnc, index) => (
                <View style={styles.tncParaWrap} key={index}>
                  {!!_tnc.paraTitle && (
                    <Text style={styles.paraTitle}>{_tnc.paraTitle}</Text>
                  )}
                  <Text
                    style={[
                      styles.paraData,
                      {
                        fontFamily: "Poppins Regular",
                        textAlign: "justify",
                      },
                    ]}
                  >
                    {_tnc.paraData}
                  </Text>
                </View>
              ))}
            </View>
          </ScrollView>
          <TouchableOpacity style={styles.tnCClose} onPress={handleTnCShow}>
            <Text style={styles.tnCCloseText}>Close</Text>
          </TouchableOpacity>
        </SafeAreaView>
      </Modal>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    flex: 1,
  },
  errorMessage: {
    color: COLORS.red,
    fontSize: 12,
    fontFamily: "Poppins Bold",
  },
  errorWrap: {
    height: 20,
  },
  flashContainerStyle: {
    top: "85%",
    bottom: "5%",
  },
  signUpForm: {
    width: "100%",
    paddingTop: 10,
    marginBottom: 40,
  },
  inputCommon: {
    backgroundColor: "#F5F7FF",
    width: "100%",
    marginVertical: 10,
    height: 50,
    justifyContent: "center",
    borderRadius: 10,
    paddingHorizontal: 10,
    fontFamily: "Poppins Regular",
  },
  label: {
    alignItems: "flex-start",
  },
  loginPrompt: {
    marginTop: 40,
  },
  required: {
    color: COLORS.red,
  },
  responseErrorWrap: {
    alignItems: "center",
  },
  responseErrorMessage: {
    color: COLORS.red,
    fontSize: 15,
    fontFamily: "Poppins Bold",
  },
  signUpBtn: {
    height: 50,
    borderRadius: 30,
    marginVertical: 10,
    width: "100%",
    justifyContent: "center",
  },
  tnCClose: {
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: COLORS.primary,
    height: screenHeight / 20,
  },
  tnCCloseText: {
    color: COLORS.white,
    fontSize: 17,
    fontFamily: "Poppins Bold",
  },
  tncModal: {
    backgroundColor: COLORS.white,
    flex: 1,
    alignItems: "center",
  },
  tnCModalContent: {
    marginHorizontal: "3%",
    marginBottom: screenHeight / 20,
  },
  tnCModalText: {
    color: COLORS.text_dark,
    fontSize: 15,
    fontFamily: "Poppins Regular",
  },
  tncParaWrap: {
    marginBottom: 20,
  },
  tncText: {
    color: "#ff6600",
    fontFamily: "Poppins Regular",
  },
  tnCToggle: {
    flexDirection: "row",
    paddingHorizontal: screenWidth * 0.03,
    alignItems: "center",
    marginVertical: 10,
  },
  tnCToggleText: {
    paddingLeft: 5,
    fontFamily: "Poppins Regular",
    fontSize: 10,
  },
  input: {
    backgroundColor: "#F5F7FF",
    width: "100%",
    marginVertical: 10,
    height: 50,
    justifyContent: "center",
    borderRadius: 10,
    paddingHorizontal: 10,
    fontFamily: "Poppins Regular",
  },
  countryCodeInput: {
    width: "16%",
    borderBottomRightRadius: 0,
    borderTopRightRadius: 0,
    color: COLORS.black,
  },
  phoneInput: {
    borderBottomLeftRadius: 0,
    borderTopLeftRadius: 0,
    width: "84%",
  },
});

export default SignUpScreen;
