/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  BackHandler,
  ActivityIndicator,
  Linking,
  KeyboardAvoidingView,
  ImageBackground,
  TextInput,
  Dimensions,
  TouchableWithoutFeedback,
} from "react-native";

import { Formik } from "formik";
// Vector Icons
import { FontAwesome5 } from "@expo/vector-icons";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { Octicons } from "@expo/vector-icons";
import { MaterialIcons } from "@expo/vector-icons";

// Custom Components & Functions
import AppSeparator from "../components/AppSeparator";
import { COLORS } from "../variables/color";
import ListingForm from "../components/ListingForm";
import { useStateValue } from "../StateProvider";
import api, { removeAuthToken, setAuthToken } from "../api/client";
import AppButton from "../components/AppButton";
import TabScreenHeader from "../components/TabScreenHeader";
import { decodeString } from "../helper/helper";
import { __ } from "../language/stringPicker";
import { routes } from "../navigation/routes";
import Feather from "react-native-vector-icons/Feather";
import CategoryImage from "../components/CategoryImage";
import CategoryIcon from "../components/CategoryIcon";
import PremiumAds from "../components/PremiumAds";
import BusinessServiceListingForm from "../components/BusinessServiceListingForm";
import CacheStore from "react-native-cache-store";

const { width: screenWidth, height: screenHeight } = Dimensions.get("screen");
const NewBusinessServiceScreen = ({ navigation, route }) => {
  const [
    {
      newListingScreen,
      user,
      listing_locations,
      auth_token,
      config,
      ios,
      appSettings,
    },
    dispatch,
  ] = useStateValue();
  const [adType, setAdType] = useState("Buy & Sell");
  const [categories, setCategories] = useState({});
  const [currentCategories, setCurrentCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [catLoading, setCatLoading] = useState(false);
  const [noSubCat, setNoSubCat] = useState(false);
  const [locationsData, setLocationsData] = useState([]);
  const [newListingConfig, setNewListingConfig] = useState({});
  const category =
    route.params.category === 498
      ? "Choose Your Business Type"
      : route.params.category === 338
      ? "Select Needs Category"
      : "Choose Your Profession";

  useEffect(() => {
    const focused = navigation.addListener("focus", () => {
      setAuthToken(auth_token);
      api.get("my/listings").then((res) => {
        if (res.ok) {
          const array = res.data.data;
          // console.log(array)
          for (let i = 0; i < array.length; i++) {
            if (
              route.params.category === 353 &&
              array[i]?.categories[0]?.parent === 353
            ) {
              navigation.pop();
              navigation.navigate("Business Profile", {
                category: 353,
                business_id: array[i].listing_id,
              });
            }
            if (
              route.params.category === 498 &&
              array[i]?.categories[0]?.parent === 498
            ) {
              navigation.pop();
              navigation.navigate("Business Profile", {
                category: 498,
                business_id: array[i].listing_id,
              });
            }
          }
          removeAuthToken();
        }
      });
      return focused;
    });
  }),
    [navigation];

  const handleClear = () => {
    setAdType("Buy & Sell");
    setCurrentCategories([]);
    setNoSubCat(false);
    setNewListingConfig({});

    dispatch({
      type: "SET_LISTING_LOCATIONS",
      listing_locations: null,
    });
  };
  let [counter, setCounter] = useState(0);
  const handleBackButtonClick = () => {
    handleClear();
    if (counter === 0) {
      navigation.goBack(null);
      dispatch({
        type: "SET_NEW_LISTING_SCREEN",
        newListingScreen: false,
      });
    } else {
      setCounter(0);
      handleClear();
    }
    return true;
  };

  //get categories call
  useEffect(() => {
    if (!adType) return;
    setLoading(true);
    const category =
      route.params.category === 498
        ? 498
        : route.params.category === 338
        ? 338
        : 353;
    getSubCategoryData(category);
  }, [adType]);

  const handleSelectedCatPress = (arg) => {
    setCurrentCategories((prevCurrentCategories) =>
      prevCurrentCategories.slice(0, arg)
    );
    const selectedData = {};
    for (let i = 0; i <= arg; i++) {
      selectedData[i] = categories[i];
    }
    setCategories(selectedData);
  };

  const catPicker = (arg) => {
    if (currentCategories.length < arg) return;
    BackHandler.addEventListener("hardwareBackPress", handleBackButtonClick);
    BackHandler.addEventListener("hardwareBackPress", () => {
      handleSelectedCatPress(arg);
    });
    return (
      <View key={arg}>
        {/* Selected Category */}
        {/*{currentCategories[arg] && (*/}
        {/*    <TouchableOpacity*/}
        {/*        style={[*/}
        {/*            styles.selectedCategory,*/}
        {/*            {*/}
        {/*                backgroundColor: arg == 0 ? COLORS.primary : COLORS.bg_primary,*/}
        {/*            },*/}
        {/*        ]}*/}
        {/*        onPress={() => handleSelectedCatPress(arg)}*/}
        {/*    >*/}
        {/*        <Text*/}
        {/*            style={[*/}
        {/*                styles.selectedCategoryText,*/}
        {/*                {*/}
        {/*                    color: arg == 0 ? COLORS.white : COLORS.primary,*/}
        {/*                },*/}
        {/*            ]}*/}
        {/*        >*/}
        {/*            {decodeString(currentCategories[arg].name)}*/}
        {/*        </Text>*/}
        {/*        <FontAwesome5*/}
        {/*            name="times"*/}
        {/*            size={15}*/}
        {/*            color={arg == 0 ? COLORS.white : COLORS.primary}*/}
        {/*        />*/}
        {/*    </TouchableOpacity>*/}
        {/*)}*/}
        {/* Category Picker Options */}

        {!currentCategories[arg] && (
          <View
            style={{
              flexDirection: "row",
              flexWrap: "wrap",
              justifyContent: "center",
            }}
          >
            {categories[arg].map((_category) => (
              <View
                style={{
                  width: "50%",
                }}
              >
                <TouchableWithoutFeedback
                  key={_category.term_id}
                  onPress={() => handleCategorySelection(_category)}
                >
                  <View
                    style={{
                      backgroundColor: COLORS.white,
                      borderRadius: 26,
                      elevation: 5,
                      marginBottom: 25,
                      shadowColor: "#a9a9a9",
                      shadowOffset: {
                        width: 0,
                        height: 12,
                      },
                      shadowOpacity: 0.58,
                      shadowRadius: 16.0,
                      marginHorizontal: 10,
                    }}
                  >
                    <View style={{ alignItems: "center", paddingTop: 10 }}>
                      {_category?.icon?.url ? (
                        <CategoryImage size={47} uri={_category.icon.url} />
                      ) : (
                        <CategoryIcon
                          iconName={_category.icon.class}
                          iconSize={27}
                          iconColor={COLORS.primary}
                        />
                      )}
                    </View>
                    <View
                      style={{
                        flexDirection: "row",
                        padding: 10,
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <Text
                        style={{
                          color: "#19191D",
                          fontSize: 10,
                          lineHeight: 29,
                          fontFamily: "Poppins Bold",
                          textAlign: "center",
                        }}
                      >
                        {decodeString(_category.name)}
                      </Text>
                    </View>
                  </View>
                </TouchableWithoutFeedback>
              </View>
            ))}
          </View>
        )}
        {/* Loading Component for Next level Picker Existance Checking */}
        {!currentCategories[arg + 1] && catLoading && (
          <View style={styles.loading}>
            <ActivityIndicator size="large" color={COLORS.primary} />
          </View>
        )}
      </View>
    );
  };

  const handleCategorySelection = (item) => {
    setCounter(1);
    setCurrentCategories((prevCurrentCategories) => [
      ...prevCurrentCategories,
      item,
    ]);
    setCatLoading(true);
    getSubCategoryData(item.term_id);
  };

  // console.log(currentCategories)

  const _getSubData = (parent_id) => {
    api
      .get("categories", {
        parent_id: parent_id,
      })
      .then((res) => {
        if (res.ok) {
          const array = res.data;
          CacheStore.set(`sub_${parent_id}`, array, 24 * 60);
          if (res.data.length) {
            const nwekey = Object.keys(categories).length;
            setCategories((prevCategories) => {
              return { ...prevCategories, [nwekey]: res.data };
            });
          } else {
            setNoSubCat(true);
          }
          setCatLoading(false);
        } else {
          //print error
          // TODO handle error
        }
      });
  };

  const getSubCategoryData = (parent_id) => {
    CacheStore.get(`sub_${parent_id}`)
      .then((data) => {
        if (data === null) {
          _getSubData(parent_id);
        } else {
          const array = [...data];
          if (array.length) {
            const nwekey = Object.keys(categories).length;
            setCategories((prevCategories) => {
              return { ...prevCategories, [nwekey]: array };
            });
          } else {
            setNoSubCat(true);
          }
          setCatLoading(false);
        }
      })
      .catch(() => {
        _getSubData(parent_id);
      });
  };

  const getCategoryTaxonomy = () => {
    let parent = currentCategories[0];
    return decodeString(parent.name);
  };

  const handleLocationButtonPress = () => {
    navigation.navigate(routes.selectLocationScreen, {
      data: locationsData,
      type: "newListing",
    });
  };

  const handleChangeCategoryButtonPress = () => {
    setCurrentCategories([]);
    setAdType();
    setNoSubCat(false);
  };

  const getLocationTaxonomy = () => {
    if (!listing_locations) return;
    return decodeString(
      listing_locations.map((_location) => _location.name).join(" > ")
    );
  };

  const handleChangeLocationButtonPress = () => {
    dispatch({
      type: "SET_LISTING_LOCATIONS",
      listing_locations: [],
    });
  };

  const handleMembership = () => {
    // TODO update this after adding membership feature
    Linking.openURL(__("newListingScreenTexts.membershipURL", appSettings.lng));
  };

  const handleGoBack = () => {
    handleBackButtonClick();
  };
  const handleGoBackonSuccess = () => {
    navigation.pop();
    navigation.navigate("Profile", { load: 1 });
  };

  return user ? (
    <KeyboardAvoidingView
      behavior={ios ? "padding" : "height"}
      style={{ flex: 1, backgroundColor: COLORS.white }}
      keyboardVerticalOffset={ios ? 20 : -20}
    >
      <TabScreenHeader
        left
        onLeftClick={() => {
          handleSelectedCatPress(0);
          handleBackButtonClick();
        }}
        style={{ elevation: 0 }}
      />
      <ScrollView>
        <View style={styles.container}>
          <View style={styles.mainWrap}>
            {/* Ad Category & Location Selector */}
            {/* Category Selector Wrap */}
            {adType && (
              <View
                style={
                  !!currentCategories.length && noSubCat
                    ? styles.displayNone
                    : styles.categoryWrap
                }
              >
                <View style={styles.imageSearchContainer}>
                  <View style={styles.child}>
                    <PremiumAds admob={false} />
                    <View
                      style={{
                        position: "absolute",
                        left: 0,
                        right: 0,
                        top: 20,
                      }}
                    >
                      <View style={styles.listingTop}>
                        <Formik initialValues={{ search: "" }}>
                          {() => (
                            <View style={styles.ListingSearchContainer}>
                              <TextInput
                                style={styles.searchInput}
                                placeholder={__(
                                  "homeScreenTexts.listingSearchPlaceholder",
                                  appSettings.lng
                                )}
                                placeholderTextColor={COLORS.textGray}
                                returnKeyType="search"
                              />

                              <TouchableOpacity
                                style={styles.listingSearchBtnContainer}
                              >
                                <Feather
                                  name="search"
                                  size={20}
                                  color={COLORS.white}
                                />
                              </TouchableOpacity>
                            </View>
                          )}
                        </Formik>
                      </View>
                    </View>
                  </View>
                </View>
                <View style={styles.categoryTitleWrap}>
                  <Text style={styles.categoryTitle}>{category}</Text>
                </View>
                {loading && !Object.keys(categories).length ? (
                  <View style={styles.loading}>
                    <ActivityIndicator size="large" color={COLORS.primary} />
                    <Text style={styles.text}>
                      {__("homeScreenTexts.loadingMessage", appSettings.lng)}
                    </Text>
                  </View>
                ) : (
                  <View style={styles.adCategory}>
                    {Object.keys(categories).map((_cat, index) =>
                      catPicker(index)
                    )}
                  </View>
                )}
              </View>
            )}
            {/* Category & Location Change Button Wrap */}
            {/*<View*/}
            {/*    style={*/}
            {/*        !!currentCategories.length &&*/}
            {/*        noSubCat*/}
            {/*            ? styles.changeCategoryWrap*/}
            {/*            : styles.displayNone*/}
            {/*    }*/}
            {/*>*/}

            {/*    /!* Location Change Button Wrap *!/*/}
            {/*    {config.location_type === "local" && (*/}
            {/*        <View*/}
            {/*            style={[*/}
            {/*                styles.categoryChangeWrap,*/}
            {/*                {backgroundColor: COLORS.bg_primary},*/}
            {/*            ]}*/}
            {/*        >*/}
            {/*            <View style={{flex: 1}}>*/}
            {/*                <Text style={styles.categoryRoute}>*/}
            {/*                    {getLocationTaxonomy()}*/}
            {/*                </Text>*/}
            {/*            </View>*/}
            {/*            <TouchableOpacity*/}
            {/*                style={styles.routeChangeIconWrap}*/}
            {/*                onPress={handleChangeLocationButtonPress}*/}
            {/*            >*/}
            {/*                <MaterialIcons*/}
            {/*                    name="mode-edit"*/}
            {/*                    size={14}*/}
            {/*                    color={COLORS.white}*/}
            {/*                />*/}
            {/*            </TouchableOpacity>*/}
            {/*        </View>*/}
            {/*    )}*/}
            {/*</View>*/}
            {adType && !!currentCategories.length && noSubCat && (
              <BusinessServiceListingForm
                catId={currentCategories[currentCategories.length - 1].term_id}
                type={adType}
                parent={route.params.category}
                catName={currentCategories[currentCategories.length - 1].name}
                goBack={handleGoBackonSuccess}
                taxonomy={getCategoryTaxonomy()}
              />
            )}
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  ) : (
    <>
      <TabScreenHeader
        left={user && newListingScreen}
        onLeftClick={handleGoBack}
        style={{ elevation: 0 }}
      />
      <View style={styles.noUserViewWrap}>
        <View style={styles.noUserTitleWrap}>
          <Text style={styles.noUserTitle}>
            {__("newListingScreenTexts.notLoggedIn", appSettings.lng)}
          </Text>
          <Text style={styles.noUserMessage}>
            {__("newListingScreenTexts.loginOrSignUp", appSettings.lng)}
          </Text>
          <View style={styles.authButtonWrap}>
            <AppButton
              style={styles.authButton}
              title={__(
                "newListingScreenTexts.loginOrSignUpButtonTitle",
                appSettings.lng
              )}
              onPress={() => navigation.navigate(routes.signuploginScreen)}
            />
          </View>
        </View>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  adCategory: {
    marginBottom: 5,
  },
  adType: {},
  authButton: {
    borderRadius: 3,
    width: "100%",
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  authButtonWrap: {
    marginVertical: 20,
    width: "100%",
  },
  button: {
    width: "45%",
  },
  buttonWrap: {
    flexDirection: "row",
    width: "100%",
    alignItems: "center",
    justifyContent: "space-around",
    paddingHorizontal: "3%",
    marginTop: "5%",
  },
  categoryChangeWrap: {
    paddingVertical: 10,
    alignItems: "center",
    justifyContent: "space-between",
    flexDirection: "row",
    paddingHorizontal: "3%",
  },
  categoryPickerFieldText: {
    textTransform: "capitalize",
  },
  categoryPickerFieldWrap: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderWidth: 1,
    borderColor: COLORS.gray,
    borderRadius: 3,
    paddingVertical: 5,
    paddingHorizontal: "3%",
    marginVertical: 10,
  },
  categoryPickerOptions: {
    backgroundColor: COLORS.white,
    padding: 8,
    marginVertical: 5,
    marginHorizontal: 3,
    borderRadius: 3,
    borderWidth: 1,
    borderColor: COLORS.bg_dark,
  },
  categoryPickerOptionsText: {
    fontSize: 13,
    fontWeight: "bold",
    color: COLORS.text_gray,
  },
  categoryPickerWrap: {},
  categoryTitle: {
    fontSize: 20,
    fontFamily: "Poppins Bold",
    color: COLORS.headingsColor,
    paddingHorizontal: 10,
    // lineHeight: 51,
    // textAlign: 'center'
  },
  categoryRoute: {
    fontSize: 15,
    color: COLORS.text_gray,
    fontWeight: "bold",
  },
  categoryTitleWrap: {
    alignItems: "center",
    paddingVertical: 15,
  },
  categoryWrap: {
    paddingHorizontal: "3%",
  },
  changeCategory: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    padding: 5,
    marginTop: 10,
    borderRadius: 3,
    backgroundColor: COLORS.primary,
  },
  changecategoryText: {
    color: COLORS.white,
    paddingRight: 5,
  },
  changeCategoryWrap: {
    marginBottom: 10,
  },
  checkWrap: {
    alignItems: "center",
    marginVertical: "10%",
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  displayNone: {
    display: "none",
  },
  flashMessage: {
    position: "absolute",
    backgroundColor: "green",
    width: "100%",
    justifyContent: "center",
    alignItems: "center",
    height: 50,
    bottom: 0,
    zIndex: 2,
  },
  formSeparator: {
    width: "100%",
  },
  freeAdText: {
    backgroundColor: COLORS.light_green,
    width: "80%",
    textAlign: "center",
    color: COLORS.dark_green,
    borderRadius: 3,
    paddingVertical: 8,
    fontSize: 16,
  },
  freeAdWrap: {
    paddingHorizontal: "3%",
    alignItems: "center",
    marginVertical: 15,
  },
  locationSelector: {
    justifyContent: "center",
    alignItems: "center",
    padding: 8,
    borderRadius: 3,
    backgroundColor: COLORS.primary,
  },
  locationSelectorText: {
    color: COLORS.white,
    paddingRight: 5,
    fontWeight: "bold",
    fontSize: 13,
  },
  internalSeparator: {
    marginVertical: 10,
    width: "100%",
  },
  locationWrap: {
    marginVertical: 10,
  },
  mainWrap: {},
  mandatory: {
    color: COLORS.red,
    fontSize: 16,
  },
  remainingAdsText: {
    fontSize: 16,
    marginVertical: "2%",
    paddingHorizontal: "3%",
    textAlign: "center",
  },
  routeArrow: {
    color: COLORS.text_gray,
  },
  routeChangeIconWrap: {
    padding: 3,
    backgroundColor: "#ff6600",
    borderRadius: 3,
    alignItems: "center",
    justifyContent: "center",
  },
  separator: {
    width: "100%",
    backgroundColor: COLORS.bg_dark,
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
    color: COLORS.text_gray,
    paddingVertical: 10,
  },
  titleWrap: {
    paddingHorizontal: "3%",
    alignItems: "center",
  },

  typePickerFieldWrap: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: "3%",
    marginVertical: 15,
  },
  typePickerOptions: {
    marginVertical: 5,
  },
  types: {
    fontWeight: "bold",
    color: COLORS.text_gray,
    paddingLeft: 18,
  },
  typePickerWrap: {
    paddingVertical: 10,
  },
  typeTitle: {
    fontSize: 14,
    fontWeight: "bold",
    color: COLORS.text_dark,
    paddingHorizontal: 10,
  },
  typeTitleWrap: {
    flexDirection: "row",
    alignItems: "center",
    paddingTop: 10,
    paddingBottom: 15,
  },
  typeWrap: {
    paddingHorizontal: "3%",
  },
  loading: {
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    opacity: 0.8,
    backgroundColor: "transparent",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 5,
    flex: 1,
  },
  notEligible: {
    alignItems: "center",
    marginVertical: "10%",
  },
  noUserMessage: {
    fontSize: 16,
  },
  noUserTitle: {
    fontSize: 20,
  },
  noUserTitleWrap: {
    alignItems: "center",
  },
  noUserViewWrap: {
    justifyContent: "center",
    alignItems: "center",
    flex: 1,
  },
  selectedCategory: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",

    padding: 8,
    borderRadius: 3,
    marginVertical: 5,
  },
  selectedCategoryText: {
    fontSize: 13,
    fontWeight: "bold",
    paddingLeft: 18,
  },
  ListingSearchContainer: {
    flex: 1,
    height: 45,
    marginHorizontal: 20,
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderRadius: 50,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 15,
    elevation: 7,
    zIndex: 20,
    shadowColor: "#000",
    shadowRadius: 4,
    shadowOpacity: 0.2,
    shadowOffset: {
      height: -4,
      width: 2,
    },
  },
  searchInput: {
    flex: 1,
    fontFamily: "Poppins Regular",
  },
  imageSearchContainer: {
    paddingTop: 0,
    borderBottomRightRadius: 50,
    height: 240,
    width: "100%",
    transform: [{ scaleX: 2 }],
    borderBottomStartRadius: 200,
    borderBottomEndRadius: 200,
    overflow: "hidden",
  },
  child: {
    // top: -100,
    flex: 1,
    transform: [{ scaleX: 0.5 }],
    alignItems: "center",
    justifyContent: "center",
  },
  listingTop: {
    width: "100%",
    // paddingTop: 100,
    zIndex: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: screenWidth * 0.03,
    paddingBottom: 10,
  },
  listingSearchBtnContainer: {
    marginLeft: 5,
    marginRight: -10,
    backgroundColor: COLORS.primary,
    borderRadius: 50,
    padding: 8,
  },
});

export default NewBusinessServiceScreen;
