import React, { useEffect, useState, useRef } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { LogBox, Linking as RNLinking } from "react-native";
import * as Notifications from "expo-notifications";
import * as Linking from "expo-linking";
// Custom Components
import Screen from "./components/Screen";
import HomeNavigator from "./navigation/HomeNavigator";
import { StateProvider } from "./StateProvider";
import reducer, { initialState } from "./reducer";
import * as Font from "expo-font";
import AppLoading from "expo-app-loading";
import { createNavigationContainerRef } from "@react-navigation/native";

const getFonts = () =>
  Font.loadAsync({
    // eslint-disable-next-line no-undef
    "Poppins Bold": require("./assets/fonts/Poppins-Bold.ttf"),
    // eslint-disable-next-line no-undef
    "Poppins Regular": require("./assets/fonts/Poppins-Regular.ttf"),
  });

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

const prefix = Linking.createURL("/");

export default function App() {
  const [fontsLoaded, setLoaded] = useState(false);
  const [notification, setNotification] = useState("");
  const [notificationData, setNotificationData] = useState(null);
  const [isNavigationReady, setNavigationReady] = useState(false);
  const notificationListener = useRef();
  const responseListener = useRef();
  const navigationRef = createNavigationContainerRef();

  // TODO: This is a temporary fix for the "Componentwillreceiveprops has been renamed" development warning
  LogBox.ignoreLogs(["componentWillReceiveProps"]);

  useEffect(() => {
    // This listener is fired whenever a notification is received while the app is foregrounded.
    notificationListener.current =
      Notifications.addNotificationReceivedListener((notification) => {
        console.log(notification);
      });
    // This listener is fired whenever a use taps on or interacts with a notification (works when app is foregrounded, backgrounded, or killed)
    responseListener.current =
      Notifications.addNotificationResponseReceivedListener(
        async (response) => {
          const { notification } = response;
          const { data } = notification.request.content;
          if (data.data_type == "link") {
            if (await RNLinking.canOpenURL(data.data)) {
              RNLinking.openURL(data.data);
            }
          } else if (data.data_type == "product_id") {
            if (isNavigationReady) {
              navigationRef.navigate("Listing Detail", {
                listingId: data.data,
              });
            } else {
              setNotificationData(data);
            }
          }
        }
      );

    return () => {
      Notifications.removeNotificationSubscription(
        notificationListener.current
      );
      Notifications.removeNotificationSubscription(responseListener.current);
    };
  }, []);

  useEffect(() => {
    if (isNavigationReady && notificationData) {
      const { data_type, data } = notificationData;
      if (data_type == "product_id") {
        if (navigationRef.isReady()) {
          setNotificationData(null);
          navigationRef.navigate("Listing Detail", { listingId: data });
        }
      }
    }
  }, [isNavigationReady, notificationData]);

  if (fontsLoaded) {
    return (
      <StateProvider initialState={initialState} reducer={reducer}>
        <Screen>
          <NavigationContainer
            ref={navigationRef}
            onReady={() => setNavigationReady(true)}
          >
            <HomeNavigator />
          </NavigationContainer>
        </Screen>
      </StateProvider>
    );
  } else {
    return (
      <AppLoading
        startAsync={getFonts}
        onFinish={() => {
          setLoaded(true);
        }}
        onError={console.warn}
      />
    );
  }
}
