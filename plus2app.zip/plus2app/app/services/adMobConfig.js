export const admobConfig = {
  admobEnabled: true,
  admobBannerId: {
    android: "ca-app-pub-3940256099942544/6300978111",
    iOS: "ca-app-pub-3940256099942544/2934735716",
  },
  listAdType: "largeBanner", // "banner" => 320x50, "largeBanner" => 320x100, "mediumRectangle" => 300x250
  detailScreenAdType: "largeBanner", // "banner" => 320x50, "largeBanner" => 320x100, "mediumRectangle" => 300x250
};