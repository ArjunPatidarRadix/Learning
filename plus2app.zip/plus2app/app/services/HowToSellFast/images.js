const images = {
  1: require("../../../assets/pick-the-right-price.png"),
  2: require("../../../assets/use-great-photo.png"),
  3: require("../../../assets/clear-descripion.png"),
};

export function getSellFastImages() {
  return images;
}
