const optionsExtraData = {
  my_listings: {
    routeName: "My Listings",
    icon: "hdd-o",
    assetUri: require("../../../assets/my_listings.png"),
    id: "my_listings",
  },
  my_store: {
    routeName: "My Online Store",
    icon: "store_icon",
    assetUri: require("../../../assets/store_icon.png"),
    id: "my_store",
  },
  all_stores: {
    routeName: "Online Stores",
    icon: "store_icon",
    assetUri: require("../../../assets/all_store_icon.png"),
    id: "all_stores",
  },
  my_public_profile: {
    routeName: "Public Profile",
    icon: "store_icon",
    assetUri: require("../../../assets/all_store_icon.png"),
    id: "my_public_profile",
  },

  faq: {
    routeName: "FAQ",
    icon: "question-circle",
    assetUri: require("../../../assets/faq.png"),
    id: "faq",
  },
  how_to_sell_fast: {
    routeName: "How To Sell Fast",
    icon: "key",
    assetUri: require("../../../assets/how_to_sell_fast.png"),
    id: "how_to_sell_fast",
  },
  more: {
    routeName: "More",
    icon: "ellipsis-h",
    assetUri: require("../../../assets/more.png"),
    id: "more",
  },
};

export function getOptionsExtraData() {
  return optionsExtraData;
}
