export const appName = "Plus2";
