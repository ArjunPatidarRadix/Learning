export const Images = {
  SplashImg: require("./../splash.png"),
};
