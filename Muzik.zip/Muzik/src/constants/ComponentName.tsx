export const ComponentName = {
  SplashScreen: "Splash",
  IntroScreen: "Intro",
};
