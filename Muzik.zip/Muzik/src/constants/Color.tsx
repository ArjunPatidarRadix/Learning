export const Colors = {
  white: "#ffffff",
  accent: "#F7943D",
  grey: "#808080",
  primary: "#0E0E0E",
  btnBg: "#CBCBCB",
  black: "#000",
};
