export default {
  BASE_URL: 'https://itunes.apple.com/',
  HOME_URL: '',
};
